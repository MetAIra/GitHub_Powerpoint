---
name: structured-output
description: Ollama の構造化出力(format="json" / JSON スキーマ指定)と Pydantic での検証、失敗時の再試行を実装する。「LLM の出力を JSON で受け取りたい」「抽出結果を Pydantic で検証したい」と言われたときに使う。
---

# 構造化出力(JSON スキーマ + Pydantic)

## 目的
ローカルモデルの出力を、プログラムでそのまま使える型付きデータとして受け取る。スキーマでの制約・検証・再試行の 3 段構えで、小さいモデルでも壊れた JSON を下流に流さない。

## 最初に確認すること
- 取り出したい項目と型(必須/任意、列挙値、配列、数値範囲)
- 入力の種類(テキスト / 画像 = vision 対応モデルが必要)
- 失敗時の扱い(再試行回数、最終的に例外かスキップか。既定: 2 回再試行して例外)
- Pydantic v2 を使えるか(既定: v2。`model_json_schema()` / `model_validate_json()`)

## 手順
1. **方式を選ぶ**
   | 方式 | 指定 | 使う場面 |
   |---|---|---|
   | JSON モード | `format="json"` | 形は自由でよく JSON でありさえすればよい |
   | スキーマ指定 | `format=<JSON Schema dict>` | 項目と型を固定したい(推奨) |
   スキーマ指定でも意味的な誤り(値の取り違え・捏造)は防げないので、検証は必須
2. **Pydantic でスキーマを定義**: フィールド名は英語の snake_case、`Field(description=...)` に日本語で意味を書く。自由記述より `Literal` や `enum` で選択肢を絞る
3. **呼び出しと検証**
   ```python
   from typing import Literal
   from pydantic import BaseModel, Field, ValidationError
   from ollama import chat

   class Ticket(BaseModel):
       category: Literal["請求", "不具合", "要望", "その他"]
       urgency: int = Field(ge=1, le=5, description="1=低 5=至急")
       summary: str = Field(max_length=80)

   def extract(text: str, model="gemma3:4b", retries=2) -> Ticket:
       schema = Ticket.model_json_schema()
       msgs = [{"role": "system", "content": "問い合わせを分類し、指定スキーマの JSON だけを返す。"
                f"スキーマ: {schema}"},
               {"role": "user", "content": text}]
       for attempt in range(retries + 1):
           r = chat(model=model, messages=msgs, format=schema, options={"temperature": 0})
           try:
               return Ticket.model_validate_json(r.message.content)
           except ValidationError as e:
               msgs += [{"role": "assistant", "content": r.message.content},
                        {"role": "user", "content": f"検証エラー: {e.errors()[:3]}。修正した JSON のみ返して。"}]
       raise ValueError("構造化出力に失敗")
   ```
   公式ドキュメントも「スキーマを文字列としてプロンプトにも入れる」ことと `temperature 0` を推奨している
4. **再試行の設計**: エラー内容を具体的に返して直させる(上記)。同じプロンプトの単純リトライは効果が薄い。上限回数を必ず設ける。`num_predict` が小さすぎると JSON が途中で切れるので余裕を持たせる
5. **スキーマ設計のコツ(小さいモデル向け)**
   - ネストは 2 段まで、フィールドは 10 個程度まで。多い場合は 2 回に分けて抽出
   - 該当なしを表現できるよう `str | None` を用意(ないと捏造しやすい)
   - 数値の単位・日付形式(`YYYY-MM-DD`)を description に書く
6. **検証を厚く**: Pydantic の `field_validator` で業務ルール(合計一致、日付の前後関係)をチェック。抽出元テキストに値が実在するか(部分一致)の確認も有効
7. **テスト**: 正常例・該当なし・紛らわしい例を含む 10〜20 件で成功率と正解率を測る。`pytest` でモデル呼び出しをモックした検証ロジックの単体テストと、実モデルでの評価スクリプトを分ける
8. **安全**: 出力 JSON を `eval` しない。ファイルパスや SQL に使う値は許可リストやパラメータ化で扱う。OpenAI 互換 API 経由なら `response_format` でも指定可能(詳細は公式で確認)

## 出力フォーマット
```markdown
## 構造化出力の設計
- モデル: <name:tag> / temperature=0
- スキーマ: <Pydantic クラス名>(項目: ...)
- 方式: format=<schema> + プロンプト内スキーマ
- 検証: Pydantic + <業務ルール>
- 再試行: 最大 <n> 回、エラー内容をフィードバック
- 評価: <n> 件で成功率 <x>% / 正解率 <y>%
- 確認: `python extract.py sample.txt`、`pytest -q`
```

## 品質チェックリスト
- [ ] `format` にスキーマを渡し、プロンプトにもスキーマを入れた
- [ ] `model_validate_json` で必ず検証している
- [ ] 再試行に上限があり、エラー内容を返している
- [ ] 該当なしを表せる型(Optional)を用意した
- [ ] 出力を eval/exec や生 SQL に使っていない

## 例
入力: 「請求書のテキストから請求元・金額・期日を抜きたい」
出力: `Invoice(vendor: str, amount_jpy: int, due_date: date | None)` を定義し、`format=Invoice.model_json_schema()`・temperature 0、金額が本文に含まれるかの検証と 2 回再試行を付けた実装と、10 件の評価手順を提示。
