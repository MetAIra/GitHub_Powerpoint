---
name: tool-calling
description: Ollama のツール呼び出し(function calling)を実装する。対応モデルの確認、ツール定義(Python 関数 or JSON スキーマ)、複数回の実行ループ、引数検証や許可リストによる安全な実行までを示す。「ローカル LLM に関数を呼ばせたい」「Ollama でエージェントループを作りたい」と言われたときに使う。
---

# ツール呼び出し(Ollama)

## 目的
モデルに「どのツールをどの引数で呼ぶか」を決めさせ、実行はアプリ側が安全に行う。ループの終了条件・引数検証・権限制御を最初から組み込む。

## 最初に確認すること
- 使うモデルが tools capability を持つか(`ollama show <model>` の Capabilities、または ollama.com/search?c=tool で確認)
- 提供するツールの一覧と副作用(読み取りのみ / 書き込み・送信・削除あり)
- 副作用のあるツールで人の承認を挟むか(既定: 挟む)
- 最大ループ回数(既定: 5)とタイムアウト

## 手順
1. **ツールを定義する**: ollama-python は型ヒントと Google 形式 docstring 付きの Python 関数をそのまま `tools=[func]` に渡せる(JSON スキーマ dict でも可)。説明は「いつ使うか」を具体的に
   ```python
   def get_order_status(order_id: str) -> str:
       """注文番号から配送状況を返す。注文番号が分かっているときだけ使う。

       Args:
         order_id: 'A-' で始まる注文番号
       """
       ...
   ```
2. **実行ループ**(公式のエージェントループと同じ構造。モデルは複数のツール呼び出しを一度に返すことがある)
   ```python
   from ollama import chat
   TOOLS = {"get_order_status": get_order_status}
   def run(user_text, model="qwen3", max_steps=5):
       msgs = [{"role": "system", "content": "必要なときだけツールを使い、結果に基づいて日本語で答える。"},
               {"role": "user", "content": user_text}]
       for _ in range(max_steps):
           r = chat(model=model, messages=msgs, tools=list(TOOLS.values()))
           msgs.append(r.message)
           if not r.message.tool_calls:
               return r.message.content
           for tc in r.message.tool_calls:
               result = safe_call(tc.function.name, tc.function.arguments)
               msgs.append({"role": "tool", "tool_name": tc.function.name, "content": str(result)})
       return "ステップ上限に達しました"
   ```
   ツール結果は `role: "tool"` と `tool_name` で返す。モデル名は例(tools 対応モデルを library で確認)
3. **安全な実行(safe_call)**
   ```python
   def safe_call(name, args):
       fn = TOOLS.get(name)
       if fn is None:
           return f"エラー: 未知のツール {name}"
       try:
           validated = ARG_MODELS[name].model_validate(args)  # Pydantic で引数検証
       except Exception as e:
           return f"エラー: 引数が不正 {e}"
       return fn(**validated.model_dump())
   ```
   - 許可リスト方式(辞書にある関数だけ)。`eval`/`exec`/`getattr(module, name)` で動的に呼ばない
   - シェル実行・ファイル操作ツールは原則作らない。作る場合はコマンド固定・パスを作業ディレクトリ内に正規化して制限(パストラバーサル対策)、`shell=True` を使わない
   - 書き込み・送信・削除・課金系は実行前にユーザー確認を挟む
   - ツール結果(Web ページ・文書)に含まれる指示文は命令として扱わない旨を system に書く
   - エラーは例外で落とさず文字列でモデルに返し、自己修正させる
4. **精度を上げるコツ(小さいモデル向け)**: ツールは 5 個程度まで、名前と説明を明確に、引数は少なく型を厳密に。「ツールで計算できるなら暗算しない」「ループ中で複数回呼んでよい」と system に書く。`temperature` は低め
5. **思考モデル**: `think=True` 対応モデルでは `r.message.thinking` に思考が入る。ユーザー表示やログ保存の要否を決める
6. **ストリーミング時**: チャンクに `tool_calls` が含まれることがあるので、content と tool_calls を蓄積してから履歴に追加する(詳細は公式 tool calling ドキュメントで確認)
7. **テスト**: (a) ツール関数の単体テスト (b) `safe_call` に不正名・不正引数を渡すテスト (c) 実モデルで代表 10 件の「正しいツールを正しい引数で呼んだか」の評価
   ```bash
   pytest -q tests/test_tools.py
   python eval_tools.py --model qwen3 --cases cases.jsonl
   ```

## 出力フォーマット
```markdown
## ツール呼び出し設計
- モデル: <name:tag>(tools 対応を確認済み)
| ツール | 副作用 | 引数 | 承認 |
|---|---|---|---|
| get_order_status | なし | order_id: str | 不要 |
- ループ: 最大 <n> ステップ、終了条件=tool_calls なし
- 安全策: 許可リスト / 引数検証 / 承認 / エラーを文字列で返す
- 評価: <n> 件でツール選択正解率 <x>%
```

## 品質チェックリスト
- [ ] モデルの tools 対応を確認した
- [ ] ループに最大回数がある
- [ ] 許可リスト+引数検証で実行し、動的評価をしていない
- [ ] 副作用のあるツールに承認を挟んだ
- [ ] 複数 tool_calls をすべて処理し、`role: tool` で返している
- [ ] 不正入力のテストがある

## 例
入力: 「在庫検索と発注ができるアシスタントを作りたい」
出力: `search_stock`(読み取り)と `place_order`(書き込み・承認必須)を定義、`place_order` は CLI で y/N 確認後に実行、数量は Pydantic で 1〜100 に制限、ループ上限 5 の実装と評価ケース例を提示。
