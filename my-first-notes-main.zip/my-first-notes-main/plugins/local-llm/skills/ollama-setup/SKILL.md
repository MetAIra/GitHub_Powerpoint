---
name: ollama-setup
description: Ollama のインストール・起動確認・モデルの pull/run/list/rm、保存先の変更、GPU/CPU どちらで動いているかの確認、ポートとリモート接続の安全な設定を手順化する。「Ollama を入れて動かしたい」「GPU が使われているか確認して」と言われたときに使う。
---

# Ollama セットアップと運用の基本

## 目的
ローカルで Ollama サーバーを安全に動かし、モデルの取得・実行・削除と動作確認(GPU 利用・メモリ)までを迷わず行えるようにする。外部公開による事故を防ぐ。

## 最初に確認すること
- OS(macOS / Windows / Linux / WSL2 / Docker)。不明なら `uname -a` 等で確認して進める
- GPU の有無と種類(NVIDIA / AMD / Apple Silicon / なし)。なしでも CPU で動く前提で進める
- ディスク空き容量(モデルは数 GB〜数十 GB)。保存先を変えたいか
- 他マシンから使う必要があるか(既定は「自分の PC からのみ」= 外部公開しない)

## 手順
1. **インストール**(公式: https://ollama.com/download)
   - macOS / Windows: インストーラを実行(アプリが常駐し自動更新)
   - Linux: `curl -fsSL https://ollama.com/install.sh | sh`(実行前にスクリプト内容を確認するのが望ましい)
   - Docker: `ollama/ollama` イメージ。NVIDIA GPU は nvidia-container-toolkit が必要、macOS の Docker では GPU 不可
2. **起動確認**
   ```bash
   ollama -v                          # バージョン
   curl http://localhost:11434/api/version   # サーバー応答
   ```
   応答がなければ `ollama serve` を別ターミナルで起動(Linux の systemd 版は `systemctl status ollama`)。
3. **モデル操作**(モデル名・タグは例。最新は https://ollama.com/library で確認)
   ```bash
   ollama pull gemma3:4b      # 取得(タグ省略時は latest)
   ollama run gemma3:4b "日本の首都は?"   # 単発実行(引数なしで対話モード、/bye で終了)
   ollama list                # 取得済みモデル(ls も可)
   ollama show gemma3:4b      # パラメータ数・量子化・コンテキスト長・capabilities
   ollama ps                  # メモリに載っているモデル
   ollama stop gemma3:4b      # 即アンロード
   ollama rm gemma3:4b        # 削除(容量回収)
   ```
4. **GPU/CPU の確認**: 推論中に `ollama ps` の `PROCESSOR` 列を見る
   - `100% GPU` = 全部 VRAM / `100% CPU` = システム RAM のみ / `48%/52% CPU/GPU` = 一部はみ出し(遅い)
   - はみ出す場合は小さいモデル・低ビット量子化・`num_ctx` 縮小を検討(→ `model-choice`)
   - NVIDIA は `nvidia-smi` で VRAM 使用量も確認。対応 GPU とドライバ要件は公式 GPU ドキュメント(docs.ollama.com)で確認
5. **保存先の変更**: 既定は macOS `~/.ollama/models`、Linux(公式インストーラ)`/usr/share/ollama/.ollama/models`、Windows `C:\Users\<user>\.ollama\models`。環境変数 `OLLAMA_MODELS` で変更。Linux では `sudo chown -R ollama:ollama <dir>` が必要
6. **環境変数の設定方法**(サーバー側の設定)
   - Linux(systemd): `sudo systemctl edit ollama.service` → `[Service]` に `Environment="OLLAMA_MODELS=/data/ollama"` → `systemctl daemon-reload && systemctl restart ollama`
   - macOS アプリ: `launchctl setenv 変数 値` → アプリ再起動
   - Windows: ユーザー環境変数を設定 → タスクバーから終了して再起動
7. **ポートとリモート接続(重要)**
   - 既定は `127.0.0.1:11434` にのみバインド。**Ollama の API には認証がない**ため、`OLLAMA_HOST=0.0.0.0` での LAN/インターネット公開は原則しない
   - 他端末から使いたい場合の優先順: (a) SSH ポートフォワード `ssh -L 11434:localhost:11434 user@host` (b) VPN(Tailscale 等)内に限定 + OS ファイアウォールで送信元制限 (c) 認証付きリバースプロキシ
   - ngrok 等のトンネルで公開するとモデルを第三者に使われ得る。行う場合はユーザーに明示的に確認する
   - ブラウザからのアクセス許可 `OLLAMA_ORIGINS` も必要最小限に
8. **その他の便利設定**: `OLLAMA_KEEP_ALIVE`(既定 5 分保持)、`OLLAMA_CONTEXT_LENGTH`、`OLLAMA_NUM_PARALLEL`。クラウド機能を使わないなら `OLLAMA_NO_CLOUD=1`(対応版のみ。公式 FAQ で確認)

## 出力フォーマット
```markdown
## Ollama セットアップ結果
- 環境: <OS> / GPU: <種類・VRAM> / Ollama: <バージョン>
- 起動確認: `curl localhost:11434/api/version` → <結果>
- 取得モデル: <name:tag>(<サイズ>)
- 実行場所: `ollama ps` → <100% GPU など>
- 保存先: <パス>(変更した場合は設定方法)
- 公開範囲: 127.0.0.1 のみ / <例外と対策>
- 次の一手: <モデル選び / Python から呼ぶ など>
```

## 品質チェックリスト
- [ ] `ollama -v` と `/api/version` の両方で起動を確認した
- [ ] `ollama ps` の PROCESSOR 列で GPU/CPU を確認した
- [ ] モデル名を例示にとどめ、ollama.com/library での確認を促した
- [ ] `OLLAMA_HOST=0.0.0.0` やトンネル公開をユーザー確認なしに勧めていない
- [ ] `ollama rm` や保存先移動などディスク操作の前に対象を確認した

## 例
入力: 「Ubuntu に入れたけど遅い。GPU 使えてる?」
出力: `ollama ps` で `100% CPU` と判明 → `nvidia-smi` でドライバ確認、`journalctl -u ollama` のログで GPU 検出失敗を確認 → ドライバ更新後 `systemctl restart ollama`、再度 `ollama ps` が `100% GPU` になることを確認、の手順を提示。
