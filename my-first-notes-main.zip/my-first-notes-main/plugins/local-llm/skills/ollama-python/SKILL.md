---
name: ollama-python
description: Python の ollama パッケージで chat / generate / ストリーミング / 非同期 / 会話履歴管理 / options 指定 / エラー処理を正しく書くための型と確認方法を示す。「Python から Ollama を呼びたい」「ストリーミングで表示したい」と言われたときに使う。
---

# Python から Ollama を使う(ollama パッケージ)

## 目的
`pip install ollama` の公式ライブラリで、ローカル Ollama サーバーを安全・確実に呼び出すコードを最小構成で書く。会話履歴の肥大化や接続先の取り違えなどの典型的な不具合を避ける。

## 最初に確認すること
- Ollama サーバーが起動しているか(`curl localhost:11434/api/version`)、使うモデルを pull 済みか(→ `ollama-setup`)
- 同期か非同期か(Web アプリ・並列処理なら `AsyncClient`)
- 単発の生成か、会話(履歴あり)か
- 接続先(既定 `http://localhost:11434`。別ホストは `OLLAMA_HOST` 環境変数か `Client(host=...)`)
- 不明なら「同期・chat・ストリーミングなし」を既定とする

## 手順
1. インストールと確認: `pip install -U ollama`(Python 3.8+。uv なら `uv add ollama`)→ `python -c "import ollama; print(ollama.list())"`
2. **chat(推奨の基本形)**。レスポンスは `response.message.content` でも `response['message']['content']` でも読める
   ```python
   from ollama import chat
   MODEL = "gemma3:4b"  # 例。ollama list にあるものを使う
   r = chat(model=MODEL, messages=[
       {"role": "system", "content": "簡潔に日本語で答える"},
       {"role": "user", "content": "空はなぜ青い?"},
   ], options={"temperature": 0.2, "num_ctx": 8192})
   print(r.message.content)
   ```
3. **generate**: 履歴不要の単発処理(要約・分類)向け。`ollama.generate(model=MODEL, prompt="...")` → `r.response`
4. **ストリーミング**: `stream=True` でジェネレータになる
   ```python
   for chunk in chat(model=MODEL, messages=msgs, stream=True):
       print(chunk.message.content, end="", flush=True)
   ```
   最後のチャンク(`done=True`)に `eval_count` / `eval_duration`(ナノ秒)が入るので、速度は `eval_count / eval_duration * 1e9` tokens/s
5. **非同期**: `AsyncClient` を使う。`stream=True` では `async for part in await client.chat(...)`
   ```python
   import asyncio
   from ollama import AsyncClient
   async def main():
       client = AsyncClient()  # host= で接続先指定
       r = await client.chat(model=MODEL, messages=[{"role": "user", "content": "こんにちは"}])
       print(r.message.content)
   asyncio.run(main())
   ```
   並列数はサーバー側 `OLLAMA_NUM_PARALLEL` に依存。`asyncio.Semaphore` でクライアント側も絞る
6. **会話履歴の管理**: assistant の返答も messages に追加して次に渡す。コンテキスト長を超えると古い部分が切り捨てられるので、system を残して直近 N 往復に制限する
   ```python
   history = [{"role": "system", "content": SYSTEM}]
   def ask(text, max_turns=10):
       history.append({"role": "user", "content": text})
       r = chat(model=MODEL, messages=[history[0]] + history[1:][-max_turns*2:])
       history.append({"role": "assistant", "content": r.message.content})
       return r.message.content
   ```
   長期の会話は古い部分を要約して system に畳み込む方式も有効
7. **よく使う引数**: `options`(temperature, top_p, num_ctx, num_predict, seed, stop など Modelfile の PARAMETER と同じ名前)、`format`(→ `structured-output`)、`tools`(→ `tool-calling`)、`keep_alive`("10m"、0 で即アンロード)、`think`(思考対応モデルのみ)
8. **エラー処理**
   ```python
   import ollama, httpx
   try:
       r = ollama.chat(model=MODEL, messages=msgs)
   except ollama.ResponseError as e:      # 404=モデル未取得 など
       if e.status_code == 404:
           raise SystemExit(f"`ollama pull {MODEL}` を実行してください")
       raise
   except (httpx.ConnectError, ConnectionError):  # サーバー未起動
       raise SystemExit("Ollama が起動していません(ollama serve)")
   ```
   自動 `ollama.pull()` は大容量ダウンロードになるので、勝手に行わずユーザーに確認する。503 は過負荷(キュー満杯)なので待って再試行
9. **テスト**: 単体テストでは `ollama.chat` をモックし、実サーバーを使う結合テストは `pytest -m ollama` などマーカーで分離。CI では小さいモデルを使うかスキップ。長いログの要約は token-saver の `log-digest` に任せてよい

## NG 例
- assistant 応答を履歴に追加し忘れ、文脈が毎回リセットされる
- `Client(host=...)` にトークンや社内 URL を直書き → 環境変数から読む
- ストリーミングで `print` に `flush=True` がなく表示が遅れる
- `num_ctx` を毎回変える → モデルの再ロードが走り遅くなる。固定する

## 出力フォーマット
```markdown
## 実装方針
- 呼び出し: chat / generate、同期 / 非同期、stream 有無
- モデル: <name:tag>(環境変数 OLLAMA_MODEL で切替)
- options: temperature=<>, num_ctx=<>
- 履歴: 直近 <N> 往復 + system
- エラー: 404 / 接続不可 / 503 の扱い
- 確認: `python app.py` → <期待出力>、`pytest -q`
```

## 品質チェックリスト
- [ ] サーバー起動とモデル取得を事前確認する手順がある
- [ ] 履歴に assistant 応答を追加し、上限を設けた
- [ ] `ResponseError` と接続エラーを区別して扱った
- [ ] 接続先・モデル名を環境変数化し、秘密情報を直書きしていない
- [ ] 動作確認コマンドとテストの分離方法を示した

## 例
入力: 「FastAPI でストリーミング返答したい」
出力: `AsyncClient().chat(..., stream=True)` を `async for` で回し `StreamingResponse` で返す 20 行程度の例、`curl -N` での確認方法、Semaphore での同時実行制限を提示。
