---
name: modelfile
description: Ollama の Modelfile(FROM、SYSTEM、PARAMETER、TEMPLATE、MESSAGE)を書いて ollama create で独自モデルを作る手順と、よくある失敗を示す。「専用のシステムプロンプト入りモデルを作りたい」「GGUF を Ollama に取り込みたい」と言われたときに使う。
---

# Modelfile で独自モデルを作る

## 目的
システムプロンプト・生成パラメータ・少数例を焼き込んだ派生モデルを作り、`ollama run <名前>` だけで同じ挙動を再現できるようにする。Modelfile はリポジトリで管理する。

## 最初に確認すること
- ベースモデル(library のモデル名:タグ / GGUF ファイル / Safetensors ディレクトリ)
- 目的(役割固定、出力形式の固定、温度などの既定値、コンテキスト長)
- TEMPLATE を変える必要があるか(**通常は不要**。ベースモデルのものを継承する)
- 作成するモデル名(例: `jp-summarizer`)。未指定なら用途名で作る

## 手順
1. ベースの設定を確認する
   ```bash
   ollama show --modelfile <base>     # 現在の TEMPLATE / PARAMETER / stop
   ollama show <base>                 # コンテキスト長・capabilities
   ```
2. Modelfile を書く(命令は大文字小文字を区別しないが大文字で書くのが慣例。順序は自由だが FROM を先頭に)
   ```
   FROM gemma3:4b
   PARAMETER temperature 0.3
   PARAMETER num_ctx 8192
   PARAMETER stop "<END>"
   SYSTEM """あなたは社内文書の要約担当です。
   - 出力は日本語の常体、箇条書き3〜5点
   - 原文にない情報は書かない。不明なら「記載なし」と書く"""
   MESSAGE user 次の文を要約: 会議は来週火曜に延期。資料は金曜までに共有。
   MESSAGE assistant - 会議は来週火曜に延期
   - 資料共有の期限は金曜
   ```
3. 作成と動作確認
   ```bash
   ollama create jp-summarizer -f ./Modelfile
   ollama run jp-summarizer "要約: ..."
   ollama show --modelfile jp-summarizer   # 反映を確認
   ```
4. 主な命令
   | 命令 | 用途 | 注意 |
   |---|---|---|
   | FROM(必須) | ベース。`name:tag`、`./model.gguf`(Modelfile からの相対/絶対)、Safetensors ディレクトリ | 分割 GGUF はワイルドカード可 |
   | PARAMETER | `temperature` `num_ctx` `top_k` `top_p` `min_p` `repeat_penalty` `seed` `stop` `num_predict` など | `stop` は複数行で複数指定 |
   | SYSTEM | 既定のシステムメッセージ | API で system を渡すとそちらが優先される |
   | MESSAGE | 少数例(user/assistant/system) | 例は短く、実際の入力形式に合わせる |
   | TEMPLATE | Go template で全体のプロンプト形式 | 変数 `{{ .System }}` `{{ .Prompt }}` `{{ .Response }}`。モデル固有の特殊トークンを壊しやすい |
   | LICENSE / REQUIRES | ライセンス表記 / 必要な Ollama バージョン | |
   既定値や追加パラメータは版で変わるので公式 Modelfile リファレンス(docs.ollama.com/modelfile)で確認する
5. GGUF を取り込む場合: `FROM ./xxx.gguf` で create。TEMPLATE がないと会話形式が崩れることがあるので、同系統の library モデルの `show --modelfile` を参考に TEMPLATE と stop を写す。入手元とライセンスを確認する
6. Python からも作成できる: `ollama.create(model='jp-summarizer', from_='gemma3:4b', system='...')`(引数は ollama-python README で確認)
7. 更新したら同じ名前で再度 `ollama create`。不要になったら `ollama rm <名前>`

## よくある失敗(NG 例)
- TEMPLATE を独自に書き換えて特殊トークンが崩れ、出力が途切れる・延々続く → TEMPLATE は消してベースを継承
- SYSTEM が長すぎ、小さいモデルが指示を落とす → 箇条書き 5 行程度に絞る(→ `prompt-tuning`)
- `num_ctx` を大きくしすぎて CPU にはみ出す → `ollama ps` で確認
- MESSAGE の例と実際の出力形式が食い違う → 例を正とみなして真似るので揃える

## 出力フォーマット
````markdown
## Modelfile 案: <モデル名>
- ベース: <name:tag>(ollama.com/library で最新を確認)
- 狙い: <...>
```
<Modelfile 本文>
```
- 作成: `ollama create <名前> -f ./Modelfile`
- 確認: `ollama run <名前> "<テスト入力>"` → 期待: <...>
````

## 品質チェックリスト
- [ ] `ollama show --modelfile <base>` で元の設定を確認した
- [ ] TEMPLATE を不用意に上書きしていない
- [ ] SYSTEM は具体的で短い。出力形式を明示した
- [ ] create 後に run と show で反映を確認した
- [ ] Modelfile をリポジトリで管理し、秘密情報を含めていない

## 例
入力: 「コミットメッセージを日本語で1行生成する専用モデルがほしい」
出力: `FROM <小さめのコード系モデル>`、`PARAMETER temperature 0.2`、`PARAMETER num_predict 60`、SYSTEM に「72字以内・体言止め・接頭辞 feat/fix」、MESSAGE で diff→1行の例を 2 組。作成・確認コマンド付き。
