---
name: encode-benchmark
description: ffmpeg のエンコード設定(CRF・プリセット・コーデック・GPU など)ごとに、速度・ファイルサイズ・画質(VMAF / SSIM / PSNR)を同じ条件で測って比較表を作ります。「x264 と NVENC、どっちがいいか数字で比べたい」「CRF をいくつにすべきか VMAF で決めたい」のような依頼で使います。
---

# エンコード設定のベンチマーク

## 目的
「なんとなく速い・きれい」ではなく、同じ素材・同じ区間で計測した数値を並べ、目的(サイズ上限・画質下限・時間)を満たす設定を選ぶ。設定の候補出しは `encode-optimizer` エージェント、GPU は `gpu-encode` を参照。

## 最初に確認すること
- **比較したい設定**: 2〜6 個に絞る(例: libx264 CRF 20/23/26、h264_nvenc cq 23)
- **判断基準**: 既定は「VMAF 93 以上で最小サイズ」。速度に上限があれば(例: 実時間の 2 倍以内)併記
- **素材**: 代表的な内容を含む 30〜60 秒を 2〜3 か所(動きの激しい場面・暗い場面・静止画に近い場面)。全編は不要
- **ビルド**: VMAF は `libvmaf` 付きビルドが必要。`ffmpeg -hide_banner -filters | grep -E "libvmaf|ssim|psnr"` で確認。無ければ SSIM / PSNR のみで比較し、その旨を明記
- **権利**: 他人の動画を素材に使う場合は社内検証の範囲にとどめる

## 手順
1. **参照区間を切り出す**(以後すべてこのファイルを入力にする)。再エンコードなしで切るとキーフレームに合わせて開始がずれるため、可逆に近い形で作る。
   ```bash
   mkdir -p bench
   ffmpeg -hide_banner -n -ss 00:10:00 -i "in.mp4" -t 60 -an -c:v libx264 -crf 0 -preset ultrafast "bench/ref.mkv"
   ```
2. **各設定でエンコードし、時間を記録**: `-benchmark` で実時間(rtime)が出る。他の重い処理を止め、同じ設定を 2 回測って速い方か平均を採る。
   ```bash
   ffmpeg -hide_banner -n -benchmark -i "bench/ref.mkv" -c:v libx264 -preset medium -crf 23 "bench/x264_crf23.mp4"
   ffmpeg -hide_banner -n -benchmark -i "bench/ref.mkv" -c:v h264_nvenc -preset p5 -cq 23 "bench/nvenc_cq23.mp4"
   ```
   GPU エンコーダーはビルド・GPU・ドライバに依存する。使えない環境ではその行を省き、表に「未計測」と書く。
3. **サイズ**: ファイルサイズ(バイト)と平均ビットレート(`ffprobe -v error -show_entries format=bit_rate -of csv=p=0 file`)。
4. **画質を測る**: 1 番目の入力が評価対象(distorted)、2 番目が参照(reference)。解像度・フレーム数をそろえる。
   ```bash
   ffmpeg -hide_banner -i "bench/x264_crf23.mp4" -i "bench/ref.mkv" \
     -lavfi "[0:v]setpts=PTS-STARTPTS[d];[1:v]setpts=PTS-STARTPTS[r];[d][r]libvmaf=log_fmt=json:log_path=bench/x264_crf23_vmaf.json:n_threads=4" \
     -f null -
   ffmpeg -hide_banner -i "bench/x264_crf23.mp4" -i "bench/ref.mkv" -lavfi "[0:v][1:v]ssim=stats_file=bench/x264_crf23_ssim.log" -f null -
   ffmpeg -hide_banner -i "bench/x264_crf23.mp4" -i "bench/ref.mkv" -lavfi "[0:v][1:v]psnr=stats_file=bench/x264_crf23_psnr.log" -f null -
   ```
   - 縮小した設定を比べるときは、評価対象を参照の解像度へ `scale` で戻してから比べる(VMAF の既定モデルは 1080p 視聴を想定)
   - 平均値は stderr の最後(`SSIM ... All:` / `PSNR ... average:`)に出る。フレームごとの値は stats_file に残る
   - libvmaf の `feature=name=psnr` を使うと VMAF と同時に PSNR も取れる(公式ドキュメントの例)
   - Windows の PowerShell では `-f null NUL` でも可。`-` は全 OS で使える
5. **目安**: VMAF 95 以上 ほぼ見分けがつかない / 93 前後 一般的な配信品質 / 85 未満 劣化が見えやすい(あくまで目安。素材と視聴環境で変わる)。SSIM は 0.98 以上、PSNR は 40dB 以上が高画質の目安。平均値だけでなく VMAF の最小値や 5 パーセンタイル(json ログ)も見る。
6. **目視確認**: 数値が近い候補は、暗部・グラデーション・細かい模様の場面を並べて見る(`ffplay` で同じ時刻)。指標は目視の代わりではない。
7. **表にまとめて推奨を出す**。長いログは token-saver の `log-digest` で要約できる。

## 出力フォーマット
```markdown
## エンコード比較(素材: in.mp4 10:00〜11:00、1080p30、ffmpeg x.y / libvmaf あり)
| 設定 | 時間(s) | 速度 | サイズ(MB) | ビットレート | VMAF 平均 / 最小 | SSIM | PSNR |
|---|---|---|---|---|---|---|---|
| libx264 medium CRF23 | 41.2 | 1.46x | 38.5 | 5.1M | 94.8 / 86.1 | 0.985 | 41.9 |
| h264_nvenc p5 cq23 | 6.3 | 9.5x | 47.9 | 6.4M | 94.1 / 84.0 | 0.983 | 41.2 |

**推奨**: (基準「VMAF 93 以上で最小サイズ」なら libx264 CRF23。時間優先なら NVENC、サイズ +24%)
**注意**: 2 回計測の平均。GPU 結果はドライバ 5xx / RTX xxxx での値
```

## 品質チェックリスト
- [ ] 全設定で同じ参照区間・同じマシン・同じ負荷条件で測った
- [ ] VMAF の入力順(評価対象が先、参照が後)を守り、解像度とフレーム数をそろえた
- [ ] libvmaf / GPU がビルドにない場合に「未計測」と明記した
- [ ] 平均値だけでなく最小値も見た
- [ ] 判断基準に沿った推奨を 1 つ示した
- [ ] 出力は bench/ に分け、元ファイルを上書きしない

## 例
**入力**: 「講義動画(スライド中心)を最小サイズで残したい。x264 の CRF をいくつにすべき?」
**出力**: スライド・板書・人物が映る 3 区間で CRF 23/26/29/32 を計測する手順と上記コマンド、「動きが少ない素材は高い CRF でも VMAF が下がりにくいので、VMAF 93 を下回らない最大 CRF を採用」という判断方法を返す。
