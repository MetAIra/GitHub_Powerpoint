---
name: hls-dash
description: ffmpeg で動画を HLS(.m3u8)や MPEG-DASH(.mpd)の配信用に変換します。セグメント長、キーフレーム間隔、複数ビットレート(ABR)、マスタープレイリストの作り方と再生確認まで扱います。「動画を HLS にしてサイトで配信したい」「1080p/720p/480p の複数画質の m3u8 を作って」のような依頼で使います。
---

# HLS / DASH の配信用変換

## 目的
Web やアプリで途切れにくく再生できる配信用ファイル一式(プレイリスト+セグメント)を作る。複数画質を用意し、プレイヤーが回線に合わせて切り替えられるようにする。

## 最初に確認すること
- **方式**: 既定は HLS(Safari / iOS がネイティブ対応、他は hls.js 等で再生)。DASH は Android / 対応プレイヤー向け。両方なら fMP4 セグメントで共通化を検討
- **VOD かライブか**: 既定は VOD(`-hls_playlist_type vod`)
- **画質の段数**: 既定は 1080p 5Mbps / 720p 3Mbps / 480p 1.2Mbps(H.264、音声 AAC 128k)。元動画より高い解像度は作らない
- **セグメント長**: 既定 6 秒(短いほど切り替えが速いがファイル数とリクエストが増える)
- **配信先**: 自前サーバー / CDN / オブジェクトストレージ。MIME タイプと CORS 設定が必要
- **保護**: DRM や暗号化が必要か(AES-128 は `hls_key_info_file`。鍵ファイルをリポジトリや公開フォルダに置かない)
- **権利**: 配信する動画・音楽の配信権を確認

## 手順
1. **エンコーダーを確認**: `ffmpeg -hide_banner -encoders | grep -E "libx264|aac"`。libfdk_aac はビルドにないことが多いので既定は内蔵の `aac`。GPU を使うなら `gpu-encode` を参照(ハードウェアエンコードはビルド・GPU・ドライバ依存)。
2. **キーフレームをセグメント境界にそろえる**: hls muxer は `hls_time` 経過後の「次のキーフレーム」で切る(公式ドキュメント)。全画質でキーフレーム位置をそろえるため、GOP を固定しシーンチェンジでの挿入を止める。30fps・6 秒なら `-g 180 -keyint_min 180 -sc_threshold 0`、または `-force_key_frames "expr:gte(t,n_forced*6)"`。
3. **複数ビットレートの HLS を一度に作る**(`-var_stream_map` と `%v`、`-master_pl_name`)
   ```bash
   mkdir -p hls/1080p hls/720p hls/480p
   ffmpeg -hide_banner -n -i "in.mp4" \
     -filter_complex "[0:v]split=3[v1][v2][v3];[v1]scale=-2:1080[v1o];[v2]scale=-2:720[v2o];[v3]scale=-2:480[v3o]" \
     -map "[v1o]" -map "[v2o]" -map "[v3o]" -map 0:a -map 0:a -map 0:a \
     -c:v libx264 -preset medium -profile:v main -g 180 -keyint_min 180 -sc_threshold 0 \
     -b:v:0 5000k -maxrate:v:0 5350k -bufsize:v:0 7500k \
     -b:v:1 3000k -maxrate:v:1 3210k -bufsize:v:1 4500k \
     -b:v:2 1200k -maxrate:v:2 1280k -bufsize:v:2 1800k \
     -c:a aac -b:a 128k -ac 2 \
     -f hls -hls_time 6 -hls_playlist_type vod -hls_flags independent_segments \
     -hls_segment_filename "hls/%v/seg_%05d.ts" \
     -master_pl_name master.m3u8 -var_stream_map "v:0,a:0,name:1080p v:1,a:1,name:720p v:2,a:2,name:480p" \
     "hls/%v/index.m3u8"
   ```
   - `%v` がディレクトリ名にあるとサブフォルダが作られる(公式ドキュメント)
   - fMP4 セグメントにするなら `-hls_segment_type fmp4`(DASH とセグメントを共有しやすい)
   - 音声のない動画では `-map 0:a` と `a:N` を外す
4. **DASH を作る**(adaptation set で映像と音声を分ける)
   ```bash
   ffmpeg -hide_banner -n -i "in.mp4" -map 0:v -map 0:v -map 0:a \
     -c:v libx264 -g 180 -keyint_min 180 -sc_threshold 0 \
     -b:v:0 3000k -s:v:0 1280x720 -b:v:1 1200k -s:v:1 854x480 -c:a aac -b:a 128k \
     -use_template 1 -use_timeline 1 -seg_duration 6 \
     -adaptation_sets "id=0,streams=v id=1,streams=a" -f dash "dash/manifest.mpd"
   ```
   (`dash/` は事前に作成。`-s` 指定は入力のアスペクト比が 16:9 の場合の例)
5. **検証**
   - 各プレイリストを開き、`#EXT-X-TARGETDURATION` が想定(6〜7)で、`#EXTINF` がほぼ一定か確認
   - `ffprobe -v error -show_entries format=duration -of csv=p=0 "hls/720p/index.m3u8"` で長さが元と一致するか
   - ローカル再生: `ffplay "hls/master.m3u8"`、ブラウザは `python -m http.server` で配信して Safari や hls.js のデモで再生
   - 画質の切り替えはブラウザの開発者ツールで回線を絞って確認
6. **配信設定**: `.m3u8` は `application/vnd.apple.mpegurl`、`.ts` は `video/mp2t`、`.mpd` は `application/dash+xml`。別ドメインから再生するなら CORS を許可。

## 出力フォーマット
```markdown
### 配信用変換の設定
- 方式: HLS(VOD, TS セグメント 6 秒)
- 画質: 1080p 5M / 720p 3M / 480p 1.2M(H.264 main)+ AAC 128k
- キーフレーム: GOP 180(30fps × 6 秒)、sc_threshold 0
- 出力構成: hls/master.m3u8, hls/{1080p,720p,480p}/index.m3u8 + seg_00000.ts…
- コマンド: ...
- 検証: TARGETDURATION=6、長さ一致、ffplay で再生 OK
- サーバー設定: MIME / CORS
```

## 品質チェックリスト
- [ ] GOP 長がセグメント長 × fps と一致し、全画質でそろっている
- [ ] 元の解像度を超える画質を作っていない
- [ ] マスタープレイリストがあり、各画質の BANDWIDTH が入っている
- [ ] 出力先が空のフォルダ(既存セグメントと混ざらない)で、`-n` を付けた
- [ ] 実際にプレイヤーで再生・画質切り替えを確認した
- [ ] 暗号化鍵を公開場所やリポジトリに置いていない

## 例
**入力**: 「社内研修の 1080p 動画(30fps)を Web で配信したい。モバイル回線でも見られるように」
**出力**: 上の 3 段 HLS コマンド(GOP 180)、出力のフォルダ構成、`python -m http.server` + hls.js での確認手順、MIME 設定、Windows の PowerShell では行継続を `` ` `` にする注意を返す。
