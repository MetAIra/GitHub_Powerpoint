---
name: long-video-split
description: 数時間の長い動画を ffmpeg の segment muxer などで分割し、分割したまま並列処理したり、最後に concat で再結合したりする手順を作ります。キーフレームと分割位置の関係、再結合時の音ズレ・映像の乱れの防止まで扱います。「3 時間の配信アーカイブを 10 分ごとに分けたい」「分割して並列エンコードしてから 1 本に戻したい」のような依頼で使います。
---

# 長時間動画の分割と再結合

## 目的
長い動画を扱いやすい長さに分ける、または分割→並列エンコード→結合で全体の処理時間を短くする。その際に「切れ目でのコマ落ち・黒画面」「結合後の音ズレ」を起こさない。

## 最初に確認すること
- **目的**: ①アップロード上限などに合わせて分けるだけ(再エンコードなし)/ ②分割して並列エンコード後に 1 本へ戻す
- **分割の基準**: 時間(既定 600 秒)/ 指定時刻 / ファイルサイズ
- **正確さ**: 再エンコードなし(`-c copy`)はキーフレームでしか切れないので、指定時刻から数秒ずれる。秒単位で正確に切るなら再エンコードが必要
- **入力の性質**: 可変フレームレート(スマホ・画面録画)か。`ffprobe` で `r_frame_rate` と `avg_frame_rate` が大きく違えば VFR で、音ズレの原因になりやすい
- **権利**: 他人の配信・番組の切り抜きは権利確認が必要

## 手順
1. **入力を調べる**
   ```bash
   ffprobe -v error -show_entries format=duration:stream=index,codec_type,codec_name,r_frame_rate,avg_frame_rate -of compact "in.mp4"
   # キーフレームの時刻(先頭 20 個)
   ffprobe -v error -select_streams v:0 -skip_frame nokey -show_entries frame=pts_time -of csv=p=0 "in.mp4" | head -20
   ```
2. **再エンコードなしで分割**(segment muxer)
   ```bash
   mkdir -p parts
   ffmpeg -hide_banner -n -i "in.mp4" -map 0 -c copy -f segment -segment_time 600 \
     -reset_timestamps 1 -segment_list "parts/list.csv" "parts/part_%03d.mp4"
   ```
   - 各セグメントは参照ストリームのキーフレームから始まる。キーフレーム間隔が長い動画ほど、長さがばらつく(公式ドキュメント)
   - `-reset_timestamps 1` で各ファイルの時刻を 0 始まりにする(単体で再生・編集しやすい)
   - 字幕やデータストリームで失敗する場合は `-map 0:v -map 0:a` に絞る
3. **時刻どおりに切る必要がある場合**: 再エンコードしながらキーフレームを強制する。
   ```bash
   ffmpeg -hide_banner -n -i "in.mp4" -c:v libx264 -crf 20 -force_key_frames "expr:gte(t,n_forced*600)" \
     -c:a aac -b:a 192k -f segment -segment_time 600 -reset_timestamps 1 "parts/part_%03d.mp4"
   ```
4. **並列エンコード(目的②)**: 各パートを同じ設定(コーデック・解像度・fps・ピクセルフォーマット・音声のサンプルレートとチャンネル数)で変換する。並列数は `parallel-encode`、GPU は `gpu-encode` を参照。VFR 入力は分割前に `-fps_mode cfr -r 30` などで固定フレームレート化しておくと結合時のズレが減る。
5. **再結合**(concat demuxer、再エンコードなし)
   ```bash
   # list.txt(1 行 1 ファイル、パスは list.txt からの相対)
   # file 'enc_000.mp4'
   # file 'enc_001.mp4'
   ffmpeg -hide_banner -n -f concat -i "parts/list.txt" -c copy -movflags +faststart "joined.mp4"
   ```
   - 全ファイルが同じストリーム構成(同じコーデック・タイムベース等)であることが条件(公式ドキュメント)
   - 既定の `-safe 1` では空白や日本語を含むパス・絶対パスが拒否される。ファイル名を英数字にするのが確実。`-safe 0` は内容を自分で作ったリストに限る(外部から受け取ったリストに使わない)
   - list.txt は Python 等で生成し、`'` を含む名前は `'\''` にエスケープする
6. **音ズレ・乱れの防止**
   - 音声は AAC 再エンコード時に各パート先頭に無音の余白(priming)が入り、結合点ごとに数十 ms ずつずれることがある。気になる場合は映像だけ分割エンコードし、音声は元から 1 本で作って最後に `-map` で合わせる
   - 結合後に「開始時刻が負」「DTS 非単調」の警告が多数出る場合は、各パートを `-reset_timestamps 1` で作り直す
7. **検証**: 結合後の長さが元と ±0.5 秒以内か、結合点の前後 5 秒を再生して確認(`ffplay -ss 595 "joined.mp4"`)。音声と映像の長さを個別に比べる:
   `ffprobe -v error -show_entries stream=codec_type,duration -of compact "joined.mp4"`

## 出力フォーマット
```markdown
### 分割・結合の手順
- 入力: in.mp4(3:02:15、H.264 CFR 30fps、キーフレーム間隔 約 2 秒)
- 方式: -c copy で 600 秒ごとに分割(誤差はキーフレーム間隔分)
- コマンド: 1) 分割 2) 各パート処理 3) concat
- 結合時の条件: 全パート同一設定(H.264 / yuv420p / 30fps / AAC 48kHz 2ch)
- 検証: 長さ差 0.2 秒、結合点 18 か所の目視 OK
```

## 品質チェックリスト
- [ ] `-c copy` ではキーフレームでしか切れないことを説明した
- [ ] VFR かどうかを確認した
- [ ] 結合する全パートの設定がそろっている
- [ ] concat の `-safe` の扱いとファイル名の制約を説明した
- [ ] 元ファイルを上書きせず、出力フォルダを分けて `-n` を付けた
- [ ] 結合後の長さと結合点を確認した

## 例
**入力**: 「4 時間のゲーム配信録画(OBS、MKV)を YouTube 用に 1 時間ずつ MP4 にしたい」
**出力**: ffprobe での VFR / キーフレーム確認、`-c copy -f segment -segment_time 3600 -reset_timestamps 1 parts/part_%02d.mp4` のコマンド、「キーフレーム間隔(OBS 既定は 2 秒程度)の分だけずれます」という説明を返す。PowerShell では行継続が `` ` `` になる点も添える。
