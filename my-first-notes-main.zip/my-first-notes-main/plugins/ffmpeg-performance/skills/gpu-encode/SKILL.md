---
name: gpu-encode
description: ffmpeg で GPU(NVIDIA NVENC / Intel QSV / Linux の VAAPI / macOS の VideoToolbox)を使ったエンコードとハードウェアデコードのコマンドを作ります。使えるかの確認方法、画質と速度のトレードオフ、CPU エンコードとの比較の仕方まで扱います。「ffmpeg で GPU を使って速く変換したい」「NVENC のおすすめ設定を教えて」のような依頼で使います。
---

# GPU エンコード(NVENC / QSV / VAAPI / VideoToolbox)

## 目的
ハードウェアエンコーダーで変換時間を短くしつつ、画質・サイズの劣化を許容範囲に収める。**ハードウェアエンコードは ffmpeg のビルド、GPU の世代、ドライバ(と OS)の三つがそろって初めて使える**ため、必ず実機で確認してから設定を決める。設定比較は `encode-benchmark`、同時実行数は `parallel-encode`、環境に合わせた提案は `encode-optimizer` エージェントへ。

## 最初に確認すること
- **OS と GPU**: Windows / Linux / macOS、GPU の型番(NVIDIA は `nvidia-smi`、Intel/AMD は `lspci | grep -i vga`、macOS は「このMacについて」)
- **優先するもの**: 速度 / 画質 / サイズ。既定は「CPU(libx264 CRF 23)と同等の見た目で、なるべく速く」
- **コーデック**: 既定は H.264(互換性重視)。サイズ重視なら HEVC / AV1(GPU 世代が対応しているか要確認)
- **用途**: 保存・アーカイブ用なら CPU エンコード(libx264 / libx265 の slow 系)の方が同じビットレートで画質が良いことが多い。GPU は速度重視・大量処理・配信向き
- **権利**: 他人の動画の変換・再配布は権利確認が必要

## 手順
1. **ビルドが対応しているか確認**
   ```bash
   ffmpeg -hide_banner -hwaccels                      # デコード用のハードウェアアクセラレーション一覧
   ffmpeg -hide_banner -encoders | grep -E "nvenc|qsv|vaapi|videotoolbox"
   ffmpeg -hide_banner -h encoder=h264_nvenc          # そのエンコーダーのオプション一覧
   ```
   PowerShell では `grep` の代わりに `| Select-String "nvenc|qsv"`。`-hwaccels` は「ビルドに含まれる」一覧で、実際に動くかはハードウェアとドライバ次第(公式ドキュメント)。
2. **実際に動くか 5 秒で試す**(エラーが出なければ使える)
   ```bash
   ffmpeg -hide_banner -n -f lavfi -i testsrc2=duration=5:size=1920x1080:rate=30 -c:v h264_nvenc test_nvenc.mp4
   ```
3. **エンコーダー別の基本形を選ぶ**(品質指定はビットレート固定より品質固定を既定にする)
   | 方式 | 環境 | エンコード例 | 品質の指定 |
   |---|---|---|---|
   | NVENC | NVIDIA | `-c:v hevc_nvenc -preset p5 -tune hq -rc vbr -cq 26 -b:v 0` | `-cq` 0〜51(小さいほど高画質)、`-preset p1`(速)〜`p7`(高画質)、既定 p4 |
   | QSV | Intel | `-c:v h264_qsv -preset slow -global_quality 25` | `-global_quality` 1〜51(ICQ、小さいほど高画質) |
   | VAAPI | Linux(Intel/AMD) | `-c:v h264_vaapi -rc_mode CQP -qp 25` | ドライバが対応する rc_mode のみ使える |
   | VideoToolbox | macOS | `-c:v hevc_videotoolbox -q:v 60` または `-b:v 6M` | `-q:v`(1〜100、大きいほど高画質)は Apple Silicon のみ。Intel Mac は `-b:v` |
4. **デコードもハードウェアで行う**: 入力の前に `-hwaccel` を置く。フレームを GPU メモリに置いたまま渡すと CPU とのコピーが減る。
   ```bash
   # NVIDIA: デコード→リサイズ→エンコードを GPU 内で完結
   ffmpeg -hide_banner -n -hwaccel cuda -hwaccel_output_format cuda -i "in.mp4" \
     -vf "scale_cuda=1280:-2" -c:v h264_nvenc -preset p5 -cq 23 -c:a copy "out/in_720p.mp4"
   # Linux VAAPI: ソフトウェアデコードしたフレームを GPU へアップロード
   ffmpeg -hide_banner -n -init_hw_device vaapi=va:/dev/dri/renderD128 -filter_hw_device va \
     -i "in.mp4" -vf "format=nv12,hwupload" -c:v h264_vaapi -qp 25 "out/in_vaapi.mp4"
   # macOS
   ffmpeg -hide_banner -n -hwaccel videotoolbox -i "in.mov" -c:v hevc_videotoolbox -q:v 60 -tag:v hvc1 "out/in.mp4"
   ```
   - `-hwaccel_output_format cuda` のまま CPU 用フィルター(`scale` や `drawtext`)を使うとエラーになる。GPU 用フィルター(`scale_cuda` など、ビルドに含まれる場合)に替えるか、`hwdownload,format=nv12` で CPU に戻す
   - 公式ドキュメントにある通り、`-hwaccel` は再生向けの機能で、デコードだけなら最新 CPU より速いとは限らない。効果は計測して判断する
5. **画質と速度のトレードオフを計測**: 同じ 30〜60 秒の区間を CPU(libx264 CRF 23)と GPU 設定で作り、時間・サイズ・VMAF を比べる(`encode-benchmark`)。一般に GPU は同じ見た目で数割大きいファイルになりやすい。
6. **負荷の確認**: エンコード中に `nvidia-smi dmon`(enc / dec 列)、Intel は `intel_gpu_top`、macOS はアクティビティモニタの GPU 履歴を見る。
7. **元ファイルを上書きしない**: 出力は別フォルダ・別名、`-n` を既定に。長いログは token-saver の `log-digest` で要約できる。

### よくあるエラー
- `Unknown encoder 'h264_nvenc'` … ビルドに含まれていない。NVENC 対応ビルドに替える
- `Cannot load libcuda.so` / `No NVENC capable devices found` / `Driver does not support the required nvenc API version` … ドライバ未導入・古い、または GPU 非対応
- `Failed to initialise VAAPI connection` … ドライバ(`intel-media-driver` / `mesa-va-drivers` 等)または `/dev/dri` の権限(`render` グループ)
- 同時に多数のエンコードを走らせると初期化に失敗する … GeForce 等は同時セッション数に上限があり、GPU とドライバで異なる(NVIDIA の Video Encode and Decode GPU Support Matrix で確認)

## 出力フォーマット
```markdown
### GPU エンコード設定
- 確認結果: -encoders に h264_nvenc あり / テストエンコード成功(ドライバ 5xx)
- コマンド: (ファイル名はダブルクォート、-n 付き)
- 品質指定: -cq 23(CPU の CRF 23 相当を VMAF で確認予定)
- 期待: 速度 x倍 / サイズ +y%(計測値 or 未計測)
- 注意: ビルド・GPU・ドライバ依存。動かない場合の代替: libx264 -preset faster
```

## 品質チェックリスト
- [ ] `-encoders` / `-hwaccels` と 5 秒テストで使えることを確認した(できない場合はその旨を明記)
- [ ] ビルド・GPU・ドライバ依存であることを書いた
- [ ] 品質指定(cq / global_quality / qp / q:v)の向き(小さいほど高画質か)を書いた
- [ ] GPU フレームと CPU フィルターの混在によるエラーを避けた
- [ ] CPU エンコードとの比較方法を示した
- [ ] `-n`・別名出力・ファイル名のクォート

## 例
**入力**: 「RTX 4070 の Windows で、ゲーム録画 100 本を H.265 で小さくしたい」
**出力**: `-encoders` の確認コマンド(PowerShell 版)、`-hwaccel cuda -hwaccel_output_format cuda` + `hevc_nvenc -preset p5 -tune hq -rc vbr -cq 28 -b:v 0` のコマンド、1 本の 60 秒区間で cq 24/28/32 を比べる手順、同時実行は 2〜3 から試す旨(`parallel-encode`)を返す。
