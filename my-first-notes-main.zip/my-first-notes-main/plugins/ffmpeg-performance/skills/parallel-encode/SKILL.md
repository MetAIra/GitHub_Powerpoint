---
name: parallel-encode
description: 複数の動画を ffmpeg で同時に変換するときの同時実行数・スレッド設定を決め、CPU / GPU / ディスクの負荷を見ながら最も速い組み合わせを探します。「100 本の動画を並列で変換したい。いくつ同時に走らせるのがいい?」「ffmpeg の -threads はどう設定する?」のような依頼で使います。
---

# ffmpeg の並列処理

## 目的
「1 本を速く」より「全体を早く終わらせる」ために、同時実行数と 1 プロセスあたりのスレッド数を計測に基づいて決める。むやみに並列数を増やすと、メモリ不足やディスク待ちで逆に遅くなる。Python での一括処理の骨組みは python-video プラグインの `batch-processing`、GPU の設定は `gpu-encode` を参照。

## 最初に確認すること
- **マシン**: 論理コア数(`nproc` / macOS `sysctl -n hw.ncpu` / PowerShell `$env:NUMBER_OF_PROCESSORS`)、メモリ量、GPU の有無
- **処理の種類**: 再エンコード(CPU 律速)/ `-c copy`(ディスク律速)/ GPU エンコード(GPU のエンコーダー数とセッション上限が律速)
- **入出力の場所**: 同じ HDD・NAS 同士だと I/O 律速になりやすい。可能なら出力は別ドライブ / SSD
- **解像度とエンコーダー**: 4K の libx265 は 1 本でも全コアを使い切ることがある
- **マシンを他の作業にも使うか**: 使うなら全コアの 7〜8 割に抑える

## 手順
1. **まず 1 本を計測**: 代表的な 1 本(または 60 秒区間)を既定設定で変換し、`-benchmark` で実時間・CPU 時間・最大メモリを見る。
   ```bash
   ffmpeg -hide_banner -n -benchmark -i "sample.mp4" -t 60 -c:v libx264 -preset medium -crf 23 -an "bench/x264_1.mp4"
   ```
   出力末尾の `bench: utime=... rtime=...` で、utime(CPU 時間)÷ rtime(実時間)が「何コア分使ったか」の目安になる。
2. **同時実行数の初期値を決める**
   | 処理 | 初期値 | 理由 |
   |---|---|---|
   | libx264 / libx265 の再エンコード | 論理コア数 ÷ (1 本が使ったコア数)、通常 2〜4 | エンコーダー自体がマルチスレッド |
   | `-c copy`・分割・結合 | 2〜4 | CPU はほぼ使わずディスク律速 |
   | NVENC / QSV / VideoToolbox | 2〜3 から | GPU のエンコーダー数・同時セッション上限・VRAM で頭打ち |
   | AV1(libsvtav1 など) | 1〜2 | 1 本でメモリとコアを多く使う |
3. **スレッドの設定**: 通常は ffmpeg 任せ(既定はエンコーダーが自動で決める)。並列数を増やすときだけ 1 本あたりを絞る。
   - `-threads N` は出力ファイルの前に書くとエンコーダーのスレッド数(libx264 等が参照)
   - `-filter_threads N` はフィルター処理のスレッド数(既定は CPU 数)。重いフィルターを並列で回すときに絞る
   - 例: 16 コアで 4 本同時なら各 `-threads 4 -filter_threads 2` を起点にする
4. **2〜3 通りを実測して決める**: 同時実行数 1 / 2 / 4 などで同じ 4〜8 本を処理し、「全体の所要時間」で比べる。1 本あたりの速度ではなく合計時間を見る。
5. **負荷の見方**
   - CPU: `htop`(全コア 100% 近くで頭打ちなら CPU 律速)、Windows はタスクマネージャーの「パフォーマンス」
   - メモリ: スワップが増えたら並列数を下げる
   - ディスク: `iostat -x 1` の `%util` が 100% 近い、または CPU が余っているのに速くならないなら I/O 律速
   - GPU: `nvidia-smi dmon` の `enc` / `dec` 列。enc が 100% 近ければ並列を増やしても速くならない。Intel は `intel_gpu_top`
6. **CPU と GPU を併用する**: GPU エンコード 2 本+ CPU エンコード 1 本のように混ぜると全体が速くなることがある。ただし画質の基準をそろえる(`encode-benchmark`)。
7. **実行方法**: シェルなら `xargs -P`、Python なら `ThreadPoolExecutor(max_workers=N)`。ファイル名の空白に備え、`find -print0 | xargs -0` を使う。
   ```bash
   mkdir -p out
   find in -type f -name "*.mp4" -print0 | xargs -0 -P 3 -I{} sh -c \
     'ffmpeg -hide_banner -nostdin -loglevel error -n -i "$1" -c:v libx264 -crf 23 -threads 4 "out/$(basename "$1")"' _ {}
   ```
   `-nostdin` がないと、並列実行中の ffmpeg が端末の入力を奪い合って止まることがある。PowerShell 7 以降なら `ForEach-Object -Parallel -ThrottleLimit 3` が使える。
8. **元ファイルを上書きしない**: 出力は別フォルダ、`-n` を既定に。失敗の記録と再実行は `batch-processing` の方法で。

## 出力フォーマット
```markdown
### 並列設定の提案
- 環境: 16 論理コア / 32GB / RTX 4060 / 出力先 SSD
- 計測(60 秒区間): 1 本 = 実時間 40s、約 6 コア使用
- 提案: CPU 2 本(-threads 6)+ NVENC 2 本、合計 4 並列
- 実測比較: 並列1: 52分 / 並列2: 31分 / 並列4: 27分(推奨)/ 並列6: 29分
- 監視ポイント: htop で CPU 飽和、nvidia-smi dmon の enc 列
- 実行コマンド: ...
```

## 品質チェックリスト
- [ ] 1 本の計測結果(`-benchmark`)を根拠に初期値を決めた
- [ ] 合計所要時間で比較した
- [ ] CPU / メモリ / ディスク / GPU のどれが律速かを確認する方法を示した
- [ ] `-nostdin`・`-n`・空白入りファイル名対策(`-print0` / 引数リスト)がある
- [ ] GPU のセッション上限・ビルド依存に触れた

## 例
**入力**: 「8 コアのノート PC で、スマホ動画 300 本を 720p にしたい。夜の間に終わらせたい」
**出力**: 60 秒区間の `-benchmark` コマンド、初期値「2 並列・各 `-threads 4`」、2 / 3 並列の比較手順、`xargs -P 2` のコマンド、ノート PC の熱で速度が落ちる場合は並列を下げる注意を返す。
