---
name: image-prompt
description: 画像生成AI(Midjourney、DALL·E/ChatGPT、Stable Diffusion、Adobe Firefly、Imagen など)向けに、被写体・構図・画風・光・色・カメラ設定を整理したプロンプトとネガティブプロンプトを作ります。「画像生成AIのプロンプトを書いて」「こんなイメージの画像を作りたい」「Midjourney用に英語で」「もっと狙い通りの絵にしたい」といった依頼で使います。
---

# 画像生成AI向けプロンプト作成

## 目的
頭の中のイメージを、画像生成AIが解釈しやすい要素(被写体・構図・画風・光・色・カメラ)に分解し、ツールごとの書き方に合わせたプロンプトにする。1回で当てるより「狙いを外しにくく、調整しやすい」プロンプトを渡す。

## 最初に確認すること
- **用途**: ブログのアイキャッチ、SNS投稿、資料の挿絵、商品イメージなど(既定値: ブログのアイキャッチ)
- **使うツール**: 既定値 ツール非依存の英語プロンプト+日本語訳を併記
- **アスペクト比**: 既定値 16:9(アイキャッチ)。SNS正方形は 1:1、縦型動画・ストーリーズは 9:16
- **画風**: 写真風/イラスト/3D/水彩など。不明なら用途から推定して2案出す
- **入れたくないもの**: 文字、人物、ロゴ など
- **商用利用の有無**: ツールの利用規約と生成物の権利を確認するよう促す

## 手順
1. イメージを次の6要素に分解する。欠けている要素は用途から補い、補ったことを明記する。

| 要素 | 決めること | 語彙の例 |
|---|---|---|
| 被写体 | 誰/何が、何をしている、表情・服装・素材 | a young office worker typing on a laptop, smiling |
| 構図 | 画角、配置、背景、余白 | close-up / wide shot / rule of thirds / negative space on the right |
| 画風 | 写真・イラストの種類、質感 | photorealistic / flat vector illustration / watercolor / isometric 3D |
| 光 | 光源、時間帯、硬さ | soft natural window light / golden hour / studio lighting / backlit |
| 色 | トーン、主色、彩度 | muted pastel palette / teal and orange / monochrome with a red accent |
| カメラ | レンズ、被写界深度、アングル | 35mm lens / shallow depth of field / low angle / top-down view |

2. 重要な要素を前に置く(多くのツールで先頭の語の影響が大きい)。順番: 被写体 → 構図 → 画風 → 光 → 色 → カメラ → 品質・比率。
3. ツール別に書き方を変える。

| ツール | 書き方 | 注意 |
|---|---|---|
| Midjourney | 短い英語の句をカンマ区切り。末尾にパラメータ `--ar 16:9` `--no text` `--style raw` | 長文の説明より名詞句が効く |
| DALL·E / ChatGPT | 自然な英語(日本語も可)の文章で状況を説明 | ネガティブは「〜は含めない」と文中に書く |
| Stable Diffusion | カンマ区切りのタグ。`(keyword:1.3)` で重み付け。ネガティブプロンプト欄を使う | モデル(チェックポイント)で結果が大きく変わる |
| Adobe Firefly / Imagen | 自然文。画風・比率はUIの設定を優先 | 商用可否はプランと規約を確認 |

4. ネガティブプロンプトを作る(対応ツールのみ)。定番: `text, watermark, logo, blurry, low quality, extra fingers, deformed hands, cropped`。用途に応じて `people` などを追加。
5. 権利・倫理面を点検し、該当すれば言い換える。
   - **実在人物**(有名人・政治家・一般人)の名前や容姿指定は使わない → 「30代の女性、ショートヘア」など属性で書く
   - **著作権のあるキャラクター**・作品名・ブランドロゴは使わない → 「丸い目の小さなロボット」など特徴で書く
   - **存命の作家・イラストレーターの画風指定**(「〇〇風」)は避ける → 画材・時代・技法で書く(例: 1980年代のエアブラシイラスト、太い輪郭線のセル画調)
6. 調整用のバリエーション(構図違い・光違い)を2つ添え、結果を見てどこを変えるかの指針を書く。

## 出力フォーマット
```markdown
## 画像プロンプト: <用途・ねらい>
- ツール: … / 比率: … / 画風: …
- 補った要素: <ユーザー未指定で既定値を入れたもの>

### プロンプト(英語)
<本文>

### 日本語訳
<本文>

### ネガティブプロンプト
<本文>(非対応ツールでは文中に「〜を含めない」と記載)

### バリエーション
- A(構図違い): …
- B(光・色違い): …

### 調整のヒント
- 〇〇が強すぎる場合: … を削る/後ろに移す
```

## 品質チェックリスト
- [ ] 被写体・構図・画風・光・色・カメラの6要素がそろっている
- [ ] 重要な要素がプロンプトの先頭にある
- [ ] ツールの書式(パラメータ、重み付け、自然文)に合っている
- [ ] 比率が用途に合っている
- [ ] 実在人物名・著作権キャラクター・存命作家名を使っていない
- [ ] 文字を入れる必要がある場合は「後から編集ソフトで入れる」を推奨している(AI生成の文字、特に日本語は崩れやすい)

## 例
入力: 「リモートワークの記事のアイキャッチ。明るい雰囲気で、人物は後ろ姿がいい」
出力:
- プロンプト: `A person seen from behind working on a laptop at a wooden desk by a large window, cozy home office with plants, wide shot, negative space on the left for a title, soft morning sunlight, warm beige and green palette, photorealistic, 35mm lens, shallow depth of field --ar 16:9 --no text`
- ネガティブ: `text, watermark, logo, face, blurry, cluttered desk`
- 補足: タイトル文字は生成後にCanva等で左の余白に配置する
