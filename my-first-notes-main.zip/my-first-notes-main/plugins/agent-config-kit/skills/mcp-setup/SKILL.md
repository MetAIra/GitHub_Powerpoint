---
name: mcp-setup
description: Claude Code に MCP サーバーを追加・設定する。claude mcp add のコマンド、スコープ(local / project / user)の選び方、プロジェクト共有用 .mcp.json、stdio と http の違い、環境変数での認証情報の渡し方を示し、トークンをコミットしない構成にする。「MCP サーバーを追加したい」「GitHub の MCP を使いたい」「.mcp.json を作って」「MCP が繋がらない」と頼まれたときに使う。
---

# MCP サーバー設定

## 目的
外部ツール(GitHub、DB、ブラウザ、社内 API など)を MCP サーバーとして Claude Code に接続する。**誰と共有するか**でスコープを選び、**認証情報がリポジトリに入らない**形で設定する。

## 最初に確認すること
- **接続したいサービスと公式の接続方法**: サービス側のドキュメントにある URL(http)か起動コマンド(stdio)。不明なら提供元の README を一緒に確認する(推測で URL を作らない)。
- **共有範囲**: 未指定なら「自分だけ・このプロジェクトだけ」= `local`(既定)。チームで使うなら `project`。
- **認証方式**: OAuth / API キー・トークン / 不要。トークンの場合、保管場所(シェルの環境変数、パスワードマネージャ等)。
- **OS とランタイム**: stdio なら `npx`(Node)や `uvx`(Python)が入っているか。

## 手順
1. **トランスポートを決める**。
   | 種類 | 使う場面 | 形 |
   |---|---|---|
   | `http` | サービスがリモート MCP の URL を提供している(推奨) | URL + 必要ならヘッダー |
   | `stdio` | 手元でプロセスを起動する(npx / uvx / 自作スクリプト) | コマンド + 引数 + 環境変数 |
   | `sse` | 古いリモートサーバー(公式では非推奨扱い) | URL |
2. **スコープを決める**。
   | スコープ | 効く範囲 | 保存先 | 共有 |
   |---|---|---|---|
   | `local`(既定) | このプロジェクト・自分のみ | `~/.claude.json` | しない |
   | `project` | このプロジェクト・全員 | リポジトリ直下の `.mcp.json` | コミットして共有 |
   | `user` | 全プロジェクト・自分のみ | `~/.claude.json` | しない |
   同名サーバーがあると local → project → user の順に優先される。
3. **追加する**(オプションはサーバー名より前、stdio のコマンドは `--` の後ろ)。
   ```bash
   # http(OAuth があるサービス)
   claude mcp add --transport http sentry https://mcp.sentry.dev/mcp
   # http(トークンをヘッダーで渡す。値は環境変数から展開して履歴に残しにくくする)
   claude mcp add --transport http github https://api.githubcopilot.com/mcp/ \
     --header "Authorization: Bearer $GITHUB_PAT"
   # stdio(環境変数は --env / -e で渡す)
   claude mcp add --transport stdio --env AIRTABLE_API_KEY="$AIRTABLE_API_KEY" airtable \
     -- npx -y airtable-mcp-server
   ```
4. **チーム共有(project スコープ)は `.mcp.json` に秘密を書かない**。値は `${VAR}` / `${VAR:-既定値}` で参照し、各自が環境変数を設定する。展開は `command` / `args` / `env` / `url` / `headers` で使える。`claude mcp add --scope project ... --header "Authorization: Bearer 実トークン"` のように実値を渡すとそのまま `.mcp.json` に書かれるので、追加後に必ずファイルを開いて `${VAR}` に置き換える。
5. **認証**: OAuth のサーバーはセッション内で `/mcp` を開き、対象を選んでブラウザで認証する。`/mcp` は接続状態(接続済み・要認証・失敗・承認待ち)の確認にも使う。
6. **確認**: `claude mcp list`(一覧と状態)、`claude mcp get <name>`(詳細)、不要になれば `claude mcp remove <name>`。`.mcp.json` のサーバーは初回利用時に承認を求められる(対話セッションの場合)。
7. **権限**: 毎回の許可が煩わしければ settings.json の `permissions.allow` に `mcp__<server>__<tool>` や `mcp__<server>__*` を足す(書き込み系ツールは allow にしない。詳細は `permissions-setup`)。
8. **つながらないとき**: stdio はコマンドを単体でターミナル実行して起動するか確かめる / `--` の位置 / 環境変数が Claude Code 起動時のシェルに存在するか / プロキシ・社内ネットワーク。起動が遅いサーバーはタイムアウト設定(`MCP_TIMEOUT` 環境変数など)を公式ドキュメントで確認する。一部の資格情報系の変数名は展開されない仕様もあるため、`${VAR}` が空になる場合は公式ドキュメントの MCP のページを確認する。

## 出力フォーマット
````markdown
### 構成
- サーバー: <name>(<http/stdio>)/ スコープ: <local/project/user>(理由: …)
- 認証: <OAuth / 環境変数 XXX_TOKEN / 不要>

### 追加コマンド
```bash
claude mcp add ...
```

### .mcp.json(project スコープの場合)
```json
{ "mcpServers": { "<name>": { "type": "http", "url": "…", "headers": { "Authorization": "Bearer ${XXX_TOKEN}" } } } }
```

### 各自がやること
1. `export XXX_TOKEN=...` をシェル設定に追加(リポジトリには書かない)
2. Claude Code を再起動し `/mcp` で接続・認証を確認

### 確認コマンド / 注意点
- …
````

## 品質チェックリスト
- [ ] URL・パッケージ名は提供元の公式情報に基づき、推測で作っていない
- [ ] スコープの選択理由が書かれている
- [ ] `.mcp.json` やコミット対象ファイルに実トークンが入っていない(`${VAR}` 参照)
- [ ] stdio のコマンドが `--` の後ろにあり、オプションが名前より前にある
- [ ] 各自が設定すべき環境変数と確認方法(`/mcp`、`claude mcp list`)を示した
- [ ] allow に入れるツールは読み取り系に限定した
- [ ] 不確かな仕様は公式ドキュメント(https://code.claude.com/docs/en/mcp)確認として残した

## 例
**入力**: 「チームで GitHub の MCP を使いたい。トークンはどうすれば?」

**出力(抜粋)**:
> 構成: github(http)/ project スコープ(全員で同じ設定を共有するため)。認証は各自の PAT を環境変数 `GITHUB_PAT` で渡す。
> `.mcp.json`: `"headers": { "Authorization": "Bearer ${GITHUB_PAT}" }`
> 注意: PAT は最小権限(読み取り中心)で発行し、`.mcp.json` に実値を書かない。追加後に `git diff .mcp.json` でトークンが含まれていないことを確認する。
