---
name: slash-command-writer
description: Claude Code のカスタムスラッシュコマンド(.claude/commands/*.md)を作成する。$ARGUMENTS などの引数、frontmatter の description / argument-hint / allowed-tools、シェル出力の埋め込みまで設計し、skill にすべきかどうかも判断する。「スラッシュコマンドを作りたい」「/review みたいな自作コマンドを作って」「よく使うプロンプトをコマンド化したい」と頼まれたときに使う。
---

# カスタムスラッシュコマンド作成

## 目的
毎回打っている定型の依頼文を、`/名前 引数` の一発で呼べるコマンドにする。引数の受け方・事前に集める情報・許可するツールを決め、誰が実行しても同じ結果になるプロンプトに仕上げる。

## 最初に確認すること
- **何を定型化するか**: いま手で打っている依頼文そのもの(あればそのまま貼ってもらう)。
- **引数**: 毎回変わる部分(Issue 番号、対象ファイル、環境名など)。未指定なら「引数なし」で作り、後から足す。
- **置き場所**: 未指定ならプロジェクト共有の `.claude/commands/<name>.md`。個人用ならユーザー直下(下記の手順2参照)。
- **自動で呼ばれてよいか**: 未指定なら「ユーザーが明示的に打ったときだけ動く」前提で作る(副作用のある操作は特に)。

## 手順
1. **skill にすべきか判定する**。公式ドキュメントでは「カスタムコマンドは skill に統合された」とされ、`.claude/commands/deploy.md` と `.claude/skills/deploy/SKILL.md` はどちらも `/deploy` になり同じように動く。そのうえで次で選ぶ。
   | 条件 | おすすめ |
   |---|---|
   | 1ファイルで完結する短い定型プロンプト、自分で打つのが前提 | `commands/<name>.md` |
   | テンプレート・スクリプトなど補助ファイルを同梱したい | skill(`skills/<name>/SKILL.md`、`skill-writer` を使う) |
   | 会話の流れから Claude に自動で使ってほしい | skill(description を発火条件として書く) |
   | 新規にプラグインへ入れる | skill を推奨(公式は `commands/` を旧形式と位置付けている) |
2. **名前と置き場所**を決める。ファイル名(拡張子なし)がコマンド名になる。英小文字とハイフン(例 `fix-issue.md` → `/fix-issue`)。
   - プロジェクト: `.claude/commands/`。サブフォルダ `frontend/component.md` は `/frontend:component` のように名前空間付きになる。
   - 個人用: 公式が推奨する現行の置き場所は `~/.claude/skills/<name>/SKILL.md`。`~/.claude/commands/` を使う場合は現行の扱いを公式ドキュメントで確認する。
   - プラグイン内: `/<プラグイン名>:<コマンド名>` で呼ばれる。
3. **引数の受け方**を選ぶ。
   - `$ARGUMENTS`: 渡された引数全体(例 `/fix-issue 123` → `123`)。迷ったらこれ。
   - 位置引数: 公式ドキュメント現行版では `$0`, `$1`…(`$ARGUMENTS[0]` も可)で、**`$0` が1つ目**。空白を含む値は引用符で囲んで渡す。以前の解説記事では `$1` 始まりのものもあるため、書く前に公式ドキュメントで番号の起点を確認し、実際に試す。
   - 引数が必須なら本文に「引数が空なら何を聞くか」を書いておく。
4. **frontmatter** を必要なものだけ書く。
   | キー | 用途 | 例 |
   |---|---|---|
   | `description` | `/` メニューに出る説明、自動起動の判断材料 | `Issue を修正して PR を作る` |
   | `argument-hint` | 入力補完に出る引数のヒント | `[issue-number]` |
   | `allowed-tools` | このコマンド実行中だけ許可なしで使えるツール | `Bash(git status *) Bash(git diff *)` |
   | `disable-model-invocation` | `true` で Claude が自動で呼ばない(手動専用) | `true` |
   | `model` | このコマンドだけ使うモデルを変える | 必要時のみ |
   `allowed-tools` の許可は次のメッセージ送信で解除される(常時許可したいなら `permissions-setup` で settings.json に書く)。キーの一覧は増減するので、上記以外を使う場合は公式ドキュメントを確認する。
5. **事前情報の埋め込み**: 本文に `` !`git diff --stat` `` のように書くと、Claude が読む前にコマンドが実行され出力が差し込まれる。失敗(非ゼロ終了)するとコマンド全体が中断されるので、失敗しうるものは `|| true` を付ける。埋め込むコマンドは読み取り系に限定する。
6. **本文**を書く: 「目的 → 手順(番号付き)→ 出力形式 → してはいけないこと」の順。依頼文の曖昧さは `prompt-improver` の観点で潰す。
7. **動作確認**: `/` を打って候補に出るか、引数あり・なし・空白入りで試し、差し込み結果と許可プロンプトの出方を確認する。

## 出力フォーマット
````markdown
### 判定
- 形式: command / skill(理由: …)
- 配置先: `.claude/commands/<name>.md` → 呼び出し: `/<name> <引数>`

### ファイル内容
```markdown
---
description: <何をするか 1文>
argument-hint: [<引数名>]
allowed-tools: <必要最小限。なければ行ごと削除>
disable-model-invocation: true
---

## 状況
- 現在の差分: !`git diff --stat || true`

## 依頼
$ARGUMENTS について、以下を行ってください。
1. …
2. …

## 出力形式
…

## してはいけないこと
- …
```

### 使い方
- `/<name> 123` → …
### 確認が必要な点
- …
````

## 品質チェックリスト
- [ ] skill と command のどちらにするか理由付きで判定した
- [ ] ファイル名が英小文字・ハイフンで、呼び出し名が明記されている
- [ ] 引数が空・空白入りのときの挙動を決めている
- [ ] `allowed-tools` が最小限で、書き込み・push・削除系を安易に許可していない
- [ ] `!` 埋め込みは読み取り系のみで、失敗時の中断を考慮している
- [ ] 副作用のあるコマンドは `disable-model-invocation: true` にしている
- [ ] 仕様が不確かな点(引数番号の起点など)を公式ドキュメント確認として残している

## 例
**入力**: 「`GitHub の Issue 123 を読んで直して` を毎回打っているのでコマンドにしたい」

**出力(抜粋)**:
> 判定: command(1ファイルで完結・手動実行が前提)。配置先 `.claude/commands/fix-issue.md` → `/fix-issue 123`
> ```markdown
> ---
> description: GitHub Issue を読んで修正し、テストを通す
> argument-hint: [issue-number]
> allowed-tools: Bash(gh issue view *)
> disable-model-invocation: true
> ---
> Issue #$ARGUMENTS を `gh issue view $ARGUMENTS` で読み、原因を特定して修正してください。
> 1. 再現手順と原因を3行で説明 2. 最小限の修正 3. 関連テストを実行
> 引数が空なら、Issue 番号を尋ねてから始めること。
> ```
