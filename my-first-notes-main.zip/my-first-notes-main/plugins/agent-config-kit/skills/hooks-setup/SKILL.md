---
name: hooks-setup
description: Claude Code の hooks を settings.json に設定する。ファイル編集後の自動整形、作業完了・入力待ちの通知、危険なコマンドのブロック、セッション開始時の準備などの設定例とスクリプトを作る。「hooks を設定したい」「編集したら自動で prettier をかけて」「rm -rf を禁止したい」「終わったら通知して」と頼まれたときに使う。
---

# Hooks 設定

## 目的
「毎回必ず実行したいこと」を、Claude の判断に任せず Claude Code 本体が確実に実行する hooks として `settings.json` に定義する。CLAUDE.md の指示は守られないことがあるが、hooks は決定的に動く。

## 最初に確認すること
- **やりたいこと**: 整形 / 通知 / ブロック / ログ / 事前準備 のどれか。
- **適用範囲**: 未指定ならプロジェクト共有の `.claude/settings.json`。個人用は `~/.claude/settings.json`、コミットしない個人設定は `.claude/settings.local.json`。
- **環境**: OS(通知コマンドが異なる)、`jq` の有無、使っている formatter。未指定なら macOS/Linux・`jq` あり・既存の lint 設定から推測。

## 手順
1. **イベントを選ぶ**。
   | 目的 | イベント | matcher |
   |---|---|---|
   | 危険コマンドのブロック | `PreToolUse` | `Bash` |
   | 編集後の整形・lint | `PostToolUse` | `Edit\|Write` |
   | 応答完了の通知 | `Stop` | (不要) |
   | 許可待ち等の通知 | `Notification` | (不要または種別) |
   | プロンプトへの文脈追加・検査 | `UserPromptSubmit` | (不要) |
   | 依存インストール等の準備 | `SessionStart` | 必要に応じ `startup` など |
2. **構造**を守る: `hooks` → イベント名 → `[{ "matcher": ..., "hooks": [{ "type": "command", "command": ... }] }]`。matcher はツール名で、`Edit|Write` のような正規表現も使える。
3. **入力の受け取り**: hook コマンドには標準入力で JSON が渡される。ツール系イベントでは `tool_name`、`tool_input`(`Bash` なら `.tool_input.command`、`Edit`/`Write` なら `.tool_input.file_path`)を `jq` で取り出す。
4. **終了コード**: `0` = 成功(続行)、`2` = ブロック(stderr の内容が Claude に返される)、その他 = ブロックしないエラー。ブロックしたいときは必ず `exit 2`。
5. **スクリプト化**: 3行を超える処理は `.claude/hooks/*.sh` に分け、`"$CLAUDE_PROJECT_DIR"/.claude/hooks/xxx.sh` で呼ぶ(作業ディレクトリに依存しないため)。`chmod +x` を忘れない。
6. **安全性の確認**: hooks はユーザー権限で任意のコマンドを実行する。入力をクォートする、`eval` しない、失敗時に作業を止めすぎない(整形失敗は `exit 0` で握りつぶす等)。
7. **動作確認**: `/hooks` で登録を確認し、わざと該当操作をして挙動を見る。
8. 利用できるイベント名・JSON 出力による高度な制御(`permissionDecision` 等)・タイムアウトなどは更新が多いため、使う前に公式ドキュメント(https://code.claude.com/docs の hooks のページ)で確認する。

### レシピ
**危険コマンドのブロック**(`.claude/hooks/block-dangerous.sh`)
```bash
#!/usr/bin/env bash
cmd=$(jq -r '.tool_input.command // ""')
if echo "$cmd" | grep -Eq 'rm -rf (/|~|\$HOME)|git push (-f|--force)|DROP TABLE'; then
  echo "危険なコマンドのためブロックしました: $cmd" >&2
  exit 2
fi
exit 0
```
**編集後の自動整形**(Prettier の例。対象拡張子だけ処理)
```bash
#!/usr/bin/env bash
f=$(jq -r '.tool_input.file_path // ""')
case "$f" in *.ts|*.tsx|*.js|*.json|*.md) npx prettier --write "$f" >/dev/null 2>&1 ;; esac
exit 0
```
**通知**: macOS `osascript -e 'display notification "完了しました" with title "Claude Code"'` / Linux `notify-send "Claude Code" "完了しました"`

## 出力フォーマット
````markdown
### 設定ファイル: `.claude/settings.json`
```json
{
  "hooks": {
    "PreToolUse": [
      { "matcher": "Bash",
        "hooks": [{ "type": "command", "command": "\"$CLAUDE_PROJECT_DIR\"/.claude/hooks/block-dangerous.sh" }] }
    ],
    "PostToolUse": [
      { "matcher": "Edit|Write",
        "hooks": [{ "type": "command", "command": "\"$CLAUDE_PROJECT_DIR\"/.claude/hooks/format.sh" }] }
    ],
    "Stop": [
      { "hooks": [{ "type": "command", "command": "notify-send 'Claude Code' '応答が完了しました'" }] }
    ]
  }
}
```

### スクリプト
- `.claude/hooks/xxx.sh`: (内容)

### セットアップ
1. `chmod +x .claude/hooks/*.sh`
2. `/hooks` で登録を確認

### 注意点・未確認事項
- …
````

## 品質チェックリスト
- [ ] イベント名の大文字小文字が正確(`PreToolUse` など)
- [ ] `matcher` と `hooks` 配列、`"type": "command"` の入れ子が正しい
- [ ] ブロック用 hook が `exit 2` と stderr メッセージを使っている
- [ ] 既存の settings.json を上書きせず、`hooks` キーにマージしている
- [ ] スクリプトのパスが `$CLAUDE_PROJECT_DIR` 基準で、実行権限の手順がある
- [ ] 変数をクォートしており、`jq` など依存コマンドを明記している
- [ ] 不確かな仕様は公式ドキュメント確認を促している

## 例
**入力**: 「Python プロジェクトで、Claude がファイルを書いたら ruff で整形してほしい」

**出力(抜粋)**:
> `PostToolUse` / matcher `Edit|Write` に `.claude/hooks/ruff.sh` を登録。
> スクリプトは `.tool_input.file_path` が `*.py` のときだけ `ruff format "$f" && ruff check --fix "$f"` を実行し、失敗しても `exit 0`(作業を止めない)。
