---
name: plugin-packager
description: 手元の .claude/ にある skill・agent・コマンド・hooks を Claude Code プラグインにまとめ、marketplace.json に登録して GitHub で配布する手順を作る。plugin.json の作成、ディレクトリ構成、claude plugin validate による検証、バージョン更新まで扱う。「自作スキルをプラグイン化したい」「マーケットプレイスで配布したい」「チームに skill を配りたい」「プラグインを更新したのに反映されない」と頼まれたときに使う。
---

# プラグイン化と配布

## 目的
個人の `.claude/` に散らばった skill / agent / コマンド / hooks を1つのプラグインにまとめ、マーケットプレイス(`.claude-plugin/marketplace.json` を持つ git リポジトリ)経由で `/plugin install` できる状態にする。このリポジトリ(`juntabe0711/my-first-notes`、マーケットプレイス名 `juntabe-toolkit`)を実例として使う。

## 最初に確認すること
- **まとめる対象**: どの skill / agent / コマンド / hooks / MCP 設定か。未指定なら `.claude/` 配下を Glob で列挙して提案する。
- **配布先**: 既存マーケットプレイスに追加 / 新規マーケットプレイスを作る。未指定ならこのリポジトリに新プラグインとして追加する。
- **公開範囲**: public / private リポジトリ(private は利用者側の git 認証が必要)。
- **プラグイン名**: 英小文字・ハイフン、空白なし。skill の呼び出し名の接頭辞になる(`/<plugin>:<skill>`)。

## 手順
1. **構成を作る**。コンポーネントはプラグインのルート直下に置き、`.claude-plugin/` には `plugin.json` だけを置く(中に置いた skill 等は読み込まれない)。
   ```
   plugins/<plugin>/
   ├── .claude-plugin/plugin.json
   ├── skills/<skill-name>/SKILL.md
   ├── agents/<agent-name>.md
   ├── commands/<name>.md      # 旧形式。新規は skills/ 推奨
   ├── hooks/hooks.json        # settings.json の "hooks" と同じ形を {"hooks": …} で包む
   └── .mcp.json               # MCP サーバー定義(秘密は ${VAR} 参照)
   ```
2. **既存ファイルを移す**: `.claude/skills` `.claude/agents` `.claude/commands` をプラグインルートへコピーする。hooks は settings.json の `hooks` オブジェクトを `hooks/hooks.json` に写す。スクリプトのパスは `${CLAUDE_PLUGIN_ROOT}/scripts/xxx.sh` のようにプラグインルート基準にする。
3. **plugin.json を書く**(`name` が必須。このリポジトリでは `plugins/writing/.claude-plugin/plugin.json` と同じ形に揃える)。
   ```json
   { "name": "<plugin>", "description": "<一覧に出る説明>", "version": "1.0.0", "author": { "name": "<名前>" } }
   ```
4. **marketplace.json に登録する**(リポジトリ直下の `.claude-plugin/marketplace.json` の `plugins` 配列に追加)。
   ```json
   { "name": "<plugin>", "source": "./plugins/<plugin>", "description": "<説明>" }
   ```
   - `source` の相対パスはマーケットプレイスのルート(`.claude-plugin/` を含むディレクトリ)から書く。`..` は使えない。
   - エントリの `name` と `plugin.json` の `name` を一致させる(ずれると「not found in marketplace」になる)。
   - `version` は `plugin.json` とエントリの**どちらか一方だけ**に書く(このリポジトリは `plugin.json` 側)。
5. **検証する**: `claude plugin validate ./plugins/<plugin>` → `claude plugin validate .`(マーケットプレイス全体)。`Validation passed` を確認する。
6. **手元で試す**: `claude --plugin-dir ./plugins/<plugin>` で起動し、`/<plugin>:<skill>` の実行、agent が `/agents` に出るか、hooks が発火するかを確認する。編集後は `/reload-plugins`。`--plugin-dir` にマーケットプレイスのルートを渡しても配下のプラグインは読まれない点に注意。
7. **元ファイルを片付ける**: `.claude/` に同じ hooks が残っていると二重に実行される。動作確認後に元を削除する(skill / agent は接頭辞が付くので衝突はしないが、重複して見える)。
8. **公開する**: commit・push 後、利用者は次を実行する。
   ```
   /plugin marketplace add juntabe0711/my-first-notes
   /plugin install <plugin>@juntabe-toolkit
   ```
   `@` の後ろはリポジトリ名ではなく marketplace.json の `name`。チーム全員に登録させたいリポジトリでは `claude plugin marketplace add <owner>/<repo> --scope project` を実行し、生成された `.claude/settings.json` をコミットする。
9. **更新を届ける**: `version` を書いている場合、**上げないと利用者に更新が届かない**(キャッシュされたコピーのまま)。変更のたびに `plugin.json` の `version` を上げる(例: skill 追加 = マイナー、文言修正 = パッチ)。利用者は `/plugin marketplace update <marketplace>` で取得する(自動更新は利用者側で有効化が必要)。
10. **名前を変える・消す**: プラグイン名の変更は既存インストールを壊す。表示名だけなら `displayName`、改名・削除は marketplace.json の `renames` を使う(詳細は公式ドキュメント)。
11. 仕様は頻繁に更新されるため、詳細は公式ドキュメント(https://code.claude.com/docs/en/plugins 、plugin-marketplaces)で確認する。skill 本文の書き方は `skill-writer`、agent は `agent-writer` を使う。

## 出力フォーマット
````markdown
### 移行計画
| 元の場所 | 移行先 | 新しい呼び出し名 |
|---|---|---|
| `.claude/skills/deploy/` | `plugins/<plugin>/skills/deploy/` | `/<plugin>:deploy` |

### 作成・編集するファイル
- `plugins/<plugin>/.claude-plugin/plugin.json`: ```json …```
- `.claude-plugin/marketplace.json` への追加エントリ: ```json …```

### 検証・確認コマンド
```bash
claude plugin validate ./plugins/<plugin>
claude plugin validate .
claude --plugin-dir ./plugins/<plugin>
```

### 利用者向けインストール手順
### リリース時のチェック(version / README / 片付け)
````

## 品質チェックリスト
- [ ] `.claude-plugin/` の中には `plugin.json` だけがある
- [ ] marketplace.json のエントリ名と plugin.json の `name` が一致している
- [ ] `source` がマーケットプレイスのルートからの `./` 相対パスで、`..` を含まない
- [ ] `version` を片方にだけ書き、更新時に上げる運用を明記した
- [ ] hooks・MCP のパスが `${CLAUDE_PLUGIN_ROOT}` 基準で、秘密情報が含まれていない
- [ ] `claude plugin validate` と `--plugin-dir` での動作確認手順がある
- [ ] 元の `.claude/` の重複(特に hooks の二重実行)への対処がある

## 例
**入力**: 「`.claude/skills/release-note` と `.claude/agents/qa.md` を `dev-tools` プラグインにしてこのリポジトリで配りたい」

**出力(抜粋)**:
> 移行: `plugins/dev-tools/skills/release-note/`(`/dev-tools:release-note`)、`plugins/dev-tools/agents/qa.md`(`dev-tools:qa`)
> marketplace.json 追加: `{"name": "dev-tools", "source": "./plugins/dev-tools", "description": "開発補助: リリースノート作成と QA レビュー"}`
> 利用者: `/plugin install dev-tools@juntabe-toolkit`。以後の更新時は `plugins/dev-tools/.claude-plugin/plugin.json` の `version` を 1.0.0 → 1.1.0 のように上げてから push する。
