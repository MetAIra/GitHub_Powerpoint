---
name: permissions-setup
description: Claude Code の settings.json の permissions(allow / ask / deny)を設計する。ルール記法(Bash のワイルドカード、Read/Edit のパス指定、WebFetch のドメイン、MCP ツール)、ユーザー/プロジェクト/ローカルの設定階層、危険なコマンドや秘密ファイルの deny 例を示す。「許可確認を減らしたい」「npm test は毎回聞かないで」「.env を読ませたくない」「rm -rf や git push を禁止したい」と頼まれたときに使う。
---

# 権限設定(permissions)

## 目的
「聞かずに実行してよいもの」「毎回確認したいもの」「絶対にさせないもの」を分け、許可プロンプトの手間を減らしつつ事故を防ぐ `permissions` を作る。permissions は Claude Code 本体が強制する(CLAUDE.md の指示と違い、モデルの判断に依存しない)。

## 最初に確認すること
- **困っていること**: 確認が多すぎる / 危険な操作を防ぎたい / 秘密ファイルを守りたい。
- **適用範囲**: 未指定なら、チーム共通は `.claude/settings.json`、個人の好みは `.claude/settings.local.json` に分けて提案する。
- **よく使うコマンド**: `package.json` の scripts、Makefile 等を読んで推測し、確認を求める。
- **秘密情報の置き場所**: `.env`、`secrets/`、鍵ファイル等。未指定なら `.env` 系を既定で deny に入れる。

## 手順
1. **置き場所(階層)を決める**。優先度は上から: 管理者の managed 設定 > コマンドライン引数 > `.claude/settings.local.json`(個人・このプロジェクト)> `.claude/settings.json`(チーム共有・コミットする)> `~/.claude/settings.json`(個人・全プロジェクト)。
   - `allow` などの配列は階層間で**結合**される(上書きではない)。
   - どの階層の deny も、他の階層の allow より優先される。
   - `settings.local.json` は Claude Code が作成した場合は自動で git の除外対象になるが、手で作ったら自分で `.gitignore` に入れる。
2. **判定順を理解する**: **deny → ask → allow** の順に評価し、最初に当たったものが採用される。具体的な allow で広い deny に穴を開けることはできない(例: deny `Bash(aws *)` があると allow `Bash(aws s3 ls)` も拒否)。
3. **ルールを書く**(形式は `ツール名` または `ツール名(指定子)`)。
   | 対象 | 記法 | 意味 |
   |---|---|---|
   | Bash 完全一致 | `Bash(npm run build)` | そのコマンドだけ |
   | Bash 前方一致 | `Bash(npm run *)` | `npm run` で始まるもの(`*` の前の空白が語の区切り。`Bash(ls*)` は `lsof` にも当たる) |
   | Bash 旧記法 | `Bash(npm run:*)` | 末尾の `:*` は ` *` と同じ |
   | ファイル読み取り | `Read(./.env)` / `Read(./secrets/**)` | gitignore 形式のパス |
   | ファイル編集 | `Edit(/src/**)` | `/` 始まりは設定ファイルの基準(プロジェクト設定ならプロジェクトルート)。絶対パスは `//`、ホームは `~/` |
   | Web 取得 | `WebFetch(domain:example.com)` | ドメイン単位 |
   | MCP | `mcp__github` / `mcp__github__get_*` | サーバー全体 / 特定ツール |
   | サブエージェント | `Agent(Explore)` | 指定エージェント |
   - `*` はサブコマンドの後ろに置く(`Bash(git log *)` は git log だけ、`Bash(git *)` は git 全部)。
   - `&&` `;` `|` でつないだコマンドは各部分が個別に判定されるので、`Bash(npm test *)` で `npm test && rm -rf x` が通ることはない。
   - 書き込みの制御は `Edit(...)` で書く(`Write(...)` のパス指定は参照されない)。
4. **allow に入れる基準**: 読み取り専用・結果が冪等・プロジェクト外に影響しないもの(テスト、lint、ビルド、`git status` / `git diff` / `git log`)。`Bash(git *)` `Bash(npm *)` `Bash(npx *)` のような広すぎる allow は避ける(`npx` や `docker exec` は任意コマンドを実行できる)。
5. **ask に入れる基準**: 必要だが影響が大きいもの(`git push`、`git commit`、依存追加、マイグレーション)。
6. **deny に入れる基準**: 取り返しがつかない・秘密情報に触れるもの。雛形:
   ```json
   "deny": [
     "Read(./.env)", "Read(./.env.*)", "Read(./secrets/**)", "Read(~/.ssh/**)", "Read(~/.aws/**)",
     "Bash(rm -rf *)", "Bash(git push --force *)", "Bash(git reset --hard *)",
     "Bash(curl *)", "Bash(sudo *)"
   ]
   ```
   `Bash(curl *)` は外部通信を完全には止められない。ネットワーク系は ask にするか sandbox を検討する。
7. **限界を明記する**: Bash ルールはコマンド文字列の一致で判定するため、`/bin/rm -rf`、`bash -c 'rm …'`、`git -C . push` のような書き方は同じ deny に当たらない。確実に止めたいものは PreToolUse hook(`hooks-setup`)や sandbox を併用する。
8. **モードも検討する**: `defaultMode`(`default` / `acceptEdits` / `plan` など)。`bypassPermissions` は隔離環境専用で、共有設定では `"disableBypassPermissionsMode": "disable"` を検討する。
9. **検証**: 設定は厳密な JSON(コメント・末尾カンマ不可)。先頭に `"$schema": "https://json.schemastore.org/claude-code-settings.json"` を入れると補完・検証が効く。反映は `/permissions`(ルールと出所の一覧)と `/status` で確認する。プロジェクト設定の allow はワークスペースの信頼ダイアログ承認後に有効になる。記法の詳細は公式ドキュメント(https://code.claude.com/docs/en/permissions)で確認する。

## 出力フォーマット
````markdown
### 方針
- allow: <対象と理由> / ask: <…> / deny: <…>

### `.claude/settings.json`(チーム共有・コミットする)
```json
{
  "$schema": "https://json.schemastore.org/claude-code-settings.json",
  "permissions": { "allow": [], "ask": [], "deny": [] }
}
```

### `.claude/settings.local.json`(個人・コミットしない)
```json
{ "permissions": { "allow": [] } }
```

### このルールで防げないこと・併用策
### 確認方法
````

## 品質チェックリスト
- [ ] 共有(settings.json)と個人(settings.local.json)を分けた
- [ ] allow が読み取り系・冪等なものに限られ、`Bash(git *)` のような広すぎるルールがない
- [ ] `.env` や鍵などの秘密ファイルが deny に入っている
- [ ] `*` の位置(サブコマンドの後ろ、空白の有無)が意図どおり
- [ ] Bash ルールの限界と、hook / sandbox の併用を説明した
- [ ] JSON として正しい(コメント・末尾カンマなし)

## 例
**入力**: 「テストと lint は毎回聞かないで。push は確認して。.env は絶対に読ませたくない」

**出力(抜粋)**:
> `.claude/settings.json`: `"allow": ["Bash(npm run test *)", "Bash(npm run lint)", "Bash(git status)", "Bash(git diff *)"]`, `"ask": ["Bash(git push *)"]`, `"deny": ["Read(./.env)", "Read(./.env.*)"]`
> 防げないこと: `git -C . push` のような別表記の push は ask に当たらない。確実に止めたい場合は PreToolUse hook を追加する(`hooks-setup` 参照)。
