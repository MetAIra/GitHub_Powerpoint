---
name: noise-reduction
description: ffmpeg で音声のノイズを減らします。afftdn(FFT ノイズ除去)、highpass/lowpass による帯域カット、agate(ゲート)を組み合わせ、やりすぎによる副作用(こもり・水中音・語尾切れ)を避ける設定を示します。「録音のサーッというノイズを消したい」「エアコンの音を減らして」と言われたときに使います。
---

# ノイズ除去

## 目的
声の自然さを保ったまま、ホワイトノイズ・低域のうなり・無音部の環境音を減らす。完全に消すことより「気にならない程度」を目標にする。正規化は処理後に `loudness-normalize`、測定は `audio-qa` エージェントで行う。

## 最初に確認すること
- ノイズの種類: サーッ(ヒス・ホワイト系)/ ブーン(電源ハム 50/60Hz)/ ゴー(空調・低域)/ 話していない間の環境音 / 突発音(咳・クリック)
- ノイズだけが鳴っている区間があるか(先頭 0.5 秒など)。あればノイズプロファイルを取れる
- 声の種類: 低い男性声か高い声か(highpass の周波数に影響)。不明なら **80Hz** で進める
- 既定: **highpass=80 → afftdn=nr=12:nf=-50 → (必要なら) agate** の順で弱めから試す

## 手順
1. **聴いて・測る**: 無音部のノイズフロアを確認する
   ```bash
   ffmpeg -hide_banner -i "rec.wav" -af astats=measure_overall=Noise_floor+RMS_level+Peak_level:measure_perchannel=none -f null - 2>&1 | grep -E "Noise floor|RMS level|Peak level"
   ```
2. **帯域カット(副作用が少ないので最初に)**
   - 低域のゴー・ハンドリングノイズ: `highpass=f=80`(低い声は 60〜70、高い声は 100 まで)
   - 高域のチリチリ: `lowpass=f=12000`(声だけなら 8000〜12000。下げすぎるとこもる)
   - 電源ハム(東日本 50Hz / 西日本 60Hz): `bandreject=f=50:width_type=q:w=10` を倍音(100, 150Hz)にも
3. **afftdn(FFT ノイズ除去)**: `nr`=除去量 dB(0.01〜97、既定 12)、`nf`=ノイズフロア dB(-80〜-20、既定 -50)
   ```bash
   ffmpeg -n -i "rec.wav" -af "highpass=f=80,afftdn=nr=12:nf=-50:tn=1" "out/rec_dn.wav"
   ```
   - `tn=1` でノイズフロアを追従(環境音が変化する録音向け)
   - ノイズだけの区間(先頭 0.4 秒など)からプロファイルを取る:
     ```bash
     ffmpeg -n -i "rec.wav" -af "asendcmd=0.0 afftdn sn start,asendcmd=0.4 afftdn sn stop,afftdn=nr=20:nf=-40" "out/rec_dn.wav"
     ```
   - 何を除去したか聴く: `afftdn=nr=12:nf=-50:om=n` でノイズだけを出力(確認用)
4. **ゲート(話していない間を下げる)**: `agate=threshold=0.02:ratio=4:attack=10:release=250:range=0.1`
   - `threshold` は 0〜1 の振幅比(0.02 ≒ -34 dBFS)。声の小さい語尾より下に設定する
   - `range` は閉じたときの残量(0.1 ≒ -20 dB)。0 に近いほど完全に切れて不自然になる
5. **比較試聴**: 同じ区間を処理前後で聴き比べる(`-ss 60 -t 15` で 15 秒だけ書き出して試す)
6. **確認**: 手順1を出力にも実行し、ノイズフロアが下がり RMS(声)があまり下がっていないことを確認

## やりすぎの副作用(NG 例)
| 症状 | 原因 | 対処 |
|-----|-----|-----|
| 水中・金属的な「シュワシュワ」音 | afftdn の nr が大きすぎ | nr を 6〜10 に下げる、`gs`(gain_smooth)を上げる |
| 声がこもる | lowpass が低すぎ / highpass が高すぎ | lowpass 12k 以上、highpass 100 以下 |
| 語頭・語尾が切れる | ゲートの threshold が高い・attack/release が短い | threshold を下げ、release 300〜500ms |
| 息継ぎで背景がポンピング | ゲートの range が 0 に近い | range=0.1〜0.3 |

## 注意
- 元ファイルを上書きしない(`-n` 既定、`-y` は確認後のみ)
- ノイズ除去は不可逆。処理前の素材は必ず残す
- フィルターの有無はビルドで異なる: `ffmpeg -filters | grep -E "afftdn|agate|arnndn"`
- フィルター連結の `,` はシェルで問題ないが、全体をダブルクォートで囲む(PowerShell も同様)
- 長いログは token-saver の `log-digest` で要約できる

## 出力フォーマット
```markdown
## ノイズ除去プラン
- ノイズの種類: <…>(根拠: 試聴 / astats の Noise floor <値> dB)
- フィルター: <highpass → afftdn → agate>

### コマンド
<試聴用 15 秒版 / 本番>

### 前後比較
| | Noise floor | RMS level | 聴感メモ |
|-|------------|-----------|---------|
| 前 | | | |
| 後 | | | |
```

## 品質チェックリスト
- [ ] ノイズの種類を特定し、帯域カットから弱めに始めた
- [ ] 15 秒程度で前後を聴き比べた
- [ ] 水中音・こもり・語尾切れが出ていない
- [ ] 処理前の素材を残し、別名で出力した
- [ ] 正規化はこの後に行う計画になっている

## 例
入力: 「自宅録音、エアコンのゴーと小さなサーッが気になる」
出力: `highpass=f=90,afftdn=nr=10:nf=-45:tn=1` を 15 秒で試聴→良ければ本番、話していない間がまだ気になれば `agate`(range=0.2)を追加、と段階的に提示。
