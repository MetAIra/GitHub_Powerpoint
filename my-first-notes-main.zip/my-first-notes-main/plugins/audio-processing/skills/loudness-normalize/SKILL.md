---
name: loudness-normalize
description: ffmpeg の loudnorm フィルターで音声・動画の音量をラウドネス基準(LUFS)に揃えます。1パス/2パスの使い分け、配信・ポッドキャスト・放送の目標値の目安、トゥルーピークの上限を扱います。「音量をそろえたい」「-16 LUFS にノーマライズして」と言われたときに使います。
---

# 音量の正規化(loudnorm)

## 目的
エピソード間・動画間で聞こえる音量を揃え、音割れ(クリップ)を防ぐ。最大音量ではなく **ラウドネス(LUFS/LKFS、人が感じる音量)** で揃える。測定だけしたいときは `audio-qa` エージェント、ポッドキャストとしての書き出し全体は `podcast-export` を使う。

## 最初に確認すること
- 入力ファイル(音声のみか、動画の音声か)
- 用途 → 目標値。未指定なら **ポッドキャスト/トーク配信の目安 I=-16, TP=-1.5, LRA=11** で進める
- 精度優先(2パス、既定)か、手早さ優先(1パス)か
- ノイズ除去・BGM ミックスをする場合は、それらの **後** に正規化する(`noise-reduction`、`bgm-mix` を先に)

## 目標値の目安
> 各サービス・放送局の基準は変わることがあるため、提出先の最新の仕様書・ヘルプで確認してください。

| 用途 | 統合ラウドネス I | トゥルーピーク TP |
|-----|----------------|-----------------|
| 音楽・動画配信サービス | -14 LUFS 前後 | -1 dBTP 以下 |
| ポッドキャスト(ステレオ) | -16 LUFS 前後 | -1 dBTP 以下 |
| ポッドキャスト(モノラル) | -19 LUFS 前後 | -1 dBTP 以下 |
| 放送(EBU R128) | -23 LUFS | -1 dBTP |
| 国内テレビ放送(ARIB TR-B32) | -24 LKFS | 提出先の規定による |

## 手順
1. **現状を測る**(ファイルは変わらない)
   ```bash
   ffmpeg -hide_banner -nostats -i "talk.wav" -af ebur128=peak=true -f null - 2>&1 | tail -n 12
   ```
2. **1パス**(手早い。動的に圧縮されるので音の抑揚がやや変わる)
   ```bash
   ffmpeg -n -i "talk.wav" -af loudnorm=I=-16:TP=-1.5:LRA=11 -ar 48000 "out/talk_norm.wav"
   ```
   - loudnorm は内部で 192kHz にアップサンプルするため、**`-ar 48000`(または 44100)を必ず付ける**
3. **2パス(推奨)**: 1 回目で測定、2 回目で測定値を渡し、可能なら線形(音質を変えない単純なゲイン)で揃える
   ```bash
   # 1回目: 測定のみ(JSON が末尾に出る)
   ffmpeg -hide_banner -i "talk.wav" -af loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | tail -n 14
   ```
   出力の `input_i` `input_tp` `input_lra` `input_thresh` `target_offset` を 2 回目に渡す:
   ```bash
   ffmpeg -n -i "talk.wav" -af loudnorm=I=-16:TP=-1.5:LRA=11:measured_I=-27.2:measured_TP=-4.1:measured_LRA=9.8:measured_thresh=-37.6:offset=0.3:linear=true:print_format=summary -ar 48000 "out/talk_norm.wav"
   ```
   - summary の `Normalization Type` が `Dynamic` になっていたら線形にできなかった印。原因は「目標 LRA < 元の LRA」か「ゲインを上げると TP 上限を超える」。LRA を上げる、TP を少し緩める、先にリミッター/コンプをかける、のどれかで対処
4. **動画の場合**: 映像は再エンコードせずコピー
   ```bash
   ffmpeg -n -i "movie.mp4" -c:v copy -af loudnorm=I=-14:TP=-1:LRA=11 -c:a aac -b:a 192k -ar 48000 "out/movie_norm.mp4"
   ```
5. **確認**: 出力に対して手順1を再実行し、I が目標 ±1 LU、TP が上限以下か確認する。詳細な報告は `audio-qa` エージェントへ

## 注意
- 元ファイルを上書きしない。`-n` を既定にし、`-y` は確認後のみ
- MP3/AAC に変換するとピークがわずかに上がるので、TP は -1.5〜-2 dBTP 程度の余裕を見る
- モノラル素材をステレオ再生前提で測るなら `dual_mono=true`
- PowerShell では `2>&1 | Select-Object -Last 14` で末尾を表示。`tail` は無い
- 長いログは token-saver の `log-digest` で要約できる
- 他人の音源を加工・再配布する場合は権利を確認する

## 出力フォーマット
```markdown
## ラウドネス正規化
- 入力: <ファイル>(測定: I <値> LUFS / TP <値> dBTP / LRA <値> LU)
- 目標: I <値> / TP <値> / LRA <値>(用途: <…>、目安のため提出先の仕様を確認)
- 方式: <1パス / 2パス(linear)>

### コマンド
<1回目・2回目>

### 結果
| | I (LUFS) | TP (dBTP) | LRA (LU) | 正規化タイプ |
|-|---------|----------|---------|------------|
| 前 | | | | — |
| 後 | | | | Linear / Dynamic |
```

## 品質チェックリスト
- [ ] 目標値の根拠(用途)を示し、目安である旨を書いた
- [ ] `-ar` で出力サンプルレートを指定した
- [ ] 2パスで Linear になったか確認した(Dynamic なら理由と対処)
- [ ] 出力を再測定し、I ±1 LU・TP 上限以下を確認した
- [ ] ノイズ除去・ミックスの後に正規化している
- [ ] 元ファイルを上書きしていない

## 例
入力: 「収録した対談 WAV を Spotify 向けポッドキャスト用に揃えたい」
出力: 目標 I=-16 / TP=-1.5 / LRA=11 で 2パスを提示。1回目の JSON から値を埋めた 2回目コマンドと、`Dynamic` になった場合の対処を添える。書き出し形式は `podcast-export` へ。
