---
name: podcast-export
description: ポッドキャスト配信用に音声を ffmpeg で書き出します。形式(MP3/AAC)とビットレート、ラウドネス、ID3 メタデータ・カバー画像、チャプターの埋め込みまでを一通り扱います。「ポッドキャスト用に MP3 で書き出したい」「チャプター付きで出力して」と言われたときに使います。
---

# ポッドキャスト向け書き出し

## 目的
編集済みの音声を、配信サービスにそのままアップロードできる形で書き出す。企画・台本・ショーノート・チャプター文面は podcast プラグイン(`show-notes`、`chapter-list` など)で作り、このスキルはファイル化を担当する。

## 最初に確認すること
- 入力(編集済み WAV など)と、番組名・エピソードタイトル・話数・公開年
- 配信先(ホスティングサービス)と、その推奨形式。不明なら **MP3、モノラル 96kbps / ステレオ 128〜192kbps、44.1kHz** で進める
- カバー画像(正方形、多くの配信先で 1400〜3000px が目安。サービスのヘルプで確認)
- チャプター: `chapter-list` で作った時刻リストがあるか
- BGM・効果音・引用音源の権利確認が済んでいるか

## 形式・ラウドネスの目安
> 配信サービスの推奨は変わることがあります。利用するホスティングサービスとディレクトリのヘルプで確認してください。

| 項目 | 目安 |
|-----|-----|
| 形式 | MP3(互換性最優先)/ AAC(.m4a) |
| ビットレート | トーク・モノラル 64〜96kbps、ステレオ・音楽多め 128〜192kbps(CBR が無難) |
| サンプルレート | 44100 または 48000 Hz |
| ラウドネス | ステレオ -16 LUFS 前後 / モノラル -19 LUFS 前後、TP -1 dBTP 以下 |

## 手順
1. **ラウドネスを整える**: `loudness-normalize` の 2パスで WAV のまま目標値に揃える(MP3 化の前に行う)
2. **チャプターファイルを用意する**(任意。ffmetadata 形式、時刻はミリ秒)
   ```text
   ;FFMETADATA1
   [CHAPTER]
   TIMEBASE=1/1000
   START=0
   END=95000
   title=オープニング
   [CHAPTER]
   TIMEBASE=1/1000
   START=95000
   END=1260000
   title=本題: 〇〇について
   ```
   - 文字コードは UTF-8。最後の END はファイルの長さに合わせる
3. **MP3 で書き出す**(メタデータ・カバー・チャプター込み)
   ```bash
   ffmpeg -n -i "ep12_norm.wav" -i "cover.jpg" -i "chapters.txt" -map 0:a -map 1:v -map_metadata 2 -map_chapters 2 -c:a libmp3lame -b:a 128k -ar 44100 -c:v mjpeg -disposition:v attached_pic -id3v2_version 3 -metadata title="#12 〇〇について" -metadata artist="番組名" -metadata album="番組名" -metadata track=12 -metadata date=2026 -metadata genre=Podcast "out/ep12.mp3"
   ```
   - `-id3v2_version 3`: ID3v2.3 は古いプレーヤーでも読める(既定は 2.4)
   - チャプターの表示はアプリ次第。配信サービス側でチャプターを設定する方式もあるので確認する
4. **AAC(.m4a)で書き出す場合**
   ```bash
   ffmpeg -n -i "ep12_norm.wav" -i "chapters.txt" -map 0:a -map_metadata 1 -map_chapters 1 -c:a aac -b:a 128k -ar 44100 -metadata title="#12 〇〇について" -metadata artist="番組名" -movflags +faststart "out/ep12.m4a"
   ```
5. **確認**
   ```bash
   ffprobe -v error -show_entries format=duration,bit_rate:format_tags=title,artist,album:stream=codec_name,sample_rate,channels -show_chapters -of default=nw=1 "out/ep12.mp3"
   ```
   - 音量・ピーク・無音区間は `audio-qa` エージェントで測定
   - 実際のプレーヤー(スマホのポッドキャストアプリ等)でカバーとチャプターの表示を確認

## 注意
- 元ファイルを上書きしない(`-n` 既定、`-y` は確認後のみ)
- libmp3lame はビルド依存(`ffmpeg -encoders | grep mp3`)
- メタデータの日本語は UTF-8 で渡す。Windows の古いコンソールで文字化けする場合は PowerShell 7 以降か、ffmetadata ファイル側に書く
- PowerShell では行継続が `` ` ``。`#` を含む値はダブルクォートで囲む(bash でも同様)
- 長いログは token-saver の `log-digest` で要約できる

## 出力フォーマット
```markdown
## ポッドキャスト書き出し: <番組名> #<話数>
- 入力: <ファイル>(I <値> LUFS / TP <値> dBTP)
- 出力: <ファイル>(<形式>, <kbps>, <Hz>, <mono/stereo>)
- メタデータ: title / artist / album / track / date / カバー <有無> / チャプター <数>
> 形式・ラウドネスは目安です。利用する配信サービスのヘルプで推奨値を確認してください。

### コマンド
<ffmpeg コマンド>

### 確認結果
<ffprobe の要点、audio-qa の結果>
```

## 品質チェックリスト
- [ ] MP3 化の前にラウドネスを整えた(目標と実測を記載)
- [ ] ビットレート・サンプルレートが目安の範囲
- [ ] タイトル・番組名・話数・カバーが入っている
- [ ] チャプターの時刻が音声の長さと矛盾しない
- [ ] 実機のプレーヤーで表示を確認した
- [ ] BGM・引用音源の権利を確認した

## 例
入力: 「第12回を MP3 で。カバー画像とチャプター 4 つを入れたい」
出力: `loudness-normalize` で -16 LUFS に揃えた後、手順2のチャプターファイル(4 項目)と手順3のコマンドを提示。確認用 ffprobe と `audio-qa` での測定を案内。
