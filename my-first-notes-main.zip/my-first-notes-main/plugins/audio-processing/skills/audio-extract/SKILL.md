---
name: audio-extract
description: ffmpeg で動画から音声を取り出したり、MP3・AAC・Opus・WAV・FLAC へ変換したりします。無劣化のコピー抽出、形式とビットレートの選び方、サンプルレート変換、モノラル化を扱います。「動画から音声だけ抜き出したい」「WAV を MP3 にして」と言われたときに使います。
---

# 音声の抽出・変換

## 目的
用途に合った形式で、不要な劣化をさせずに音声を取り出す・変換する。文字起こし用の前処理(python-video の Whisper 系)や編集用素材づくりの入口になる。

## 最初に確認すること
- 入力ファイルと用途: 編集用(劣化させたくない)/ 配布用(軽くしたい)/ 文字起こし用
- 既定: 編集用は **WAV 48kHz 24bit** か **FLAC**、配布用は **AAC 192kbps** か **MP3 192kbps**
- チャンネル: 1 人の声だけならモノラル化してよいか
- 他人の動画・音楽から抽出する場合は、私的利用の範囲か・権利を確認したか

## 手順
1. **中身を調べる**(音声のコーデック・本数を確認)
   ```bash
   ffprobe -v error -select_streams a -show_entries stream=index,codec_name,sample_rate,channels,bit_rate:stream_tags=language -of compact "input video.mp4"
   ```
2. **コピー抽出(無劣化・最速)**: 元のコーデックに合う拡張子で出す
   ```bash
   ffmpeg -n -i "input video.mp4" -vn -map 0:a:0 -c:a copy "out/audio.m4a"
   ```
   - 対応: aac → `.m4a`、mp3 → `.mp3`、opus → `.opus`/`.webm`、pcm → `.wav`。合わない組み合わせはエラーになる
   - 音声が複数ある場合は `-map 0:a:1` のように番号で選ぶ
3. **形式を選んで変換**(判断基準)
   | 形式 | 用途 | 例 |
   |-----|-----|----|
   | WAV(PCM) | 編集素材、最大互換 | `-c:a pcm_s24le -ar 48000` |
   | FLAC | 可逆でサイズ約半分、保管用 | `-c:a flac` |
   | AAC | 動画・Apple 系・汎用配布 | `-c:a aac -b:a 192k` |
   | MP3 | 互換性最優先の配布・ポッドキャスト | `-c:a libmp3lame -b:a 192k`(可変: `-q:a 2`) |
   | Opus | 低ビットレートで高音質、Web・通話 | `-c:a libopus -b:a 96k` |
   ```bash
   ffmpeg -n -i "talk.wav" -c:a libmp3lame -q:a 2 "out/talk.mp3"
   ```
   - libmp3lame・libopus・libfdk_aac はビルドによって無い。`ffmpeg -encoders | grep -E "mp3|opus|aac"` で確認(libfdk_aac は再配布ライセンスの都合で通常のビルドに入っていない。内蔵 `aac` で十分)
   - 非可逆 → 非可逆の変換(MP3 → AAC など)は劣化が重なる。できるだけ元素材から変換する
4. **サンプルレート・ビット深度**
   - 動画・配信は 48000、音楽 CD 由来は 44100。むやみにアップサンプルしない
   - 文字起こし用: `-ar 16000 -ac 1 -c:a pcm_s16le`(Whisper 系は 16kHz モノラルが一般的)
5. **モノラル化**
   - 両チャンネル同じ声: `-ac 1`(左右を平均)
   - 片側だけに声が入っている(ピンマイクを L にだけ録音など): `-af "pan=mono|c0=c0"`(L のみ)。`-ac 1` だと音量が半分になる
6. **部分だけ抽出**: `-ss 00:05:00 -to 00:10:00` を `-i` の前に置く(コピー抽出でも音声はほぼ正確)
7. **確認**: 手順1の ffprobe を出力に実行し、コーデック・サンプルレート・チャンネル・長さが期待どおりか確認

## 注意
- 元ファイルを上書きしない(`-n` 既定、`-y` は確認後のみ)
- `-vn` を付け忘れると、カバー画像やサムネイルが映像として入ることがある
- ファイル名の空白はダブルクォート。PowerShell では `grep` の代わりに `Select-String`
- 大量変換は python-video プラグインの一括処理、長いログは token-saver の `log-digest` へ

## 出力フォーマット
```markdown
## 音声の抽出・変換
- 入力: <ファイル>(音声: <codec>, <Hz>, <ch>, <kbps>)
- 出力: <ファイル>(<codec>, <Hz>, <ch>, <kbps>)/ 方式: <コピー / 変換>
- 理由: <用途に合わせた選択理由>

### コマンド
<ffmpeg コマンド>

### 確認
<ffprobe コマンドと期待値>
```

## 品質チェックリスト
- [ ] 劣化させなくてよい場面ではコピー抽出か可逆形式を選んだ
- [ ] エンコーダがビルドに含まれるか確認した
- [ ] 非可逆の多重変換を避けた
- [ ] モノラル化の方法が録音状態に合っている
- [ ] 元ファイルを上書きしていない
- [ ] 他人の素材なら権利を確認した

## 例
入力: 「会議の録画 MP4 から文字起こし用の音声がほしい」
出力: `ffmpeg -n -i "meeting.mp4" -vn -ar 16000 -ac 1 -c:a pcm_s16le "out/meeting_16k.wav"` を提示。片側マイクなら `pan=mono|c0=c0` を使うよう補足し、文字起こしは python-video プラグインへ案内。
