---
name: bgm-mix
description: ffmpeg で声と BGM をミックスします。amix による音量バランス、sidechaincompress で声に合わせて BGM を自動で下げるダッキング、フェードイン/アウト、BGM の長さ合わせを扱います。「トークに BGM を入れたい」「話している間だけ BGM を小さくして」と言われたときに使います。
---

# BGM のミックスとダッキング

## 目的
声が聞き取りやすく、BGM が邪魔にならないバランスで 1 本の音声(または動画の音声)にまとめる。BGM の選曲や番組構成は podcast プラグイン(`episode-plan` など)、最終的な音量合わせは `loudness-normalize` で行う。

## 最初に確認すること
- 声のファイルと BGM のファイル(動画の場合は動画ファイル)
- BGM の権利: 商用利用・クレジット表記・改変の可否(利用規約を確認。市販曲は原則使えない)
- 方式: 一定音量で敷く(シンプル)か、ダッキング(話す間だけ下げる)か。既定は **ダッキング**
- BGM の長さが足りない場合のループ可否、終わり方(フェードアウト 3 秒を既定)

## 手順
1. **素材のラウドネスを揃えておく**: 声・BGM それぞれを測る(`audio-qa` エージェント、または `ebur128`)。声は先に `noise-reduction` を済ませる
2. **シンプルなミックス(BGM を一定量下げる)**
   ```bash
   ffmpeg -n -i "voice.wav" -i "bgm.mp3" -filter_complex "[1:a]volume=-18dB,afade=t=in:d=2[b];[0:a][b]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[m]" -map "[m]" -ar 48000 "out/mix.wav"
   ```
   - BGM は声より **15〜20 dB 下** が出発点(トークは -18dB 前後、BGM が主役の場面は -10dB 前後)
   - `duration=first`: 声の長さで終える。`normalize=0`: amix の自動縮小を止め、音量を自分で管理(既定の 1 だと入力数で割られて小さくなる)
   - `normalize=0` ではクリップしやすいので、最後に必ず `loudness-normalize` で整える
3. **ダッキング(sidechaincompress)**: 声をサイドチェーンにして BGM を圧縮する
   ```bash
   ffmpeg -n -i "voice.wav" -i "bgm.mp3" -filter_complex "[0:a]asplit=2[v][sc];[1:a]volume=-8dB[b];[b][sc]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=600:makeup=1[duck];[v][duck]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[m]" -map "[m]" -ar 48000 "out/mix_duck.wav"
   ```
   - 1 番目の入力(BGM)が、2 番目(声)の大きさに応じて下がる
   - `threshold`(0〜1 の振幅比): 声で確実に超える値に。小声でも下がらないなら下げる
   - `ratio`: 4〜10。大きいほど深く下がる
   - `release`: 400〜800ms。短いと話の切れ目ごとに BGM が「ポンピング」する
4. **BGM の長さ合わせとフェード**
   - 足りないとき: BGM 入力の前に `-stream_loop -1` を付け、`duration=first` で声に合わせて切る
   - 終わりのフェードアウト: 声の長さを `ffprobe -v error -show_entries format=duration -of csv=p=0 "voice.wav"` で調べ、BGM 側に `afade=t=out:st=<長さ-3>:d=3`
5. **動画に入れる**: 映像はコピーし、ミックスした音声に差し替え
   ```bash
   ffmpeg -n -i "movie.mp4" -i "out/mix_duck.wav" -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest "out/movie_bgm.mp4"
   ```
6. **確認**: 冒頭・話の切れ目・終わりを試聴し、`audio-qa` でピーク・音割れを測る。仕上げに `loudness-normalize`

## 注意
- 元ファイルを上書きしない(`-n` 既定、`-y` は確認後のみ)
- `-stream_loop` は入力オプションなので `-i` の **前** に置く
- PowerShell でもフィルター全体をダブルクォートで囲む。`;` を含むため必須
- 長いログは token-saver の `log-digest` で要約できる

## 出力フォーマット
```markdown
## BGM ミックス
- 声: <ファイル>(I <値> LUFS) / BGM: <ファイル>(I <値> LUFS、ライセンス: <確認済み/要確認>)
- 方式: <一定音量 / ダッキング>、BGM レベル <-18dB>、フェード in <2秒> / out <3秒>

### コマンド
<ffmpeg コマンド>

### 試聴ポイント
- 0:00〜0:10 イントロ / 話の切れ目 <時刻> / 終わり <時刻>
```

## 品質チェックリスト
- [ ] BGM の利用規約(商用・クレジット・改変)を確認した
- [ ] 声が常に BGM より明確に大きい(目安 15 dB 以上の差)
- [ ] ダッキングでポンピングしていない(release が短すぎない)
- [ ] BGM の終わりが唐突に切れない(フェードアウト)
- [ ] ミックス後に正規化・ピーク確認を行う計画
- [ ] 元ファイルを上書きしていない

## 例
入力: 「20 分のトーク WAV に、フリー BGM を薄く敷いて、話している間は下げたい」
出力: 手順3のダッキングに `-stream_loop -1` と終わり 3 秒のフェードを追加したコマンドを提示し、BGM の利用規約確認と、仕上げの `loudness-normalize`(-16 LUFS)を案内。
