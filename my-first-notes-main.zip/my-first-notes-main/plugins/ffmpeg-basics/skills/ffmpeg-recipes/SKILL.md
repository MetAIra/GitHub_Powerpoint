---
name: ffmpeg-recipes
description: 「やりたいこと」から ffmpeg コマンドを組み立てる(形式変換・切り出し・結合・リサイズ・フレームレート変更・回転・音声の削除/差し替え)。「この動画を MP4 にして」「10秒から30秒だけ切り出したい」のような依頼のときに使う。
---

# ffmpeg 逆引きレシピ

## 目的
ユーザーの「やりたいこと」を、元ファイルを壊さない安全な ffmpeg コマンドに変換する。再エンコードとストリームコピー(`-c copy`)のどちらを使うかを毎回判断し、その理由を一言添える。

## 最初に確認すること
- 入力ファイル名と、やりたいこと(未指定の細部は既定値で進める)。
- 画質優先か速度優先か。既定: **劣化させない操作は `-c copy`、それ以外は H.264(`libx264 -crf 23 -preset medium`)+ AAC 128k**。
- 入力の中身が不明なら、先に [ffprobe-inspect](../ffprobe-inspect/SKILL.md) でコーデック・fps・回転情報を確認する。
- 実行環境(bash / zsh か Windows PowerShell か)。不明なら bash で書き、PowerShell の違いを注記する。

## 手順
1. **操作を分類する**: 「コンテナだけ変える・時間で切る・つなぐ」= コピー可能性あり / 「サイズ・fps・回転・フィルター・コーデック変更」= 再エンコード必須。
2. **安全オプションを付ける**: 常に `-n`(出力が既にあれば中止)。`-y` はユーザーが上書きを明示したときだけ。出力は別名(例: `out/元名_trim.mp4`)。
3. **ファイル名はダブルクォート**で囲む(空白・日本語対策)。
4. 下の型から選んで組み立てる。
5. **確認方法を添える**: `ffprobe -v error -show_entries format=duration:stream=codec_name,width,height,r_frame_rate -of compact "out.mp4"` で結果を確認。
6. 他人の動画・音楽を加工・転載する場合は権利(著作権・肖像権・利用規約)の確認が必要と一言添える。

## よく使う型
| やりたいこと | コマンド(bash) | 注意 |
|---|---|---|
| MOV→MP4(中身そのまま) | `ffmpeg -n -i "in.mov" -c copy -movflags +faststart "out.mp4"` | コーデックが MP4 非対応なら失敗→再エンコード |
| 何でも MP4(互換重視) | `ffmpeg -n -i "in.mkv" -c:v libx264 -crf 23 -preset medium -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart "out.mp4"` | `yuv420p` は古い再生機器・ブラウザ向け |
| 切り出し(高速・不正確) | `ffmpeg -n -ss 00:00:10 -to 00:00:30 -i "in.mp4" -c copy "cut.mp4"` | 開始がキーフレームにずれる |
| 切り出し(正確) | `ffmpeg -n -ss 00:00:10 -to 00:00:30 -i "in.mp4" -c:v libx264 -crf 18 -c:a aac "cut.mp4"` | 再エンコードで時間がかかる |
| 結合(同一形式) | 下の concat demuxer | コーデック・解像度・fps が全部同じこと |
| 結合(形式バラバラ) | concat フィルター(下) | 再エンコード必須 |
| 横幅 1280 に縮小 | `-vf "scale=1280:-2"` | `-2` で縦を偶数に自動調整(`-1` は奇数になり得る) |
| 30fps に変更 | `-vf "fps=30"` | `-r 30` より挙動が明確 |
| 90度回転(時計回り) | `-vf "transpose=1"` | 反時計回り `transpose=2`、180度 `transpose=1,transpose=1` |
| 音声を消す | `ffmpeg -n -i "in.mp4" -c copy -an "mute.mp4"` | 再エンコードなし |
| 音声を差し替え | `ffmpeg -n -i "v.mp4" -i "bgm.m4a" -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -shortest "out.mp4"` | `-shortest` で短い方に合わせる |

### -ss の位置
- `-i` の**前**(入力シーク): 速い。再エンコード時は正確(ffmpeg 既定の accurate_seek)。`-c copy` だと直前のキーフレームから始まる。
- `-i` の**後**(出力シーク): 先頭からデコードして捨てるので遅いが確実。
- `-to` を `-i` の前に置くと元動画の時刻、`-i` の後で入力シークと併用すると出力の時刻扱いになりやすい。迷ったら `-ss 開始 -t 長さ` を使う。

### 結合
```bash
# concat demuxer(再エンコードなし)。list.txt は1行1ファイル
printf "file '%s'\n" part1.mp4 part2.mp4 > list.txt
ffmpeg -n -f concat -safe 0 -i list.txt -c copy "joined.mp4"
# concat フィルター(解像度・fps が違うなら事前に scale/fps で揃える)
ffmpeg -n -i a.mp4 -i b.mp4 -filter_complex "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]" -map "[v]" -map "[a]" -c:v libx264 -crf 20 -c:a aac "joined.mp4"
```
- `-safe 0` は絶対パスや記号入りの名前を許可する設定。list.txt 内のファイル名に `'` があると壊れるので名前を変えるのが安全。
- 細かいカット編集は video-editing プラグインの `cut-edit` を参照。

### PowerShell の違い
- 行継続は `\` ではなくバッククォート `` ` ``。`printf` の代わりに `"file 'part1.mp4'" | Out-File -Encoding ascii list.txt` など(BOM 付き UTF-8 だと concat が失敗することがある)。
- フィルター内の `'` と `"` の扱いが bash と違うので、まず1行で書いて試す。

## 出力フォーマット
```markdown
### コマンド
（bash 用コードブロック。必要なら PowerShell 版も）
### 方式
- 再エンコード / ストリームコピー: 〇〇(理由: …)
### 各オプションの要点
- `-ss` … / `-crf 23` … （3〜6行）
### 確認方法
（ffprobe コマンド、再生して確認する箇所）
### 注意
- 上書き防止 `-n`、権利確認、ビルド依存のエンコーダ など
```

## 品質チェックリスト
- [ ] `-n` が付き、出力名が入力名と違う
- [ ] ファイル名をクォートしている
- [ ] コピー/再エンコードの選択理由を書いた
- [ ] フィルター(`-vf` / `-af` / `-filter_complex`)と `-c copy` を同じストリームに併用していない
- [ ] 確認用の ffprobe コマンドを付けた
- [ ] 長い実行ログを読む必要があれば token-saver の `log-digest` に要約を任せられると案内した

## 例
入力: 「スマホで撮った縦動画 IMG_0001.MOV を、横幅720のMP4にしたい」
出力: `ffmpeg -n -i "IMG_0001.MOV" -vf "scale=720:-2" -c:v libx264 -crf 23 -preset medium -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart "IMG_0001_720.mp4"` / 方式: 再エンコード(リサイズのため)/ 注意: iPhone の HEVC・回転メタデータは ffmpeg が自動で回転を適用する(`-noautorotate` で無効化)。
