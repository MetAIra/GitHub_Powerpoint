---
name: ffprobe-inspect
description: ffprobe で動画・音声ファイルの中身(コーデック、解像度、fps、ビットレート、長さ、ストリーム一覧、回転情報)を確認し、結果を読み解く。「この動画の情報を調べて」「fps と解像度を JSON で出したい」と言われたとき、ffmpeg で加工する前の下調べに使う。
---

# ffprobe で情報確認

## 目的
加工前に「何が入っているか」を正確に把握し、コピーで済むか・再エンコードが必要かの判断材料にする。出力は必要な項目だけに絞り、長いログをそのまま貼らない。

## 最初に確認すること
- 対象ファイル(複数なら一覧)。
- 何を知りたいか。未指定なら既定セット(コンテナ・長さ・総ビットレート・各ストリームのコーデック/解像度/fps/サンプルレート/チャンネル)を出す。
- 機械処理に使うか(→ JSON)、人が読むか(→ compact / default)。

## 手順
1. **全体像**: `ffprobe -hide_banner "in.mp4"` の末尾にある `Stream #0:0 ...` 行で概要をつかむ(ログは標準エラー出力)。
2. **必要項目だけ取り出す**(`-v error` で余計な出力を消す):
   ```bash
   ffprobe -v error -show_entries format=format_name,duration,bit_rate:stream=index,codec_type,codec_name,profile,width,height,pix_fmt,r_frame_rate,avg_frame_rate,sample_rate,channels,bit_rate -of json "in.mp4"
   ```
3. **用途別の型**:
   | 知りたいこと | コマンド |
   |---|---|
   | 長さ(秒)だけ | `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "in.mp4"` |
   | 映像の解像度 | `ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "in.mp4"` |
   | fps | `ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate,avg_frame_rate -of compact "in.mp4"` |
   | ストリーム一覧 | `ffprobe -v error -show_entries stream=index,codec_type,codec_name:stream_tags=language,title -of compact "in.mkv"` |
   | 回転情報 | `ffprobe -v error -select_streams v:0 -show_entries stream_side_data -of json "in.mov"`(Display Matrix の rotation) |
   | 正確なフレーム数 | `ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "in.mp4"`(全デコードで遅い) |
   | キーフレーム時刻 | `ffprobe -v error -select_streams v:0 -skip_frame nokey -show_entries frame=pts_time -of csv=p=0 "in.mp4"` |
4. **読み解く**:
   - `r_frame_rate` と `avg_frame_rate` が大きく違う → 可変フレームレート(VFR、スマホ録画に多い)。編集・結合で音ズレの原因になるので `fps=30` 等で固定化を検討。
   - `30000/1001` は 29.97fps。分数のまま表示されるので割り算して示す。
   - `pix_fmt` が `yuv420p10le` などなら 10bit。古い機器で再生できないことがある。
   - `bit_rate` が `N/A` のストリームは MKV 等でよくある。format の bit_rate かファイルサイズ×8÷長さで概算する。
   - 音声の `channels` と `sample_rate`(44100 / 48000)が結合する素材間で違うと concat demuxer が失敗しやすい。
5. **複数ファイルの比較**: bash なら `for f in *.mp4; do echo "$f"; ffprobe -v error ... "$f"; done`。PowerShell なら `Get-ChildItem *.mp4 | ForEach-Object { ffprobe -v error ... $_.FullName }`。
6. JSON をスクリプトで扱うなら `-of json` を `jq` や Python の `json` で読む(Python からの呼び出しは python-video プラグインを参照)。

## 出力フォーマット
```markdown
### ファイル概要: in.mp4
| 項目 | 値 |
|---|---|
| コンテナ | mov,mp4,m4a,3gp,3g2,mj2(MP4) |
| 長さ | 123.45 秒(2:03.45) |
| 総ビットレート | 約 5.2 Mbps |
### ストリーム
| # | 種類 | コーデック | 詳細 |
|---|---|---|---|
| 0 | video | h264 (High) | 1920x1080, 29.97fps(30000/1001), yuv420p |
| 1 | audio | aac (LC) | 48000Hz, 2ch, 128kbps |
### 判断メモ
- コピーで扱える操作 / 再エンコードが必要な理由
- VFR・10bit・回転メタデータなどの注意点
### 使ったコマンド
（再実行できるようにコードブロックで）
```

## 品質チェックリスト
- [ ] `-v error` と `-show_entries` で必要項目に絞った
- [ ] fps を分数と小数の両方で示した
- [ ] VFR・10bit・回転・音声形式の違いなど、後の加工に効く点を指摘した
- [ ] ファイル名をクォートした
- [ ] 推測(例: ビットレート概算)は「概算」と明記した

## 例
入力: 「GoPro の動画2本をつなげたいけど、そのまま結合できる?」
出力: 両ファイルの codec_name / width,height / r_frame_rate / sample_rate,channels を比較表にし、「すべて一致 → concat demuxer + `-c copy` で可(ffmpeg-recipes 参照)」または「fps が 59.94 と 29.97 で不一致 → 再エンコードで揃える必要あり」と判断を返す。
