---
name: ffmpeg-install-check
description: ffmpeg を OS 別(Windows / macOS / Linux)にインストールし、バージョン・使えるエンコーダ・フィルター・ハードウェアアクセラレーションを確認する。「ffmpeg を入れたい」「libx264 や NVENC が使えるか確認して」「Unknown encoder と出る」ときに使う。
---

# ffmpeg のインストールと機能確認

## 目的
「入っているか」だけでなく「必要なエンコーダ・フィルター・GPU 機能がそのビルドに含まれているか」を確認し、コマンドが失敗する原因を事前に潰す。

## 最初に確認すること
- OS とシェル(Windows PowerShell / macOS zsh / Linux bash)。
- 使いたい機能(例: `libx264`、`libsvtav1`、字幕焼き込みの `subtitles`、`drawtext`、NVENC)。未指定なら基本セット(libx264, aac, libopus, subtitles, drawtext)を確認する。
- 会社 PC などで管理者権限・インストール制限がないか。あれば情シスのルールに従う。

## 手順
1. **既にあるか**: `ffmpeg -version`(先頭行のバージョンと `configuration:` 行)、`ffprobe -version`。見つからなければ PATH を確認(`which ffmpeg` / PowerShell `Get-Command ffmpeg`)。
2. **インストール**(公式サイトはソースのみ配布で、バイナリは公式ダウンロードページから辿れる配布元を使う):
   | OS | 方法 | 備考 |
   |---|---|---|
   | macOS | `brew install ffmpeg` | Homebrew。機能はフォーミュラ次第 |
   | Windows | `winget install ffmpeg`(ID は `winget search ffmpeg` で確認)、または公式ページ経由の配布ビルドを展開して `bin` を PATH に追加 | full/essentials などビルド種別で機能が違う |
   | Ubuntu/Debian | `sudo apt install ffmpeg` | ディストリのバージョンは古めのことがある |
   | Fedora | RPM Fusion を有効化して `sudo dnf install ffmpeg` | 標準リポジトリ版は機能が絞られている場合あり |
   インストール後はターミナルを開き直して `ffmpeg -version` を再確認。
3. **エンコーダ**: `ffmpeg -hide_banner -encoders | grep -E "libx264|libx265|libsvtav1|libvpx|aac|libopus|nvenc|qsv|videotoolbox"`(PowerShell: `ffmpeg -hide_banner -encoders | Select-String "libx264|nvenc"`)。詳細オプションは `ffmpeg -h encoder=libx264`。
4. **フィルター**: `ffmpeg -hide_banner -filters | grep -E "subtitles|drawtext|silencedetect|xfade|loudnorm"`。`subtitles` は libass、`drawtext` は libfreetype(フォント名指定は fontconfig)が必要。
5. **ハードウェア**: `ffmpeg -hide_banner -hwaccels` でデコード支援の一覧。エンコーダは手順3の `*_nvenc` / `*_qsv` / `*_videotoolbox` / `*_amf` / `*_vaapi` を確認。**一覧にあっても GPU・ドライバがなければ実行時に失敗**するので、短いテストで確かめる:
   ```bash
   ffmpeg -hide_banner -f lavfi -i testsrc=duration=2:size=1280x720:rate=30 -c:v h264_nvenc -f null -
   ```
6. **動作テスト(ファイル不要)**: `ffmpeg -n -f lavfi -i testsrc=duration=3:size=640x360:rate=30 -f lavfi -i sine=frequency=440:duration=3 -c:v libx264 -c:a aac -shortest "test_out.mp4"` → `ffprobe test_out.mp4` で確認。
7. **よくあるエラー**:
   | メッセージ | 原因 | 対処 |
   |---|---|---|
   | `Unknown encoder 'libx264'` | ビルドに未収録 | 別ビルドを入れる / 別エンコーダ |
   | `No such filter: 'subtitles'` | libass なし | full 系ビルドへ |
   | `Cannot load nvcuda.dll` / `No NVENC capable devices found` | GPU・ドライバ非対応 | ドライバ更新 / ソフトエンコードに戻す |
   | `'ffmpeg' は認識されていません` | PATH 未設定 | PATH に `bin` を追加し再起動 |
   | `libfdk_aac` がない | non-free のため配布ビルドには通常入らない | 標準の `aac` を使う |
8. GPU エンコードの設定最適化は ffmpeg-performance プラグインを参照。

## 出力フォーマット
```markdown
### 環境
- OS / ffmpeg バージョン / ビルド種別
### 機能チェック
| 機能 | 状態 | 確認コマンド |
|---|---|---|
| libx264 | 可 / 不可 | `ffmpeg -encoders \| grep libx264` |
### 次の一手
- 足りない機能と、入れ直す方法 or 代替エンコーダ
```

## 品質チェックリスト
- [ ] OS とシェルに合わせたコマンドを示した
- [ ] 「一覧にある ≠ 動く」ことを伝え、テストコマンドを付けた
- [ ] 非公式サイトや出所不明のバイナリを勧めていない
- [ ] 管理者権限が必要な操作を明示した

## 例
入力: 「Windows で `h264_nvenc` が使えるか知りたい」
出力: `ffmpeg -hide_banner -encoders | Select-String nvenc` で収録確認 → `testsrc` を使ったテストで実際にエンコードできるか確認 → 失敗時は NVIDIA ドライバの更新と GPU 世代の確認を案内し、当面は `libx264` で代替する案を示す。
