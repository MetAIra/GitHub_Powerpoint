---
name: model-serving
description: 学習済みモデル(scikit-learn / ONNX / PyTorch など)を FastAPI の推論 API にし、モデルの読み込みタイミング、入力検証、バッチ推論、タイムアウト、同時実行数、ヘルスチェックまで設計します。「このモデルを API にしたい」「推論エンドポイントが遅い・詰まる」のような依頼で使います。
---

# モデルの API 化(FastAPI)

## 目的
モデルを「起動時に 1 回だけ読み込み、検証済みの入力をバッチで推論し、遅いリクエストで全体が詰まらない」API にする。FastAPI 全般(ルーティング・認証・DB)は python-apps プラグイン、Docker 化は `dockerize`、軽量化は `inference-optimize` に任せる。

## 最初に確認すること
- **モデルの形式**: joblib(sklearn)/ ONNX / PyTorch / Hugging Face。サイズと 1 件あたりの推論時間
- **入出力**: 特徴量の列と型、返すもの(ラベル・確率・上位 k 件)
- **要件**: 想定リクエスト数(件/秒)、許容レイテンシ(既定: p95 で 500ms)、1 リクエストの最大件数(既定: 256)
- **実行環境**: CPU / GPU、メモリ上限、ワーカー数
- **利用者**: 社内のみか外部公開か(認証・レート制限の要否)

## 手順
1. **読み込みは lifespan で 1 回**: リクエストごとに読む(遅い)・import 時に読む(テストで差し替えにくい)のを避ける。
```python
from contextlib import asynccontextmanager
from pathlib import Path
import os, joblib
from fastapi import FastAPI

MODEL_PATH = Path(os.environ.get("MODEL_PATH", "models/model.joblib"))
state: dict = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    state["model"] = joblib.load(MODEL_PATH)   # 信頼できる出どころのファイルだけ
    state["version"] = os.environ.get("MODEL_VERSION", "unknown")
    state["model"].predict(WARMUP_X)           # ウォームアップ(初回の遅さを起動時に払う)
    yield
    state.clear()

app = FastAPI(lifespan=lifespan)
```
   pickle / joblib は読み込むだけで任意コードが実行されうる。ユーザーがアップロードしたモデルを読み込む API は作らない。
2. **入力を Pydantic で検証する**: 件数上限・値の範囲を型で縛る(巨大リクエストによるメモリ枯渇を防ぐ)。
```python
from pydantic import BaseModel, Field

class Features(BaseModel):
    age: int = Field(ge=0, le=120)
    monthly_fee: float = Field(ge=0)
    plan: str = Field(max_length=20)

class PredictRequest(BaseModel):
    instances: list[Features] = Field(min_length=1, max_length=256)

class PredictResponse(BaseModel):
    predictions: list[float]
    model_version: str
```
3. **推論はバッチで**: 受け取った `instances` を 1 つの DataFrame / 配列にまとめて 1 回 `predict` する(1 件ずつのループより大幅に速い)。列の順序と型は学習時と同じにする(学習時の Pipeline ごと保存しておくと安全)。
4. **CPU 処理でイベントループを止めない**: `async def` の中で重い `predict` を直接呼ばない。スレッドに逃がし、同時実行数を制限し、タイムアウトを付ける。
```python
import anyio
from fastapi import HTTPException

limiter = anyio.CapacityLimiter(4)          # 同時推論数(CPU コア数が目安)

@app.post("/predict", response_model=PredictResponse)
async def predict(req: PredictRequest):
    X = to_frame(req.instances)
    try:
        with anyio.fail_after(2.0):          # 秒
            y = await anyio.to_thread.run_sync(
                state["model"].predict_proba, X, abandon_on_cancel=True, limiter=limiter)
    except TimeoutError:
        raise HTTPException(status_code=504, detail="inference timeout")
    return PredictResponse(predictions=y[:, 1].tolist(), model_version=state["version"])
```
   - `abandon_on_cancel=True`(anyio 4.1 以降)がないと、タイムアウトしても推論の終了まで応答が返らない(動作確認済み)。ただしスレッド自体は止まらず裏で走り続けるので、根本対策は推論の高速化と入力件数の上限
   - 単純にしたいなら `def predict(...)`(同期関数)で書けば FastAPI がスレッドプールで実行する
5. **ヘルスチェックを 2 つ用意**: `/healthz`(プロセスが生きている、常に 200)と `/readyz`(モデル読み込み済みなら 200、未完了なら 503)。オーケストレーター(Kubernetes など)の liveness / readiness に対応させる。
6. **ワーカー数とメモリ**: `uvicorn --workers N` はモデルを N 個メモリに載せる。メモリ = モデルサイズ × N + α で見積もる。GPU は 1 プロセスで扱い、ワーカーを増やさない方が安全。
7. **ログと監視**: リクエスト ID・件数・推論時間・モデルバージョンを構造化ログに出す。入力の生データ(個人情報)はログに出さない。詳細は `monitoring`。
8. **動作確認**
```bash
uv run uvicorn myapp.main:app --port 8000
curl -s -X POST localhost:8000/predict -H 'Content-Type: application/json' \
  -d '{"instances":[{"age":34,"monthly_fee":2980,"plan":"basic"}]}'
curl -i localhost:8000/readyz
```
   テストは `fastapi.testclient.TestClient` を `with TestClient(app) as c:` で使う(`with` を付けないと lifespan が走らずモデルが読まれない)。正常系・件数 0 / 上限超過で 422・タイムアウトで 504 を確認する。TestClient が追加パッケージを要求したら、エラーメッセージに従って開発依存に入れる。

### NG 例
- エンドポイント内で `joblib.load()`(毎回数百 ms〜数秒)
- `async def` 内で重い同期処理を直接実行(全リクエストが詰まる)
- 入力件数の上限なし / 例外の詳細(スタックトレース)をそのままクライアントに返す
- 学習時と異なる列順で配列を作る(エラーにならず誤った予測を返す)

## 出力フォーマット
````markdown
## 設計
- モデル / 読み込み方法 / 入出力スキーマ / 上限(件数・タイムアウト・同時実行数)
## コード
```python
(main.py: lifespan、スキーマ、/predict、/healthz、/readyz)
```
## テスト
```python
(TestClient での正常系・異常系)
```
## 起動と確認コマンド
## 性能の見積もり(1 件・256 件の推論時間、ワーカー数とメモリ)
````

## 品質チェックリスト
- [ ] モデルを起動時に 1 回だけ読み込み、ウォームアップしている
- [ ] 入力に件数上限・値の範囲の検証がある
- [ ] 推論がバッチで、学習時と同じ前処理・列順を使う
- [ ] イベントループを止めない(同期関数 or スレッド+同時実行数制限)
- [ ] タイムアウトと 504 応答がある
- [ ] `/healthz` と `/readyz` がある
- [ ] ログにモデルバージョンと推論時間があり、個人情報がない

## 例
入力: 「sklearn の Pipeline を joblib で保存した。FastAPI で返したい。たまに 1 万件まとめて送られて止まる」
出力: lifespan での読み込み、`max_length=256` の入力スキーマ(超えたら 422 で分割送信を案内)、`CapacityLimiter` とタイムアウト付きの推論、TestClient のテスト 3 本。大量件数はバッチ用の別ジョブ(非同期処理)に分ける提案。
