---
name: ci-actions
description: Python プロジェクトの GitHub Actions CI を、lint・型チェック・テスト、依存キャッシュ、Python バージョンのマトリクス、最小権限、秘密情報の安全な扱いまで含めて作ります。「GitHub Actions でテストを自動化したい」「CI が遅い・secrets の扱いが不安」のような依頼で使います。
---

# GitHub Actions の CI(Python)

## 目的
プッシュとプルリクエストごとに lint・型・テストを自動で回し、速く(キャッシュ・並列)、安全に(最小権限・秘密情報を漏らさない)動く workflow を作る。ruff / mypy / pytest 自体の設定は python-core プラグインに任せる。

## 最初に確認すること
- **依存管理**: uv(`uv.lock`)/ pip(`requirements*.txt`)/ poetry。既定は uv
- **ツール**: lint(既定 ruff)、型(既定 mypy。pyright でも可)、テスト(pytest)。`pyproject.toml` に設定があるか
- **対象 Python**: `requires-python` の範囲。マトリクスは下限と最新の 2〜3 本が既定
- **秘密情報の要否**: テストに API キーや DB が必要か(不要にできるならモックを優先)
- **公開リポジトリか**: フォークからの PR を受けるか(secrets の扱いが変わる)

## 手順
1. **workflow を作る**: `.github/workflows/ci.yml`。以下は uv の公式ガイドと setup-uv の action 定義(v10 系)を確認して書いた最小構成。
```yaml
name: CI
on:
  push:
    branches: [main]
  pull_request:
permissions:
  contents: read                       # 最小権限。必要なジョブだけ個別に広げる
concurrency:
  group: ci-${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true             # 同じブランチの古い実行を止める
jobs:
  test:
    runs-on: ubuntu-latest
    timeout-minutes: 15
    strategy:
      fail-fast: false
      matrix:
        python-version: ["3.11", "3.12", "3.13"]
    steps:
      - uses: actions/checkout@v7
      - uses: astral-sh/setup-uv@v10.2.0   # v8 以降は v10 のような短いメジャータグがないので完全なタグか SHA で指定
        with:
          python-version: ${{ matrix.python-version }}
          enable-cache: true
      - run: uv sync --locked --all-extras --dev
      - run: uv run ruff check .
      - run: uv run ruff format --check .
      - run: uv run mypy src
      - run: uv run pytest -q --maxfail=1
```
   - `uv sync --locked` は lock ファイルが `pyproject.toml` と食い違うと失敗する(lock の更新忘れを CI で検出)
   - lint と型はマトリクスの 1 本だけで回すと速い(`if: matrix.python-version == '3.12'`)
2. **キャッシュ**: setup-uv の `enable-cache`(既定 `auto` は GitHub ホストのランナーで有効)は `uv.lock` などのハッシュをキーにする。pip の場合は `actions/setup-python@v7` に `cache: pip` と `cache-dependency-path: requirements*.txt`。キャッシュに秘密情報やビルド成果物の機密を入れない。
3. **アクションのバージョン固定**: 上の `@v7` はメジャータグ、`@v10.2.0` は完全なタグ(いずれも 2026 年 10 月時点の最新。採用時に各リポジトリのリリースを確認)。サプライチェーン攻撃対策として、本番運用ではフルのコミット SHA で固定し、コメントでバージョンを残す(`uses: actions/checkout@<40桁SHA> # v7.0.1`)。Dependabot の `github-actions` エコシステムで更新を自動化する。
4. **秘密情報の扱い**
   - 値は Settings → Secrets and variables → Actions に登録し、`${{ secrets.NAME }}` で**必要なステップの `env:` だけ**に渡す
   - フォークからの `pull_request` には secrets が渡らない。`pull_request_target` で PR のコードを checkout して実行するのは危険(権限付きでフォーク側のコードが動く)なので使わない
   - `run:` の中に `${{ github.event.pull_request.title }}` などを直接埋め込まない(スクリプトインジェクション)。一度 `env:` に入れてから `"$TITLE"` で参照する
   - secrets 以外の機密値をログに出すときは `echo "::add-mask::$VALUE"` で伏せる。`set -x` や `env` の全出力をしない
   - 本番デプロイ用の秘密情報は Environment(承認者付き)に置き、CI のジョブからは参照しない。クラウドへの認証は長期キーより OIDC を優先
5. **ML プロジェクト特有の工夫**
   - 学習済みモデルや大きなデータを CI でダウンロードしない。テストは小さな固定データ(`tests/fixtures/`)と小さなモデルで回す
   - 時間のかかるテストは `@pytest.mark.slow` を付け、PR では `-m "not slow"`、夜間の `schedule:` で全件
   - GPU が必要なテストは GitHub ホストの標準ランナーでは動かないので、マーカーで除外する
6. **動作確認**
   - ローカルで同じコマンドを先に通す: `uv sync --locked && uv run ruff check . && uv run mypy src && uv run pytest -q`
   - YAML の構文は `actionlint` があれば実行(`actionlint .github/workflows/ci.yml`)
   - プッシュ後、Actions タブで全マトリクスが緑になること、2 回目の実行でキャッシュがヒットすることを確認。失敗ログが長ければ token-saver プラグインの `log-digest` に要約させてよい

### NG 例
- `permissions:` 未指定で書き込み権限付きトークンのまま全ジョブを実行
- `run: echo ${{ secrets.API_KEY }}`(マスクされても加工した値は漏れる)
- `uses: some/action@main`(ブランチ参照。中身が勝手に変わる)
- `pip install -r requirements.txt` をバージョン未固定のまま毎回解決(昨日通ったテストが今日落ちる)

## 出力フォーマット
````markdown
## 構成
- トリガー / マトリクス / ジョブ(lint・型・テスト)/ キャッシュ / 権限
## .github/workflows/ci.yml
```yaml
```
## 必要な設定(Secrets・Dependabot・ブランチ保護で必須にするチェック)
## 確認手順と期待結果
````

## 品質チェックリスト
- [ ] `permissions: contents: read` を既定にした
- [ ] lock ファイルを使い、lock のずれで失敗する
- [ ] キャッシュが lock ファイルのハッシュで更新される
- [ ] `concurrency` と `timeout-minutes` で無駄な実行を止める
- [ ] secrets は必要なステップの `env:` だけに渡し、ログに出していない
- [ ] `pull_request_target` で PR のコードを実行していない
- [ ] アクションのバージョンを固定し、更新手段(Dependabot)がある

## 例
入力: 「pip + requirements.txt のプロジェクト。CI で毎回 5 分インストールしている」
出力: `actions/setup-python@v7` の `cache: pip` を使う workflow、lint を 1 本に絞ったマトリクス、`concurrency` 設定。uv へ移行した場合の差分と、2 回目以降の時間短縮の見込みを提示。
