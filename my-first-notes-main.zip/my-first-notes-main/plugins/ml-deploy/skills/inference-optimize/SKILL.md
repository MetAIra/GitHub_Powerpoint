---
name: inference-optimize
description: 学習済みモデルの推論を、計測→バッチ化→スレッド設定→ONNX Runtime への変換→量子化の順に軽量化・高速化し、精度の劣化も検証します。「推論が遅いので CPU で速くしたい」「モデルを小さくしてサーバー代を下げたい」のような依頼で使います。
---

# 推論の軽量化(CPU 中心)

## 目的
精度を許容範囲内に保ったまま、推論のレイテンシ・スループット・メモリ・モデルサイズを改善する。**計測してから**手を打ち、変更ごとに「速さ」と「予測の一致」を数値で確かめる。PyTorch モデルの ONNX 変換や GPU 高速化の詳細は pytorch プラグイン、API 側の作りは `model-serving` に任せる。

## 最初に確認すること
- **モデルの種類**: scikit-learn(線形・木・勾配ブースティング)/ PyTorch / Transformers。ファイルサイズ
- **目標**: 何を何倍にしたいか(例: p95 を 300ms → 100ms、メモリを半分)。既定は「p95 レイテンシを半分」
- **呼ばれ方**: 1 件ずつのオンライン推論か、まとめて流すバッチ推論か。1 回の件数
- **実行環境**: CPU のコア数・命令セット(AVX2 / AVX-512 / ARM)、メモリ上限、コンテナの CPU 制限
- **許容する精度劣化**: 既定は「ラベル一致率 99.5% 以上、確率の最大差 0.01 以下」

## 手順
1. **ベースラインを計測する**: ウォームアップ後に複数回測り、平均ではなく p50 / p95 を見る。
```python
import time, numpy as np

def bench(fn, X, n=50, warmup=5):
    for _ in range(warmup):
        fn(X)
    ts = []
    for _ in range(n):
        t = time.perf_counter(); fn(X); ts.append(time.perf_counter() - t)
    return {"p50_ms": np.percentile(ts, 50) * 1e3, "p95_ms": np.percentile(ts, 95) * 1e3}

print(bench(model.predict_proba, X_1), bench(model.predict_proba, X_256))
```
   前処理(DataFrame の変換、特徴量計算)が遅いことも多い。`python -m cProfile -s cumtime infer.py` でどこが遅いか先に見る。
2. **安い対策から順に**

| 順 | 対策 | 効く場面 | 注意 |
|---|---|---|---|
| 1 | バッチ化(1 件ずつのループをやめる) | ほぼすべて | レイテンシとのトレードオフ |
| 2 | 前処理の効率化(pandas の行ループ削除、事前計算) | 前処理が支配的 | 学習時と結果が一致するかテスト |
| 3 | スレッド数の調整 | コンテナで CPU 制限あり | 制限より多いスレッドは逆に遅い |
| 4 | 軽いモデルに置き換え(木の本数・深さ、蒸留) | モデル自体が重い | 再学習と再評価が必要 |
| 5 | ONNX Runtime | sklearn・PyTorch とも | 変換できない演算・前処理がある |
| 6 | 量子化(INT8) | 全結合・Transformer 系 | 木モデルにはほぼ効かない。精度を必ず検証 |

3. **スレッド数**: コンテナの CPU 上限に合わせる。複数ワーカーで動かすなら「ワーカー数 × スレッド数 ≤ コア数」。環境変数 `OMP_NUM_THREADS`、ONNX Runtime は `SessionOptions.intra_op_num_threads`、scikit-learn 側は `threadpoolctl` で制御できる。
4. **ONNX Runtime に変換する**(scikit-learn の例。skl2onnx 1.20 / onnxruntime 1.31 で確認)
```python
import numpy as np, onnxruntime as ort
from skl2onnx import to_onnx

onx = to_onnx(model, X_train[:1].astype(np.float32), options={"zipmap": False})
open("model.onnx", "wb").write(onx.SerializeToString())

so = ort.SessionOptions()
so.intra_op_num_threads = 2
so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
sess = ort.InferenceSession("model.onnx", so, providers=["CPUExecutionProvider"])
name = sess.get_inputs()[0].name
labels, proba = sess.run(None, {name: X_test.astype(np.float32)})
assert np.allclose(proba, model.predict_proba(X_test), atol=1e-4)
```
   - `zipmap=False` で確率を辞書のリストではなく配列で受け取る(後処理が速い)
   - ColumnTransformer の文字列列など、変換に対応しない前処理は ONNX の外(Python 側)に残す
   - float32 になるため、確率がわずかにずれる。しきい値付近のサンプルでラベルが変わらないか確認
   - PyTorch モデルは `torch.onnx.export`(pytorch プラグインの ONNX 変換を参照)
5. **動的量子化**(重みを INT8 に。キャリブレーションデータ不要)
```python
from onnxruntime.quantization import quant_pre_process, quantize_dynamic, QuantType
quant_pre_process("model.onnx", "model.pre.onnx")     # sympy が必要
quantize_dynamic("model.pre.onnx", "model.int8.onnx", weight_type=QuantType.QInt8)
```
   動作確認の例(全結合 2 層の MLP): サイズ 1,159KB → 297KB、ラベル一致率 100%。速度の改善は CPU とモデル次第でわずかなこともある。静的量子化(活性化も INT8)はキャリブレーション用の代表データが必要で、精度劣化も大きくなりやすい。
6. **精度の劣化を検証する**: 元モデルと最適化後で、検証データ全体の指標(AUC など)・ラベル一致率・確率の最大差を比べる。セグメント別(少数クラスなど)でも確認する。
7. **動作確認**
```bash
uv run python scripts/bench.py --model model.joblib --onnx model.onnx --onnx model.int8.onnx
uv run pytest tests/test_inference_parity.py   # 予測一致のテスト
```
   本番と同じ CPU 制限で測る(`docker run --cpus 2 ...`)。手元の高性能 PC の数字で判断しない。

### NG 例
- 平均レイテンシだけで判断(p95 が悪化していても気づかない)
- 最適化後のモデルを精度確認なしで本番に置き換える
- 4 コアのコンテナでワーカー 4 × スレッド 8 を起動(コンテキストスイッチで遅くなる)
- 出どころ不明の ONNX / pickle ファイルを読み込む(ONNX は pickle より安全だが、ファイルの出どころと改ざん有無は確認する)

## 出力フォーマット
```markdown
## ベースライン
| 条件 | p50 | p95 | メモリ | サイズ |
## 施策と結果
| 施策 | p50 | p95 | サイズ | ラベル一致率 | 指標の変化 |
|---|---|---|---|---|---|
| 元モデル | | | | 100% | - |
| ONNX Runtime | | | | | |
| + INT8 量子化 | | | | | |
## 採用案と理由
## 再現コマンド・テスト
```

## 品質チェックリスト
- [ ] 本番相当の環境・件数で、ウォームアップ後に p50 / p95 を計測した
- [ ] 遅い箇所(前処理かモデルか)を特定してから対策した
- [ ] スレッド数がコンテナの CPU 上限と矛盾しない
- [ ] 最適化前後で予測の一致と指標を比較した
- [ ] 一致を確かめるテストを残した
- [ ] モデルの種類に効かない手法(木モデルの量子化など)を勧めていない

## 例
入力: 「sklearn の RandomForest(500 本、`n_jobs=-1`)。1 件の推論に 120ms かかる」
出力: まず 1 件と 256 件で計測。1 件でも時間が変わらなければ並列化の起動コストが支配的と判断 → 1 件推論では `n_jobs=1` を試す、木の本数を 200 本に減らした場合の精度比較、ONNX Runtime 化の手順と一致テスト。量子化は木モデルに効かないため対象外と説明。
