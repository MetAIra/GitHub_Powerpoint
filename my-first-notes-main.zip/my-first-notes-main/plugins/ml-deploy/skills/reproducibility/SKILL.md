---
name: reproducibility
description: Python / ML プロジェクトの依存と環境を固定し、lock ファイル、Python と CUDA のバージョン、乱数シード、データとモデルのバージョン管理まで含めて「別の人・別のマシン・半年後でも同じ結果が出る」状態にします。「他の PC で動かない」「去年の実験結果が再現できない」のような依頼で使います。
---

# 依存と環境の固定(再現性)

## 目的
「コード・依存・実行環境・データ・乱数」の 5 つを固定または記録し、同じ結果を再現できるようにする。完全に同一のビット列まで揃えるのか、指標が誤差の範囲で一致すればよいのかを最初に決める。

## 最初に確認すること
- **再現したい範囲**: 開発者間で動けばよい / CI と本番を一致させたい / 論文・監査のため結果まで再現したい。既定は「CI と本番の一致+指標が誤差内で再現」
- **現在の依存管理**: `requirements.txt`(バージョン未固定か)/ uv / poetry / conda
- **GPU の有無**: PyTorch などの CUDA 版を使うか。手元と本番の GPU・ドライバ
- **データの置き場所と大きさ**: リポジトリ内 / 共有ストレージ / DB。更新されるか
- **OS の違い**: Windows / macOS / Linux が混在するか(lock は複数 OS 向けに解決されているか)

## 手順
1. **Python のバージョンを固定**: `uv python pin 3.12`(`.python-version` が作られる)。`pyproject.toml` の `requires-python` と矛盾させない。Docker のベースイメージも同じマイナーバージョンにする。
2. **依存を lock する**
   - uv: `uv add pandas scikit-learn` → `uv.lock` をコミット。環境構築は `uv sync --locked`(lock が古ければ失敗)
   - 更新は意図的に: `uv lock --upgrade-package scikit-learn` で 1 つずつ上げ、テストを通してからコミット
   - pip しか使えない環境向け: `uv export --format requirements.txt --no-dev > requirements.lock.txt`(既定でハッシュ付き)→ `pip install --require-hashes -r requirements.lock.txt`
   - `pyproject.toml` は「範囲」(`scikit-learn>=1.6,<2`)、lock は「確定版」と役割を分ける。範囲を `==` で縛りすぎない
3. **CUDA を揃える**: PyTorch の CUDA 版は OS・CUDA のバージョンごとに wheel が分かれる。どの CUDA 版を使うかを `pyproject.toml`(uv ならインデックス設定)で明示し、ドライバの最低バージョンを README に書く。学習環境の `nvidia-smi` と `python -c "import torch; print(torch.__version__, torch.version.cuda)"` の出力を実験記録に残す。細かい設定は pytorch プラグインに任せる。
4. **乱数シードを固定する**
```python
import os, random
import numpy as np

SEED = 42

def set_seed(seed: int = SEED) -> np.random.Generator:
    random.seed(seed)
    np.random.seed(seed)                 # 旧 API を使うライブラリ向け
    os.environ["PYTHONHASHSEED"] = str(seed)  # 子プロセス向け(実行中のプロセスには効かない)
    return np.random.default_rng(seed)   # 自分のコードはこちらを使う
```
   - scikit-learn は各所で `random_state=SEED` を明示する(分割・CV・モデル・探索)
   - GPU の演算や並列処理(`n_jobs=-1`)では、シードを固定しても結果がわずかに揺れることがある。「指標の差が ±0.002 以内なら再現」のように許容幅を決める
5. **データをバージョン管理する**: 大きなファイルは Git に直接入れない。
   - DVC(3.x で確認): `dvc init` → `dvc add data/raw.csv`(`data/raw.csv.dvc` にハッシュが記録される)→ `git add data/raw.csv.dvc data/.gitignore` → `dvc remote add -d storage <保存先>` → `dvc push`。取得は `git checkout <commit> && dvc pull`
   - DVC を入れない場合: データのパス・取得日時・行数・SHA-256(`sha256sum data/raw.csv`)を `data/MANIFEST.md` に記録し、学習時にハッシュを照合する
   - DB から抽出する場合: 抽出 SQL と抽出日時を保存し、抽出結果をスナップショットとして保存する
6. **実験ごとに記録する**: Git のコミット ID(未コミットの変更があれば警告)、lock ファイルのハッシュ、データのハッシュ、シード、ハイパーパラメータ、指標を 1 つの JSON / YAML に保存し、モデルファイルと同じ場所に置く。実験管理ツール(MLflow など)を使っていればそこに記録する。
7. **動作確認**
```bash
git clone <repo> /tmp/repro && cd /tmp/repro
uv sync --locked            # lock どおりに入るか
dvc pull                    # データが取得できるか(DVC 利用時)
uv run python train.py --seed 42 && uv run python train.py --seed 42   # 2 回の指標を比較
```
   CI でも `uv sync --locked` を使い、lock の更新忘れを検出する(`ci-actions` 参照)。

### NG 例
- `pip freeze > requirements.txt` を開発環境から丸ごと出力(関係ない・OS 固有のパッケージが混ざる)
- `pip install torch` のようにバージョンも CUDA 版も指定しない
- データを上書き更新し、どの版で学習したか分からない
- ノートブックのセルを任意の順で実行した結果を「実験結果」として保存(`notebook-hygiene` 参照)
- 秘密情報(DB のパスワード、ストレージのキー)を DVC の設定ファイルに直書きしてコミット(`dvc remote modify --local` でローカル設定に置く)

## 出力フォーマット
```markdown
## 現状診断
| 項目 | 現状 | 問題 | 対応 |
|---|---|---|---|
| Python | 未固定 | 開発 3.13 / 本番 3.11 | `.python-version` で 3.12 に統一 |
| 依存 / CUDA / シード / データ / 実験記録 | | | |
## 変更内容(ファイルとコマンド)
## 再現手順(新しいマシンで)
## 許容する差(指標の誤差範囲)
```

## 品質チェックリスト
- [ ] Python のバージョンが `.python-version` / `requires-python` / Docker で一致
- [ ] lock ファイルがコミットされ、`--locked` で構築している
- [ ] CUDA 版とドライバの要件が明記されている(GPU 利用時)
- [ ] シードを固定し、許容する揺れの幅を決めた
- [ ] データの版をハッシュで特定できる
- [ ] 実験記録にコミット ID・データのハッシュ・シード・指標がある
- [ ] 秘密情報が lock・設定ファイル・記録に含まれていない

## 例
入力: 「requirements.txt に pandas とだけ書いてある。同僚の PC で結果が変わる」
出力: uv への移行手順(`uv init` → `uv add -r requirements.txt` → `uv.lock` をコミット)、`set_seed` と `random_state` の追加箇所、データの SHA-256 を記録する MANIFEST、2 回学習して指標を比べる確認手順。
