---
name: dockerize
description: Python アプリや学習済みモデルを Docker 化し、マルチステージビルド・slim イメージ・uv / pip のキャッシュ・非 root 実行・.dockerignore・GPU 利用時の注意まで含めた Dockerfile を作ります。「この FastAPI アプリを Docker にして」「イメージが 3GB あるので小さくしたい」のような依頼で使います。
---

# Python アプリ / モデルの Docker 化

## 目的
小さく・速くビルドでき・root で動かず・秘密情報を含まないイメージを作る。依存は lock ファイルから入れ、同じ Dockerfile から同じ環境が再現できるようにする。

## 最初に確認すること
- **起動コマンド**: API(uvicorn など)/ バッチ / CLI。ポート番号
- **依存管理**: `uv.lock` / `requirements.txt` / `poetry.lock`。既定は uv(なければ pip の例を使う)
- **Python のバージョン**: `.python-version` や `pyproject.toml` の `requires-python` に合わせる
- **モデルファイル**: サイズと置き場所(イメージに焼く / 起動時にストレージから取得 / ボリューム)。数 GB ならイメージに入れない案を優先
- **GPU の要否**: 必要なら CUDA のバージョンとホストのドライバ
- **ネイティブ依存**: `libgomp`(LightGBM)、`libpq` など apt で必要なもの

## 手順
1. **`.dockerignore` を先に作る**(コンテキストを小さく、秘密情報を入れない)
```
.git
.venv
__pycache__/
*.pyc
.env
.env.*
data/
notebooks/
mlruns/
*.ipynb
tests/
```
2. **Dockerfile(uv・マルチステージ)**: uv 公式ドキュメントの Docker ガイドの構成に、非 root 実行を足したもの。
```dockerfile
# syntax=docker/dockerfile:1
FROM python:3.12-slim AS builder
COPY --from=ghcr.io/astral-sh/uv:0.12.24 /uv /uvx /bin/
ENV UV_COMPILE_BYTECODE=1 UV_LINK_MODE=copy UV_PYTHON_DOWNLOADS=0
WORKDIR /app
RUN --mount=type=cache,target=/root/.cache/uv \
    --mount=type=bind,source=uv.lock,target=uv.lock \
    --mount=type=bind,source=pyproject.toml,target=pyproject.toml \
    uv sync --locked --no-dev --no-install-project --no-editable
COPY . /app
RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync --locked --no-dev --no-editable

FROM python:3.12-slim
RUN groupadd --system app && useradd --system --gid app --no-create-home app
COPY --from=builder --chown=app:app /app/.venv /app/.venv
ENV PATH="/app/.venv/bin:$PATH" PYTHONUNBUFFERED=1
WORKDIR /app
USER app
EXPOSE 8000
CMD ["uvicorn", "myapp.main:app", "--host", "0.0.0.0", "--port", "8000"]
```
   - 依存だけを先に入れる層と、コードを入れる層を分ける(コード変更で依存の再インストールが走らない)
   - `--no-editable` でプロジェクトを venv に入れ、最終ステージにはソースを持ち込まない
   - builder と最終ステージは**同じベースイメージ**にする(venv の python は base の python を指す)
   - 本番では `python:3.12-slim@sha256:...` のようにダイジェスト固定、uv のタグもバージョン固定(`latest` にしない)
3. **pip の場合**: `RUN --mount=type=cache,target=/root/.cache/pip pip install -r requirements.txt` を builder で `python -m venv /opt/venv` に入れ、venv ごとコピーする。`requirements.txt` はハッシュ付き(`--require-hashes`)が望ましい。
4. **apt が必要な場合**: `apt-get update && apt-get install -y --no-install-recommends <pkg> && rm -rf /var/lib/apt/lists/*` を 1 つの `RUN` で。ビルド専用(gcc など)は builder だけに入れる。
5. **秘密情報**: `ENV` / `ARG` / `COPY .env` に API キーを入れない(イメージ履歴に残る)。ビルド時に必要なら `RUN --mount=type=secret,id=pip_token ...` と `docker build --secret id=pip_token,env=PIP_TOKEN`。実行時は環境変数やシークレット管理サービスで渡す。
6. **モデルの置き場所**: 小さいモデルは `COPY models/ /app/models/`。大きいモデルは起動時に取得するか読み取り専用ボリュームでマウントし、イメージとモデルのバージョンを別々に管理する。pickle / joblib のモデルは信頼できる出どころのものだけを読む。
7. **GPU の場合の注意**
   - ホストに NVIDIA ドライバと NVIDIA Container Toolkit が必要。実行は `docker run --gpus all ...`
   - PyTorch の CUDA 版 wheel は CUDA ランタイムを同梱するので、`python:*-slim` ベースでも動くことが多い。CUDA ライブラリを別途使うなら `nvidia/cuda` の `runtime` 系タグ(`devel` は大きいのでビルド時のみ)
   - ホストのドライバが、使う CUDA バージョンに対応しているか確認(`nvidia-smi` の表示で確認)
   - イメージは数 GB になりやすい。CPU 推論で足りるなら `inference-optimize` を先に検討
8. **動作確認**
```bash
docker build -t myapp:dev .
docker run --rm -p 8000:8000 --env-file .env.local myapp:dev   # .env.local は Git 管理外
curl -f http://localhost:8000/healthz
docker run --rm myapp:dev id            # uid が 0(root)でないこと
docker image ls myapp:dev               # サイズの確認
docker history myapp:dev                # 不要な大きい層・秘密情報がないこと
```
   ビルドログが長いときは token-saver プラグインの `log-digest` に要約させてよい。

### NG 例
- `FROM python:3.12`(フルイメージで 1GB 超)のまま本番に出す
- `COPY . .` を依存インストールより前に書く(毎回全依存を再インストール)
- `pip install` を `RUN` ごとにバラバラに実行し、キャッシュを層に残す
- `USER` 指定なし(root で動く)/ `ENV OPENAI_API_KEY=...` の直書き
- `CMD uvicorn ...`(シェル形式)→ シグナルが届かず停止が遅れる。exec 形式 `["..."]` で書く

## 出力フォーマット
````markdown
## 前提
- 起動コマンド / ポート / Python / 依存管理 / GPU 要否
## ファイル
### .dockerignore
### Dockerfile
```dockerfile
```
## 確認コマンドと期待結果
## 注意点(モデルの置き場所、秘密情報の渡し方、イメージサイズの見込み)
````

## 品質チェックリスト
- [ ] `.dockerignore` に `.env`・`.git`・`.venv`・データがある
- [ ] lock ファイルから依存を入れ、依存とコードの層が分かれている
- [ ] 最終ステージが slim 系で、ビルド用ツールを含まない
- [ ] 非 root ユーザーで動く
- [ ] 秘密情報が `ENV` / `ARG` / イメージ内ファイルにない
- [ ] ベースイメージと uv のバージョンが固定されている
- [ ] `docker run` → ヘルスチェックの確認手順がある

## 例
入力: 「scikit-learn のモデルを返す FastAPI アプリ。requirements.txt で管理。イメージが 2.4GB」
出力: `python:3.12` → `python:3.12-slim` のマルチステージ化、pip キャッシュマウント、venv だけをコピー、非 root 化した Dockerfile と `.dockerignore`、`docker image ls` での比較手順。サイズ削減の主因(フルイメージとビルドツールの除去)を説明。
