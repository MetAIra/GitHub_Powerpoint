---
name: word-roots
description: 英単語を接頭辞・語根・接尾辞に分解し、語源から意味を推測したり派生語をまとめて覚えたりできる表と練習を作ります。「語源で英単語を覚えたい」「predict を分解するとどうなる?」といった依頼で使います。
---

# 語源で覚える英単語

## 目的
単語を部品(接頭辞+語根+接尾辞)に分け、知らない語の意味を推測し、1つの語根から派生語を広げて語彙を増やす。テーマ別の単語帳は language-learning の `vocab-builder` に任せ、ここは「分解と派生」に特化する。

## 最初に確認すること
| 項目 | 既定値 |
|---|---|
| 対象 | 分解したい単語、または学びたい語根(不明なら頻出語根から) |
| レベル | CEFR B1〜B2 相当(語源学習は中級以上で効果が出やすい) |
| 数 | 語根5個 × 派生語4〜6語 |

## 頻出の部品
| 種類 | 部品 | 意味 | 例 |
|---|---|---|---|
| 接頭辞 | re- | 再び・元へ | return, rebuild |
| 接頭辞 | pre- | 前に | predict, prepare |
| 接頭辞 | un- / in- (im-, il-, ir-) | 否定 | unhappy, impossible, illegal |
| 接頭辞 | dis- | 否定・離れる | disagree, disappear |
| 接頭辞 | ex- | 外へ | export, exit |
| 接頭辞 | inter- | 間 | international, interview |
| 接頭辞 | trans- | 越えて | transport, translate |
| 接頭辞 | sub- | 下 | subway, submarine |
| 語根 | port | 運ぶ | export, portable, transport |
| 語根 | dict | 言う | predict, dictionary, contradict |
| 語根 | spect | 見る | inspect, respect, spectator |
| 語根 | struct | 建てる | structure, construct, instruct |
| 語根 | mit / miss | 送る | submit, mission, transmit |
| 語根 | vis / vid | 見る | visible, video, revise |
| 語根 | form | 形 | inform, transform, uniform |
| 接尾辞 | -able / -ible | 〜できる(形容詞) | portable, visible |
| 接尾辞 | -tion / -sion | 名詞化 | inspection, mission |
| 接尾辞 | -er / -or / -ist | 人 | inspector, scientist |
| 接尾辞 | -ize / -ify | 動詞化 | organize, simplify |
| 接尾辞 | -ful / -less | 満ちた / ない | careful, careless |
| 接尾辞 | -ly | 副詞化 | quickly |

## 手順
1. 対象語を「接頭辞 / 語根 / 接尾辞」に分け、各部品の意味を書く(例: pre + dict = 前もって言う → 予言する)。
2. 部品の意味をつないだ「直訳」と、実際の意味を並べる。意味がずれている場合はずれ方も説明する。
3. 同じ語根の派生語を4〜6語、品詞を変えて広げる(inspect → inspection, inspector)。
4. 接尾辞による品詞と強勢の変化を注記する(例: **pho**tograph → pho**tog**rapher → photo**graph**ic)。
5. 推測練習: 未知の語を3つ出し、部品から意味を推測させる。
6. 注意: 語源はあくまで記憶の補助。見た目が似ていても語源が違う語(例: pedestrian の ped=足 と pediatric の ped=子ども)や、歴史的に意味が大きく変わった語がある。不確かな語源は「諸説あり・語源辞典で要確認」と書き、作り話の語源を書かない。

## 出力フォーマット
```markdown
# 語源で覚える: 〇〇(語根)

## 分解
| 単語 | 接頭辞 | 語根 | 接尾辞 | 直訳 | 実際の意味 |
|---|---|---|---|---|---|

## 派生語の広がり
- port(運ぶ): export(輸出する)/ import / portable / transport / report

## 品詞と強勢の変化
- …

## 推測練習
1. unpredictable → ?

---
## 解答
1. 予測できない(un + pre + dict + able)

※ 語源は記憶の補助。不確かなものは語源辞典で確認。
```

## 品質チェックリスト
- [ ] 分解が正しく、部品の意味が書いてある
- [ ] 直訳と実際の意味のずれを説明した
- [ ] 派生語が実在し、品詞が変わっている
- [ ] 不確かな語源を断定していない/作り話をしていない
- [ ] 推測練習と解答がある

## 例
入力: 「transport を分解して」
出力(抜粋): trans(越えて)+ port(運ぶ)= 向こうへ運ぶ → 輸送する。派生: portable(持ち運べる)、export(外へ運ぶ=輸出)、import(中へ運ぶ=輸入)、porter(運ぶ人)。
