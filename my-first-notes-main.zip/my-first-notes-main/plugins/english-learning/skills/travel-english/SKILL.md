---
name: travel-english
description: 海外旅行で使う英語(空港・ホテル・レストラン・買い物・交通・トラブル時)と聞き返し方を、そのまま言える短いフレーズ集にまとめます。「海外旅行で使う英語フレーズをまとめて」「ホテルで部屋を替えてほしいとき何て言う?」といった依頼で使います。
---

# 旅行英語

## 目的
旅行中に「最低限これが言えれば困らない」短いフレーズを、場面ごとに用意する。長い会話のロールプレイ台本は language-learning の `conversation-practice` に任せ、ここは「すぐ言える一言」と聞き返し・トラブル対応に特化する。

## 最初に確認すること
| 項目 | 既定値 |
|---|---|
| 行き先 | 英語圏(米が既定。英・豪などは語の違いを注記) |
| 場面 | 全場面の基本セット(指定があれば深く) |
| レベル | CEFR A1〜A2(1フレーズ3〜8語) |
| 特別な事情 | アレルギー・持病・同行者(子ども・高齢者)があれば反映 |

## 基本の万能フレーズ
| 用途 | フレーズ |
|---|---|
| 依頼 | Could I have…, please? / Can I get…? |
| 質問 | Do you have…? / Where is…? / How much is this? |
| 確認 | Is this the right…? / Is … included? |
| 聞き返し | Sorry? / Could you say that again, please? / Could you speak a little more slowly? |
| 確認の言い直し | Do you mean…? / So, … right? |
| 書いてもらう | Could you write it down, please? |
| 断り | No, thank you. / I'm just looking. |

## 場面別
| 場面 | フレーズ |
|---|---|
| 空港・チェックイン | I'd like an aisle/window seat, please. / Can I check this bag? |
| 入国審査 | I'm here for sightseeing. / I'm staying for five days. / I'm staying at [Hotel]. |
| 交通 | How do I get to…? / Does this bus go to…? / One ticket to…, please. |
| ホテル | I have a reservation under [Name]. / Could I change rooms? It's a bit noisy. / What time is checkout? |
| レストラン | A table for two, please. / What do you recommend? / Could we get the check, please?(英: the bill) |
| アレルギー | I'm allergic to nuts. Does this have any nuts in it? |
| 買い物 | Do you have this in a smaller size? / Can I try this on? / Can I pay by card? |
| 道に迷う | I'm lost. Could you show me on the map? |
| トラブル | I lost my passport. / My bag was stolen. / My luggage didn't arrive. |
| 体調 | I don't feel well. / I need a doctor. / Please call an ambulance. |

## 手順
1. 行き先・場面・特別な事情を確認し、必要な場面を選ぶ。
2. 各場面で「言う」フレーズと、相手がよく言う「聞く」フレーズ(例: For here or to go?(米)/ Eat in or take away?(英))をセットにする。
3. 1フレーズは短く、Could you / Can I の型に寄せて覚える数を減らす。
4. 聞き返し方を必ず入れ、「分からないまま Yes と言わない」ことを強調する。
5. トラブル・緊急時は、短い文+相手に見せられるメモ(英語で書いた症状・アレルギー)を用意する。
6. 米英豪で語が違うもの(check/bill, restroom/toilet, elevator/lift)を注記する。
- チップ・マナー・緊急番号・入国の決まりは国や時期で異なるため「出発前に公式情報(大使館・航空会社など)で確認」と書く。具体的な番号や金額を断定しない。

## 出力フォーマット
```markdown
# 旅行英語: 〇〇(行き先: ◯ / A2)

## 万能フレーズ
- …

## 場面別
### ホテル
| 言う | 聞くかも | 意味 |
|---|---|---|

## 聞き返し
- …

## 緊急時のメモ(見せる用)
I'm allergic to [ ]. / I take [medicine].

## 米英の違い
| 米 | 英 | 意味 |
|---|---|---|

※ チップ・緊急番号・入国の決まりは公式情報で要確認
```

## 品質チェックリスト
- [ ] フレーズが短く、レベルに合っている
- [ ] 「言う」と「聞く」がセットになっている
- [ ] 聞き返し方とトラブル時の表現がある
- [ ] 米英などの語の違いを注記した
- [ ] 国ごとに異なる決まり・番号を断定していない

## 例
入力: 「ホテルで部屋のエアコンが壊れていたとき」
出力(抜粋): The air conditioner in my room isn't working. Could someone take a look? / 聞くかも: We'll send someone up right away. / うまくいかなければ: Could I change rooms, please?
