---
name: speaking-frameworks
description: 英語で話すときの型(PREP、1分スピーチ)と、意見を言う・反論する・時間を稼ぐ表現、フィラーの使い方を、レベル別の例付きでまとめます。「英語で意見をうまく言えるようになりたい」「1分スピーチの型を教えて」といった依頼で使います。
---

# スピーキングの型

## 目的
「何から話せばいいか分からない」をなくすため、英語の話の組み立て方(型)と、その型に入れる定型表現を用意する。場面別のロールプレイ台本は language-learning の `conversation-practice`、相手役との対話練習は agent `conversation-partner` に任せ、ここは「話の骨組みと表現」に特化する。

## 最初に確認すること
| 項目 | 既定値 |
|---|---|
| レベル | CEFR B1 相当 |
| 場面 | 会議・面接・雑談・試験のスピーキング のどれか(不明なら一般的な意見を述べる場面) |
| 話す長さ | 1分(約100〜130語) |
| お題 | あれば使う。なければ身近なお題を1つ出す |

## 型
| 型 | 構成 | 向く場面 |
|---|---|---|
| PREP | Point → Reason → Example → Point | 意見・質問への回答 |
| 1分スピーチ | 結論(10秒)→ 理由1・2(各20秒)→ まとめ(10秒) | 自己紹介・試験・朝礼 |
| STAR | Situation → Task → Action → Result | 面接で経験を話す |
| 比較 | Option A → Option B → My choice + why | どちらがよいか問われたとき |

## 型に入れる表現
| 機能 | ふつう | 丁寧・改まった |
|---|---|---|
| 結論を言う | I think… / For me, … | In my view, … / I'd argue that… |
| 理由 | That's because… / The main reason is… | One reason for this is… |
| 例 | For example, … / Like when I… | To give you an example, … |
| まとめ | So, … / That's why I think… | In short, … / To sum up, … |
| 賛成 | I agree. / Good point. | I completely agree with you on that. |
| 部分的に賛成 | I see your point, but… | That's true to some extent, however… |
| 反論 | I'm not sure about that. | I see it a bit differently. / I'm afraid I don't quite agree. |
| 確認・聞き返し | So you mean…? | Just to make sure I understand, … |
| 時間を稼ぐ | Let me think. / That's a good question. | Let me think about that for a second. |
| 言い直す | I mean, … / What I'm trying to say is… | To put it another way, … |

## フィラーの使い方
- 使ってよい: well, so, you know, I mean, let me see, um は「考え中」の合図として自然。日本語の「えーと」「あのー」を英語に混ぜない。
- 使いすぎない: like / you know を1文に何度も入れると幼く・自信がなく聞こえる。会議・面接では Let me think. のような文で間を取るほうがよい。
- 沈黙より合図: 2〜3秒以上黙るなら That's a good question. Let me think. と言ってから考える。

## 手順
1. 場面とお題を決め、型を1つ選ぶ(迷ったら PREP)。
2. 日本語で言いたいことを型の枠に箇条書き(1枠1行)。
3. 各枠を上の表現で英語にする。レベルに合わせて1文を短く(B1 で10〜15語)。
4. 1分のモデル回答を作り、各部分に型のラベル([P][R][E][P])を付ける。
5. 練習: ①モデルを音読 → ②メモ(キーワードだけ)で話す → ③別のお題で同じ型 → ④録音して時間を測る。
6. 反論や質問への返し方を2〜3パターン付ける(部分的に賛成 → 自分の意見、が角が立ちにくい)。
- 英語圏でも場面・相手によって直接さの好みは違うので「一般的な傾向」として書く。

## 出力フォーマット
```markdown
# スピーキングの型: 〇〇(型: PREP / 1分 / B1)

## 枠(日本語メモ)
- P: … / R: … / E: … / P: …

## モデル回答
[P] … [R] … [E] … [P] …(約◯語)

## 使った表現
| 機能 | 表現 |
|---|---|

## 反論・質問への返し
- 相手: … → あなた: …

## 練習チェック
- [ ] メモだけで1分話せた
- [ ] 2秒以上の沈黙がなかった(つなぎ表現を使えた)
```

## 品質チェックリスト
- [ ] 型と場面が合っている
- [ ] モデル回答に型のラベルがあり、長さが目安どおり
- [ ] 丁寧さの段階に合った表現を選んだ
- [ ] フィラーの使いすぎに注意を促した
- [ ] 反論・時間稼ぎの表現がある

## 例
入力: 「Is working from home a good idea? に PREP で」
出力(抜粋): [P] I think it's a good idea, at least a few days a week. [R] The main reason is that it saves commuting time. [E] For example, I get about an hour back every day, so I can exercise. [P] That's why I think a mix of home and office works best.
