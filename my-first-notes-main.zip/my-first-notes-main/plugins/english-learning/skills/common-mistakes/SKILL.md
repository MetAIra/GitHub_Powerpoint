---
name: common-mistakes
description: 日本語話者に多い英語の誤り(冠詞、可算/不可算、時制、前置詞、直訳表現)と和製英語を、×→○と理由付きで整理し、自分の弱点チェックリストを作ります。「和製英語で通じないものを知りたい」「日本人がやりがちな英語のミスをまとめて」といった依頼で使います。
---

# 和製英語と日本人に多い誤り

## 目的
日本語の発想から生まれる誤りをパターンで覚え、自分の英文で見つけられるようにする。個別の作文の添削は language-learning の `writing-correction`、文法項目の体系的な解説は `grammar-explain` に任せ、ここは「日本語話者に典型的なズレ」の一覧と見つけ方に特化する。

## 最初に確認すること
| 項目 | 既定値 |
|---|---|
| 扱う範囲 | 全カテゴリから代表例(指定があればそのカテゴリを深く) |
| レベル | CEFR A2〜B1 相当 |
| 自分の英文 | あれば、その中の誤りをパターンに分類して優先する |

## 誤りのカテゴリと代表例
| カテゴリ | × | ○ | 理由 |
|---|---|---|---|
| 冠詞 | I have dog. | I have a dog. | 単数の可算名詞は裸で使わない |
| 冠詞 | I went to the school by the bus. | I went to school by bus. | 本来の目的の school、手段の by には付けない |
| 可算/不可算 | many informations / advices | a lot of information / some advice | 不可算。数えるなら a piece of advice |
| 可算/不可算 | furnitures, baggages | furniture, baggage(米は luggage も) | 不可算 |
| 時制 | I live in Tokyo since 2020. | I have lived in Tokyo since 2020. | since と継続は現在完了 |
| 時制 | When I will arrive, I'll call you. | When I arrive, I'll call you. | 時・条件の節は現在形で未来を表す |
| 前置詞 | I arrived to Osaka. | I arrived in Osaka. | arrive in(都市・国)/ at(地点) |
| 前置詞 | discuss about the plan | discuss the plan | discuss は他動詞 |
| 前置詞 | enter into the room | enter the room | 物理的に入るなら前置詞なし |
| 直訳 | I'm boring. | I'm bored. | boring は「退屈させる側」 |
| 直訳 | My hobby is watching movies. | I like watching movies. / In my free time, I watch movies. | hobby は能動的な趣味に使うことが多い |
| 直訳 | Please teach me your email. | Could you tell me your email address? | teach は技能・教科を教える |
| 直訳 | I can't eat raw fish.(嫌いなだけ) | I don't like raw fish. | can't は「体質的・物理的に無理」と取られうる |
| 語法 | It's very delicious. | It's really good. / It's delicious. | delicious は強い語で very と合いにくい |

## 和製英語(通じにくい語)
| 和製英語 | 英語での言い方(米) | 注 |
|---|---|---|
| マンション | apartment / condo | mansion は大邸宅 |
| コンセント | outlet(英: socket) | |
| ノートパソコン | laptop | |
| サラリーマン | office worker | |
| クレーム | complaint | claim は「主張・請求」 |
| アンケート | survey / questionnaire | 仏語由来 |
| ガソリンスタンド | gas station(英: petrol station) | |
| フロントガラス | windshield(英: windscreen) | |
| シャープペンシル | mechanical pencil | |
| ペットボトル | plastic bottle | |
| テンションが高い | excited / energetic | tension は緊張 |
| スマート(細い) | slim | smart は「賢い」 |

## 手順
1. ユーザーの英文があれば、誤りを上のカテゴリに分類する(なければ代表例から始める)。
2. 各誤りに × → ○ → 理由(1文のルール)を付ける。日本語の発想(なぜ間違えるか)も1行添える。
3. 和製英語は英語での言い方と、誤解されるとどうなるか(mansion=大邸宅など)を示す。英米差は注記。
4. 自分用の「弱点チェックリスト」を作る(多かった誤り上位3〜5個を、英文を見直すときの問いにする)。
5. 確認問題(誤文訂正5問)と解答を最後に置く。
- 地域差・揺れがある語法は「〜が一般的」「要確認」とし、断定しない。

## 出力フォーマット
```markdown
# 日本人に多い誤り: 〇〇

## 誤りの一覧
| カテゴリ | × | ○ | 理由 | なぜ間違えるか |
|---|---|---|---|---|

## 和製英語
| 和製英語 | 英語 | 注 |
|---|---|---|

## 私の弱点チェックリスト
- [ ] 単数の可算名詞に a / the を付けたか
- [ ] 不可算名詞に s を付けていないか

## 誤文訂正
1. I'm interesting in music.

---
## 解答
1. I'm interested in music.(人の気持ちは -ed)
```

## 品質チェックリスト
- [ ] すべての × に ○ と理由がある
- [ ] 日本語の発想からの原因を説明した
- [ ] 和製英語に英米差を注記した
- [ ] 弱点チェックリストが見直しの問いになっている
- [ ] 揺れのある語法を断定していない

## 例
入力: 「I'm very exciting to go abroad. I'll buy many souvenir.」
出力(抜粋): exciting → excited(気持ちは -ed)/ many souvenir → a lot of souvenirs(可算の複数形)。弱点: -ed/-ing の取り違え、複数形の s 落ち。
