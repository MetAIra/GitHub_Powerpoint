---
name: business-english
description: 英語のビジネスメール、会議、プレゼン、電話・オンライン会議で使う表現を、丁寧さの段階付きでまとめ、そのまま使える文面やフレーズ集を作ります。「英語で納期延長をお願いするメールを書きたい」「英語の会議で使う表現を知りたい」といった依頼で使います。
---

# ビジネス英語

## 目的
仕事の場面で「失礼にならず、簡潔に伝わる」英語を書けて話せるようにする。日本語の敬語をそのまま訳すのではなく、英語の丁寧さの仕組み(依頼の仕方・クッション言葉・直接さ)で表す。場面のロールプレイ練習は language-learning の `conversation-practice`、話の組み立ての型は本プラグインの `speaking-frameworks` を参照する。

## 最初に確認すること
| 項目 | 既定値 |
|---|---|
| 場面 | メール / 会議 / プレゼン / 電話・オンライン会議(必須) |
| 相手 | 社外・初めて(丁寧)/ 社外・既知 / 社内 |
| 目的 | 依頼・お礼・お詫び・確認・催促・断り など |
| レベル | CEFR B1 相当 |
| 英米 | アメリカ英語(日付は 10/9/2026 が米式、英は 9/10/2026。誤解を避けるなら October 9, 2026) |

## 丁寧さの段階(依頼の例)
| 段階 | 表現 | 使う相手 |
|---|---|---|
| とても丁寧 | I would appreciate it if you could… / Would it be possible to…? | 社外・目上・大きなお願い |
| 丁寧 | Could you please…? / Would you mind …ing? | 社外・ふつうの依頼 |
| ふつう | Can you…? / Please… | 社内・同僚 |
| 直接 | Send me… | 親しい同僚・緊急(命令に聞こえるので避けがち) |
- please を付けても命令文は命令。丁寧さは疑問文・仮定(would/could)・クッション言葉(I was wondering if…)で上げる。
- 日本語の「お世話になっております」「よろしくお願いします」に一対一の訳はない。冒頭は I hope you're doing well.(省略可)、末尾は Thank you for your help. / Best regards, など目的に合わせる。

## 場面別の定型
| 場面 | 表現 |
|---|---|
| メール冒頭(用件) | I'm writing to… / I'm reaching out regarding… |
| 添付 | Please find attached… / I've attached… |
| 催促 | I'm just following up on my email from Monday. |
| お詫び | I apologize for the delay. / Sorry for any inconvenience. |
| 断り | Unfortunately, we're unable to… / I'm afraid that won't be possible. |
| 会議・開始 | Let's get started. / The purpose of today's meeting is… |
| 会議・意見 | From my perspective, … / Could I add something? |
| 会議・まとめ | So, to summarize, … / The next steps are… |
| プレゼン | Today I'd like to talk about… / Let's move on to… / Any questions? |
| 電話 | This is 〇〇 from △△. / Could you hold on a moment? |
| オンライン会議 | You're on mute. / Can everyone see my screen? / Sorry, you broke up. Could you repeat that? |

## 手順
1. 場面・相手・目的から、丁寧さの段階を決める。
2. メールは「件名(内容が分かる具体的なもの)→ 挨拶 → 用件(1文目で目的)→ 詳細 → 依頼・次の行動 → 締め → 署名」の順。1段落2〜3文、全体は短く。
3. 会議・プレゼン・電話は、開始/意見/確認/まとめ の各段階の定型を用意する。
4. 丁寧さの段階を変えた言い換えを2つ付ける。
5. 日本語からの直訳になりがちな箇所(「ご検討ください」→ Please consider. は冷たく響くことがある → I'd appreciate it if you could consider…)を注記する。
6. 社名・金額・日付・氏名はプレースホルダー([Name])にし、送信前に確認する項目を書く。
- 契約・法務に関わる文面は、社内の担当者・専門家の確認を促す。

## 出力フォーマット
```markdown
# ビジネス英語: 〇〇(場面: メール / 相手: 社外 / 段階: 丁寧)

## 文面
Subject: …

Dear [Name],(米: Hi [Name], も可・関係性による)
…
Best regards,
[Your Name]

## 言い換え(丁寧さの段階)
| 段階 | 表現 |
|---|---|

## 直訳に注意
- …

## 送信前チェック
- [ ] 日付・金額・氏名
```

## 品質チェックリスト
- [ ] 相手と目的に合った丁寧さの段階
- [ ] 1文目で用件が分かる/全体が簡潔
- [ ] 日本語の決まり文句を直訳していない
- [ ] 日付の米英差など誤解の起きる点を注記した
- [ ] 固有情報はプレースホルダー/法務関連は確認を促した

## 例
入力: 「社外の取引先に、資料の提出を1週間延ばしてほしいとお願い」
出力(抜粋): Subject: Request to extend the deadline for the report / I'm writing to ask if it would be possible to extend the deadline by one week, to October 16. … I apologize for any inconvenience this may cause.
