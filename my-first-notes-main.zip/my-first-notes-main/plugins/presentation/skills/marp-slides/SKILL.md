---
name: marp-slides
description: Marp(Markdown でスライドを作るツール)形式のスライドファイル(.md)を、frontmatter・テーマ・改ページ・画像配置・発表者ノートまで正しい記法で生成します。「Marpでスライドを作って」「Markdownでプレゼン資料を書きたい」「この構成案をMarpにして」「VS Codeでスライドを作りたい」といった依頼で使います。
---

# Marp スライド生成

## 目的
構成案や原稿から、Marp for VS Code / Marp CLI でそのまま表示・PDF/PPTX 出力できる Markdown ファイルを生成する。記法ミス(`marp: true` 忘れ、改ページ不備、画像サイズ指定の誤り)をなくす。

## 最初に確認すること
- **中身**: 構成案・原稿があればそれを使う。なければ slide-outline スキルで先に構成を作る
- **テーマ**: `default`(既定値)/ `gaia` / `uncover`
- **サイズ**: `16:9`(既定値、1280x720)/ `4:3`(960x720)
- **ページ番号・ヘッダー/フッター**: 既定値 ページ番号あり、フッターに資料名
- **画像**: 使うファイルのパスまたはURL(不明なら `images/xxx.png` の仮パスで置き、差し替え箇所を明記)
- **出力先ファイル名**: 既定値 `slides.md`

## 手順
1. 先頭に frontmatter(グローバルディレクティブ)を書く。`marp: true` がないと Marp として描画されない。
2. スライドの区切りは **前後に空行を入れた `---`** の1行。frontmatter の閉じ `---` の直後から1枚目が始まる。
3. 1枚ごとに見出し(`#` または `##`)=キーメッセージを置き、本文は箇条書き3〜5行を目安にする。
4. 特定スライドだけの装飾はローカルディレクティブ(HTMLコメント)で指定する。先頭に `_` を付けるとそのスライドのみに適用(スポット)、付けないと以降すべてに適用される。
5. 画像は下記の記法で配置する。
6. 発表者ノートは、ディレクティブ以外の HTML コメント `<!-- ... -->` に書く(発表者ビューと PPTX のノートに入る)。
7. 日本語フォントや細部の見た目は frontmatter の `style:` で最小限に調整する。
8. 出力方法(下記)を添えて渡す。

### 主要ディレクティブ
| 記法 | 意味 |
|---|---|
| `marp: true` | Marp を有効化(必須) |
| `theme: default` | テーマ(default / gaia / uncover) |
| `size: 16:9` | スライド比率(組み込みテーマで 16:9 / 4:3) |
| `paginate: true` | ページ番号表示 |
| `header: '...'` / `footer: '...'` | ヘッダー/フッター文字列 |
| `class: lead` | 中央寄せレイアウト(default/gaia)。`invert` で反転配色 |
| `backgroundColor:` / `color:` | 背景色 / 文字色 |
| `math: mathjax` | 数式(`katex` も可) |
| `<!-- _class: lead -->` | このスライドのみ中央寄せ(表紙・章扉に) |
| `<!-- _paginate: false -->` | このスライドのみページ番号を消す |
| `<!-- _header: '' -->` | このスライドのみヘッダーを消す |

### 画像の記法
| 記法 | 効果 |
|---|---|
| `![w:600](img.png)` / `![h:300](img.png)` | 幅/高さ指定(`width:600px` も可) |
| `![bg](img.jpg)` | 背景全面(既定は cover) |
| `![bg contain](img.jpg)` / `![bg fit](img.jpg)` | 背景を切らずに収める |
| `![bg right](img.jpg)` / `![bg left:40%](img.jpg)` | 分割背景(左右に配置、幅指定可) |
| `![bg](a.png)` を複数行 | 背景を横に並べる(`![bg vertical](a.png)` で縦) |
| `![bg opacity:.3](img.jpg)` | 半透明背景(`blur` `grayscale` `sepia` 等のフィルタも可) |
| `# <!-- fit --> 大見出し` | 見出しを枠いっぱいに自動拡大 |

## 出力フォーマット
```markdown
---
marp: true
theme: default
size: 16:9
paginate: true
footer: '<資料名>'
style: |
  section { font-family: "Noto Sans JP", "Hiragino Sans", "Meiryo", sans-serif; }
  section.lead h1 { font-size: 56px; }
---

<!-- _class: lead -->
<!-- _paginate: false -->
<!-- _footer: '' -->

# <タイトル>
<所属・氏名>
<日付>

---

## <キーメッセージ(1文)>

- 根拠1
- 根拠2

<!-- 発表者ノート: ここで話す内容 -->

---

![bg right:40%](images/xxx.png)

## <キーメッセージ>

- 左側に本文、右40%に画像
```

出力方法: VS Code 拡張「Marp for VS Code」でプレビュー/エクスポート、または
`npx @marp-team/marp-cli@latest slides.md --pdf`(PPTX は `--pptx`、HTML は `-o slides.html`)。ローカル画像を PDF/PPTX に含める場合は `--allow-local-files` を付ける。

## 品質チェックリスト
- [ ] frontmatter の先頭に `marp: true` がある
- [ ] 改ページ `---` の前後に空行がある(文字行の直後に空行なしで `---` を置くと、改ページではなく見出し(setext 記法)扱いになる)
- [ ] 表紙・章扉は `_class: lead` など `_` 付きで、以降のスライドに波及していない
- [ ] 画像サイズは `w:` `h:` か `bg` で指定し、はみ出していない(1枚の本文は目安7行以内)
- [ ] 画像パスがファイルからの相対パスで、差し替えが必要な仮パスを明記した
- [ ] 発表者ノートがディレクティブと混同されていない(`_class:` などのキー形式で書かない)
- [ ] 見出しがキーメッセージ(主張のある1文)になっている

## NG例
- `marp: true` なし → 普通の Markdown として表示される
- `<!-- class: lead -->`(`_` なし)を表紙に書く → 全スライドが中央寄せになる
- `![](img.png){width=300}` → Pandoc 記法で Marp では効かない。`![w:300](img.png)` と書く
- `<img src="...">` に頼る → 既定では多くの HTML タグが無効(CLI は `--html`、VS Code は設定 `markdown.marp.enableHtml` で有効化が必要)

## 例
入力: 「表紙+結論+根拠(画像あり)の3枚、gaiaテーマで」
出力: 上記テンプレートの `theme: gaia` 版。2枚目 `## 経費精算SaaSで年1,200時間を削減できる`、3枚目に `![bg left:45%](images/effect.png)` と根拠3行、各スライド末尾に発表者ノートのコメント。
