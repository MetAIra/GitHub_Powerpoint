---
name: dataframe-prep
description: pandas / Polars で CSV・Parquet などを読み込み、型の指定、欠損処理、結合、集計、ウィンドウ関数、大きなデータのメモリ対策までの前処理コードを書きます。「この CSV を pandas で整形して」「Polars で書き直したい」のような依頼で使います。
---

# pandas / Polars 前処理

## 目的
分析・学習に渡す前のデータを「型が正しく、欠損の扱いが決まっていて、結合で行が増減していない」状態にする。処理は関数かメソッドチェーンにまとめ、再実行で同じ結果になるコードにする。Excel / スプレッドシート上の整形は spreadsheet プラグインの `data-cleansing` に任せる。

## 最初に確認すること
- **ライブラリ**: 既定は pandas。数 GB 以上・速度重視・新規コードなら Polars を提案。インストール済みのバージョンを `python -c "import pandas, polars; print(pandas.__version__, polars.__version__)"` で確認する
- **データ**: パス、形式(CSV / Parquet / Excel)、行数の目安、文字コード(日本の業務 CSV は `cp932` のことがある)
- **キー**: 1 行が何を表すか(注文 1 件、顧客 1 人など)。結合キーと期待する対応(1:1 / 多:1)
- **欠損の意味**: 「未入力」「0」「該当なし」のどれか。わからなければ欠損フラグ列を残して進める

## 手順
1. **読み込み時に型を決める**: 必要な列だけ、型を指定して読む。日付は文字列のまま残さない。
2. **診断**: `df.info()`、`df.isna().sum()`、`df.describe()`(Polars は `df.null_count()`、`df.describe()`)。キーの重複を `df.duplicated(subset=key).sum()` で確認。
3. **型の修正**: 数値化できない値は `pd.to_numeric(errors="coerce")` で NaN にし、件数を数えてから扱いを決める。カテゴリは `category`(Polars は `pl.Categorical`)。
4. **欠損処理**: 列ごとに「削除・定数埋め・前方埋め・フラグ化」を決める。学習用の補完(平均値など)はここでせず、sklearn の Pipeline 内で行う(`sklearn-ml` 参照)。
5. **結合**: 結合前後の行数を必ず比べる。pandas は `validate=` と `indicator=True`、Polars は `validate=` を使う。
6. **集計・ウィンドウ**: 名前付き集計で列名を明示する。時系列のずらし(lag)や累積は必ずソートしてからグループ内で行う。
7. **保存**: 中間データは Parquet で保存(型が保たれる)。CSV に戻すのは最終出力だけ。
8. **動作確認**: 行数・キー一意性・合計値の assert を書き、`pytest` または関数末尾で検証する。

### 書き方対応表(pandas 3.0 / Polars 2.0 で動作確認)
| 処理 | pandas | Polars |
|---|---|---|
| 列追加 | `df.assign(x=lambda d: d.a * 2)` | `df.with_columns((pl.col("a") * 2).alias("x"))` |
| 絞り込み | `df[df.a > 0]` / `df.query("a > 0")` | `df.filter(pl.col("a") > 0)` |
| 集計 | `df.groupby("k", observed=True).agg(total=("a", "sum"))` | `df.group_by("k").agg(pl.col("a").sum().alias("total"))` |
| グループ内合計を各行に | `df.groupby("k")["a"].transform("sum")` | `pl.col("a").sum().over("k")` |
| 累積・lag | `groupby("k")["a"].cumsum()` / `.shift(1)` | `pl.col("a").cum_sum().over("k")` / `.shift(1).over("k")` |
| 移動平均 | `.rolling(7, min_periods=1).mean()` | `pl.col("a").rolling_mean(window_size=7, min_samples=1)` |
| 結合 | `df.merge(o, on="id", how="left", validate="many_to_one")` | `df.join(o, on="id", how="left", validate="m:1")` |
| 片方にない行 | `indicator=True` で `_merge` を見る | `df.join(o, on="id", how="anti")` |
| 遅延評価 | なし | `pl.scan_parquet(p).filter(...).collect()` |

### 最小例(pandas)
```python
import pandas as pd

def load_orders(path: str) -> pd.DataFrame:
    df = pd.read_csv(
        path,
        usecols=["order_id", "customer_id", "ordered_at", "amount", "status"],
        dtype={"status": "category"},
        parse_dates=["ordered_at"],
        encoding="utf-8",  # 業務 CSV なら "cp932" を試す
    )
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    assert df["order_id"].is_unique, "order_id が重複しています"
    return df

def add_customer(orders: pd.DataFrame, customers: pd.DataFrame) -> pd.DataFrame:
    out = orders.merge(customers, on="customer_id", how="left", validate="many_to_one")
    assert len(out) == len(orders), "結合で行数が変わりました"
    return out
```

### 大きなデータのメモリ対策
- 読む列を絞る(`usecols` / `columns=`)。文字列の繰り返しは `category`。数値は `pd.to_numeric(downcast="float")` で小さい型に
- 実メモリは `df.memory_usage(deep=True).sum()`、Polars は `df.estimated_size("mb")` で測る
- pandas で収まらないなら `chunksize=` で分割集計、または Polars の `scan_csv` / `scan_parquet` + `.collect(engine="streaming")`(フィルタと列選択がスキャン時に適用される。`lf.explain()` で確認)

### NG 例
- `df[df.a > 0]["b"] = 0`(連鎖代入)。pandas 3.0 以降は Copy-on-Write が常に有効で、元の df は**変わらない**。`df.loc[df.a > 0, "b"] = 0` と書く
- 全部 NaN のグループを `sum()` すると 0 になる。欠損を 0 と区別したいなら `sum(min_count=1)`
- pandas 3.0 では文字列列の既定 dtype が `str`。`object` 前提の古いコード(`dtype == object` 判定)は見直す

## 出力フォーマット
````markdown
## 前処理の内容
| 列 | 元の型 | 変換後 | 欠損数 | 扱い |
|---|---|---|---|---|

## コード
```python
(関数にまとめた前処理)
```

## 検証
- 行数: 読み込み N 行 → 出力 M 行(差分の理由)
- キー一意性 / 合計値のチェック結果
- 確認コマンド: `python -m pytest tests/test_prep.py`
````

## 品質チェックリスト
- [ ] 読み込み時に型と列を指定している
- [ ] 結合前後の行数を assert し、`validate=` を付けている
- [ ] 欠損の扱いを列ごとに説明できる。学習用の補完を前処理でしていない
- [ ] ウィンドウ処理の前にソートしている
- [ ] 連鎖代入がない(pandas)/ 不要な `.collect()` の途中挿入がない(Polars)
- [ ] 中間データを Parquet で保存している

## 例
入力: 「orders.csv(300 万行)と customers.csv を結合して、顧客ごとの月次売上を出したい。メモリが足りない」
出力: Polars の `scan_csv` で必要列だけ読み、`join(validate="m:1")` → `group_by("customer_id", pl.col("ordered_at").dt.truncate("1mo"))` で集計、`collect(engine="streaming")` するコードと、行数・合計値の検証手順を返す。
