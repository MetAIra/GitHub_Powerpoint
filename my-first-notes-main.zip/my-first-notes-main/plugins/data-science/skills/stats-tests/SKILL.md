---
name: stats-tests
description: 比較したいデータの種類から適切な統計検定(t 検定、カイ二乗、ノンパラメトリック、多重比較の補正)を選び、scipy / statsmodels のコードと、効果量・信頼区間を含めた誤解のない解釈文を作ります。「A と B の差は有意?」「どの検定を使えばいい?」のような依頼で使います。
---

# 統計検定の選び方と解釈

## 目的
「差があるか」を p 値だけで判断せず、**効果量(差の大きさ)と信頼区間**を併記して、実務的に意味のある差かどうかを言える状態にする。結論の書き方で誤解(p 値の誤読)を生まない。

## 最初に確認すること
- **問い**: 2 群の比較 / 3 群以上 / 前後比較(同じ人)/ 割合の比較 / 関連の強さ
- **データの型**: 連続値・順序・カテゴリ(件数)
- **対応の有無**: 同じ対象を 2 回測ったか(対応あり)、別々の対象か
- **サンプルサイズと取り方**: 各群の n、無作為割付か観察データか(観察データは因果を言えない)
- **事前に決めた仮説・有意水準**: 既定は両側検定、α=0.05。データを見てから検定を選び直さない
- 医療・臨床判断に関わる結論は一般的な解説にとどめ、専門家(生物統計家など)の確認を勧める

## 手順
1. **検定を選ぶ**(scipy 1.17 / statsmodels 0.15 で動作確認)

| 比較 | 第一選択 | 前提が怪しいとき | 効果量 |
|---|---|---|---|
| 2 群の平均(独立) | Welch の t 検定 `ttest_ind(a, b, equal_var=False)` | Mann-Whitney U `mannwhitneyu` | Cohen's d / Hedges' g |
| 2 群(対応あり) | 対応のある t 検定 `ttest_rel` | Wilcoxon 符号順位 `wilcoxon` | 差の平均 / 差の SD |
| 3 群以上の平均 | 一元配置分散分析 `f_oneway`(等分散が怪しければ Welch の ANOVA) | Kruskal-Wallis `kruskal` | η² / ω² |
| 割合・クロス集計 | カイ二乗 `chi2_contingency` | 期待度数 5 未満のセルが多い→ Fisher `fisher_exact`(2×2) | Cramér の V `contingency.association` / リスク差 |
| 2 群の割合 | `statsmodels` の `proportions_ztest` | 少数なら Fisher | 割合の差と CI |
| 関連の強さ | Pearson `pearsonr` | Spearman `spearmanr` | r そのもの |

   - 等分散かどうかで t 検定を切り替える(Levene → Student)二段階の方法は推奨しない。最初から Welch を使う
   - 正規性の検定(Shapiro)は n が大きいとわずかな歪みでも有意になる。ヒストグラム・QQ プロットと n で判断する(n が各群 30 程度以上なら t 検定は頑健なことが多い)

2. **検定を実行し、効果量と信頼区間を出す**
```python
import numpy as np
from scipy import stats

res = stats.ttest_ind(a, b, equal_var=False)          # Welch
ci = res.confidence_interval(confidence_level=0.95)   # 平均の差の CI
def cohens_d(x, y):
    nx, ny = len(x), len(y)
    sp = np.sqrt(((nx - 1) * np.var(x, ddof=1) + (ny - 1) * np.var(y, ddof=1)) / (nx + ny - 2))
    return (np.mean(x) - np.mean(y)) / sp
print(f"t={res.statistic:.2f}, p={res.pvalue:.3f}, 差の95%CI=[{ci.low:.2f}, {ci.high:.2f}], d={cohens_d(a, b):.2f}")

chi = stats.chi2_contingency(table)                   # table: 2 次元の件数表
print(chi.statistic, chi.pvalue, chi.dof, chi.expected_freq.min())
```
   分布を仮定したくない場合は `stats.bootstrap((x,), np.mean)` で CI を出す。

3. **多重比較を補正する**: 検定を複数回するなら補正が必要(5 回の検定で少なくとも 1 回偽陽性になる確率は約 23%)。
   - 少数の検定・強い制御: Holm(`statsmodels.stats.multitest.multipletests(p, method="holm")`)
   - 多数の検定(探索的): FDR / Benjamini-Hochberg(`stats.false_discovery_control(p)`)
   - ANOVA 後の全ペア比較: Tukey HSD(`stats.tukey_hsd(a, b, c)`)
4. **必要なサンプルサイズ**(事前の計画時): `statsmodels.stats.power.TTestIndPower().solve_power(effect_size=0.5, alpha=0.05, power=0.8)` → 1 群約 64。
5. **解釈文を書く**: 「p<0.05 だから効果がある」で終えず、差の大きさ・CI・実務上の意味・限界を書く。
6. **動作確認**: 結果を再現できるよう、乱数を使う処理は `random_state` を固定し、スクリプトとして実行する(`python analysis/ab_test.py`)。

### p 値のよくある誤解(NG → 正しい言い方)
- NG「p=0.03 なので仮説が正しい確率は 97%」→ p 値は「差がないと仮定したとき、これ以上極端なデータが出る確率」
- NG「p=0.20 なので差はない」→「この n では差を検出できなかった」。CI が広ければ判断保留
- NG「p=0.001 なので効果が大きい」→ n が大きければ小さな差でも p は小さくなる。効果量で語る
- NG 有意になるまで n を増やす / 外れ値を除く / 指標を変える(p ハッキング)

### 効果量の目安(Cohen の慣例。分野により異なる)
| 指標 | 小 | 中 | 大 |
|---|---|---|---|
| d | 0.2 | 0.5 | 0.8 |
| r / Cramér の V(自由度 1) | 0.1 | 0.3 | 0.5 |

## 出力フォーマット
```markdown
## 問いと検定の選択
- 問い / データ型 / 対応 / n
- 選んだ検定と理由(前提の確認結果)
## 結果
| 指標 | 値 |
|---|---|
| 群ごとの平均(または割合)と n | |
| 差と 95% 信頼区間 | |
| 検定統計量 / p 値(補正後) | |
| 効果量 | |
## 解釈
(差の大きさ、実務上の意味、限界。因果を言えるかどうか)
```

## 品質チェックリスト
- [ ] データ型・対応の有無から検定を選んだ理由を書いた
- [ ] 効果量と信頼区間を p 値と併記した
- [ ] 複数検定に補正をかけた(または 1 回だけと明記した)
- [ ] 有意でない結果を「差がない」と書いていない
- [ ] 観察データで因果を断定していない
- [ ] コードを再実行して同じ数値が出る

## 例
入力: 「新しいボタンのクリック率が A: 120/2,400、B: 156/2,380。差はある?」
出力: 2 群の割合の比較として `proportions_ztest([156, 120], [2380, 2400])`(z≈2.30, p≈0.021)と `confint_proportions_2indep(156, 2380, 120, 2400)` を実行。「B は A より約 +1.6 ポイント高い(95% CI: +0.2〜+2.9 ポイント)。CI の下限は小さく、効果は 0.2 ポイント程度の可能性もある。曜日・流入元の偏りは要確認」と解釈する。
