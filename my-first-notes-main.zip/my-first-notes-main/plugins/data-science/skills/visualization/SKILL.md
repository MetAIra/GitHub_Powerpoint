---
name: visualization
description: Python のデータ可視化コードを、matplotlib / seaborn / plotly の使い分け、伝わるグラフの原則、日本語フォントの設定まで含めて書きます。「このデータをグラフにして」「matplotlib で日本語が文字化けする」のような依頼で使います。
---

# Python でのデータ可視化

## 目的
分析結果を「1 枚 1 メッセージ」で伝わるグラフにし、再実行で同じ画像が出るコードとして残す。グラフ種類の選び方の一般論は presentation プラグインの `data-to-chart`、Excel のグラフは spreadsheet プラグインに任せ、ここでは Python コードに集中する。

## 最初に確認すること
- **用途**: 探索用(自分が見る・速さ優先)か、報告用(他人に見せる・体裁優先)か。既定は探索用
- **出力先**: ノートブック / PNG(資料貼り付け)/ HTML(操作できるグラフ)
- **伝えたいこと**: 比較・推移・分布・関係・構成のどれか。1 文で言えなければ先に決める
- **環境**: OS(日本語フォントの有無)、ライブラリのバージョン

## 手順
1. **ライブラリを選ぶ**

| 状況 | 選択 | 理由 |
|---|---|---|
| 探索で分布・カテゴリ比較を素早く | seaborn | DataFrame と列名で書ける。`hue` で層別が簡単 |
| 報告用 PNG を細部まで整える | matplotlib(seaborn で描いて matplotlib で整える) | 軸・注釈・余白を全部制御できる |
| 操作できる HTML・ダッシュボード | plotly(`plotly.express`) | ホバー・ズーム。`write_html` で共有 |
| 数十万点の散布図 | 集計してから描く(hexbin / 2D ヒストグラム) | 点の重なりで情報が消える |

2. **日本語フォントを設定する**(文字化け=豆腐 □ の対策)
```python
import matplotlib.pyplot as plt
import seaborn as sns

JP_FONTS = ["Noto Sans CJK JP", "Hiragino Sans", "Yu Gothic", "Meiryo", "IPAexGothic", "sans-serif"]
plt.rcParams["font.family"] = JP_FONTS          # 見つかった最初のフォントが使われる
sns.set_theme(style="whitegrid", rc={"font.family": JP_FONTS})
# 入っているか確認: python -c "import matplotlib.font_manager as fm; print([f.name for f in fm.fontManager.ttflist if 'CJK' in f.name or 'Gothic' in f.name])"
```
   - Linux / Docker では `fonts-noto-cjk`(Debian/Ubuntu)を入れる。入れた後に反映されなければ matplotlib のキャッシュ(`matplotlib.get_cachedir()`)を削除
   - `japanize-matplotlib` は手軽だが、新しい Python で動かない報告があるため、上の rcParams 方式を既定にする
   - plotly は `fig.update_layout(font_family="Noto Sans JP, sans-serif")`(表示側のブラウザのフォントが使われる)

3. **伝わるグラフの原則を適用する**
   - タイトルは「何のグラフか」ではなく**結論**を書く(NG「月別売上」→ OK「11 月以降、売上が前年比 2 割減」)
   - 強調したい 1 系列だけ色を付け、残りはグレー。凡例よりも線の端に直接ラベル
   - 棒グラフの軸は 0 から。並びは値の大きい順(順序に意味がある場合を除く)
   - 円グラフ・3D・二重軸は原則使わない(比較しにくい、誤解を招く)
   - 軸ラベルに単位(円、件、%)。桁が大きければ「万円」に換算
   - 色覚多様性に配慮: 赤と緑だけで区別しない。seaborn の `colorblind` パレットや形・線種を併用

4. **報告用の型**
```python
fig, ax = plt.subplots(figsize=(8, 4.5), layout="constrained")
colors = ["#d62728" if c == "大阪" else "#bbbbbb" for c in df["store"]]
bars = ax.barh(df["store"], df["sales_man"], color=colors)
ax.bar_label(bars, fmt="%.0f 万円", padding=3)
ax.invert_yaxis()                                  # 大きい順を上に
ax.spines[["top", "right"]].set_visible(False)
ax.set(title="大阪店だけが目標を上回った(2026 年 9 月)", xlabel="売上(万円)")
fig.savefig("out/sales_by_store.png", dpi=200, bbox_inches="tight")
```
   探索なら `sns.histplot(data=df, x="amount", hue="plan")`、`sns.boxplot`、`sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag", vmin=-1, vmax=1)` で十分。

5. **plotly で共有する**: `px.line(df, x="date", y="sales", color="store")` → `fig.write_html("out/sales.html", include_plotlyjs="cdn")`。PNG 出力(`write_image`)には別途 `kaleido` が必要。

6. **動作確認**: スクリプトとして実行して画像を開き、文字化け・ラベルの重なり・軸の 0 起点を目視確認する。
   `MPLBACKEND=Agg python plot_sales.py && ls -la out/`(画面のない環境では Agg バックエンド)

## 出力フォーマット
````markdown
## グラフの意図
- 伝えたいこと: (結論 1 文)
- 種類と理由: 横棒グラフ(店舗間の比較、ラベルが長いため)
## コード
```python
(フォント設定 + 描画 + 保存)
```
## 確認ポイント
- 出力先: out/xxx.png(dpi 200)
- 目視確認: 文字化け / 重なり / 軸の起点 / 単位
````

## 品質チェックリスト
- [ ] タイトルが結論になっている
- [ ] 日本語が文字化けしない(フォント設定+確認コマンド)
- [ ] 強調は 1 か所、残りは控えめな色
- [ ] 軸ラベルと単位がある。棒グラフは 0 起点
- [ ] 色だけに頼らず区別できる
- [ ] 画像の保存先・解像度がコードに明記されている

## 例
入力: 「店舗別の売上を棒グラフにしたら日本語が □ になった」
出力: フォールバック付きの `font.family` 設定、フォントの有無を確かめるコマンド、Docker なら `apt-get install -y --no-install-recommends fonts-noto-cjk`、値の大きい順に並べた横棒グラフのコード。
