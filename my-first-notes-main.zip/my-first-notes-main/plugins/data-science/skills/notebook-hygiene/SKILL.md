---
name: notebook-hygiene
description: Jupyter ノートブックを、上から順に実行すれば同じ結果になる状態に整理し、関数化・.py モジュールへの移行・出力のクリア・Git での管理・再現性の確保まで行います。「このノートブックを整理して」「ipynb を .py にしたい」のような依頼で使います。
---

# Jupyter ノートブックの整理

## 目的
試行錯誤で散らかったノートブックを「**カーネル再起動 → 全セル実行**で同じ結果になる」状態にし、再利用するロジックは `.py` に移して import する。ノートブックは「結果を読む場所」、`.py` は「処理を置く場所」に分ける。

## 最初に確認すること
- **ノートブックの役割**: 探索メモ / 共有用レポート / 定期実行するバッチ。バッチなら最終的に `.py` 化を勧める
- **実行環境**: ローカル / JupyterLab / VS Code / Google Colab。依存の管理方法(uv / pip / conda)
- **Git 管理の有無**: 管理しているなら出力の扱い(消す/残す)を決める。既定は「消してコミット」
- **データの場所と機密性**: 出力セルに個人情報・API キーが表示されていないか

## 手順
1. **現状診断**: 実行番号(`[12]`, `[3]`, `[27]` …)が飛んでいる・逆順のセルを探す。未定義変数への依存、上書きされた変数、セル内の `!pip install` を洗い出す。
   `python -c "import json,sys; nb=json.load(open(sys.argv[1])); print([c.get('execution_count') for c in nb['cells'] if c['cell_type']=='code'])" analysis.ipynb`
2. **構成を固定する**: 次の順にセルを並べ替える。
   1. タイトルと目的(Markdown)
   2. import とバージョン表示(`pandas.__version__` など)
   3. 設定: パス・定数・乱数シード(`SEED = 42`)。パスは `pathlib.Path` で相対指定
   4. データ読み込み
   5. 前処理 → 分析 → 可視化
   6. 結論(Markdown。数値はセルの出力を見て書く)
3. **関数化**: 3 回以上コピーされた処理、20 行を超えるセルは関数にする。グローバル変数に依存させず引数で渡す。
4. **`.py` へ移す**: 安定した関数は `src/<pkg>/` に移し、ノートブックから import する。編集を自動反映させるなら先頭で `%load_ext autoreload` と `%autoreload 2`。移した関数には `pytest` のテストを付ける。
5. **ペア化(任意)**: jupytext で `.ipynb` と `.py` を同期すると差分レビューが楽になる。
   `jupytext --set-formats ipynb,py:percent analysis.ipynb` → 編集後 `jupytext --sync analysis.ipynb`
6. **出力のクリアと Git**: 出力・実行番号・メタデータを除いてコミットする。
   - その場で消す: `nbstripout analysis.ipynb`(出力+メタデータ)。`jupyter nbconvert --clear-output --inplace` は出力だけ消し、一部メタデータが残る
   - Git の filter で自動化: `nbstripout --install`(リポジトリに設定。`--keep-output` で残す指定も可)
   - CI での検査: `nbstripout --verify notebooks/*.ipynb`(消すべきものが残っていれば非 0 で終了。nbstripout 0.9 で確認)
7. **再現性**: 乱数シードを固定(`np.random.default_rng(SEED)`、sklearn の `random_state=SEED`)。依存は lock ファイルで固定(詳細は ml-deploy プラグインの `reproducibility`)。`!pip install` はノートブックから消し、`pyproject.toml` に移す。
8. **秘密情報**: API キーを直書きしない。`os.environ["API_KEY"]` または `.env`(`.gitignore` に追加)から読む。出力セルに表示されたキーや個人情報は、出力クリアだけでなく Git 履歴にも残っていないか確認する。
9. **動作確認**: カーネルを再起動して全セル実行し、エラーなく最後まで通ることを確かめる。
   `jupyter nbconvert --to notebook --execute analysis.ipynb --output /tmp/executed.ipynb`
   長い実行ログは token-saver プラグインの `log-digest` に要約させてよい。

### NG 例
- セル 5 で定義した変数をセル 3 で使っている(上から実行すると NameError)
- `df = df[...]` を同じセルで何度も実行する前提(実行回数で結果が変わる)
- 絶対パス `C:\Users\tanaka\Desktop\data.csv`(他人の環境で動かない)
- 分析結果の結論を Markdown に手書きし、データ更新後も古い数値のまま

## 出力フォーマット
```markdown
## 診断結果
| 重要度 | セル | 問題 | 対応 |
|---|---|---|---|
| 高 | [7] | セル [9] で定義した `df_clean` を参照 | 順序を入れ替え |
## 整理後の構成
1. 目的 / 2. import・設定 / 3. 読み込み / …
## .py に移した関数
- `src/sales/prep.py`: `load_orders()`, `add_customer()`(テスト: tests/test_prep.py)
## 実行確認
- `jupyter nbconvert --to notebook --execute ...` で全セル成功
- Git: nbstripout 設定済み
```

## 品質チェックリスト
- [ ] カーネル再起動 → 全セル実行でエラーなく同じ結果になる
- [ ] import・設定・シードが先頭にまとまっている
- [ ] 再利用する処理は `.py` に移し、テストがある
- [ ] パスが相対指定で、秘密情報が直書きされていない
- [ ] 出力をクリアしてコミットする仕組みがある
- [ ] 結論の数値が最新の出力と一致している

## 例
入力: 「先輩から引き継いだ 80 セルのノートブックが上から実行すると途中で落ちる」
出力: 実行番号の一覧から依存関係の崩れたセル 4 か所を特定、セル順の修正案、前処理 3 関数を `src/` に移す差分、`nbstripout --install` と `nbconvert --execute` での確認手順。
