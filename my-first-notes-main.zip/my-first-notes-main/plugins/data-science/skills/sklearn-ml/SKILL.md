---
name: sklearn-ml
description: scikit-learn で、Pipeline と ColumnTransformer による前処理、交差検証、ベースラインを含むモデル比較、ハイパーパラメータ探索、特徴量の重要度までをリークなく組みます。「scikit-learn で分類モデルを作って」「交差検証の書き方を直したい」のような依頼で使います。
---

# scikit-learn で機械学習

## 目的
表形式データの分類・回帰モデルを、**前処理込みの Pipeline** として作り、テストデータに一切触れずにモデル選択し、最後に 1 回だけテストで評価する。深層学習は pytorch プラグイン、本番 API 化は ml-deploy プラグインの `model-serving` に任せる。

## 最初に確認すること
- **タスク**: 分類(2 値 / 多クラス)か回帰か。目的変数の列名
- **評価指標**: 業務上の損失に合わせる。既定は 2 値分類=ROC-AUC(不均衡なら PR-AUC=`average_precision` も)、回帰=MAE
- **データの構造**: 時系列か(未来で過去を予測しない)、同一顧客の行が複数あるか(グループ分割が必要)
- **データ量と時間**: 数十万行以上なら `HistGradientBoosting*` を中心に、探索回数を絞る
- **バージョン**: `python -c "import sklearn; print(sklearn.__version__)"`(以下は 1.9 で動作確認)

## 手順
1. **最初にテストを切り離す**: `train_test_split(..., stratify=y, random_state=42)`。時系列なら期間で切る(最後の N か月をテスト)。以降、テストは最終評価まで使わない。
2. **分割方法を決める**

| データ | CV | 注意 |
|---|---|---|
| 通常の分類 | `StratifiedKFold(5, shuffle=True, random_state=42)` | クラス比を保つ |
| 同一人物・同一店舗の行が複数 | `GroupKFold` / `StratifiedGroupKFold` | 同じグループを学習と検証に分けない |
| 時系列 | `TimeSeriesSplit(n_splits=5, gap=...)` | `gap` で特徴量の集計期間ぶん空ける |

3. **前処理を Pipeline に入れる**: 補完・スケーリング・エンコードは**必ず Pipeline 内**で(CV の各分割の学習側だけで fit される)。
```python
from sklearn.compose import ColumnTransformer, make_column_selector as sel
from sklearn.pipeline import Pipeline, make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression

pre = ColumnTransformer([
    ("num", make_pipeline(SimpleImputer(strategy="median"), StandardScaler()),
     sel(dtype_include="number")),
    ("cat", OneHotEncoder(handle_unknown="ignore", min_frequency=10),
     sel(dtype_exclude="number")),
])
pipe = Pipeline([("pre", pre), ("model", LogisticRegression(max_iter=1000))])
```
4. **ベースラインと比較する**: `DummyClassifier(strategy="most_frequent")`(回帰は `DummyRegressor`)→ 線形モデル → `HistGradientBoostingClassifier` の順。
```python
from sklearn.model_selection import StratifiedKFold, cross_validate
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
for name, model in models.items():          # {"dummy": ..., "logreg": ..., "hgb": ...}
    pipe.set_params(model=model)
    r = cross_validate(pipe, X_train, y_train, cv=cv,
                       scoring=["roc_auc", "average_precision"], return_train_score=True)
    print(name, r["test_roc_auc"].mean().round(3), r["test_roc_auc"].std().round(3),
          "train:", r["train_roc_auc"].mean().round(3))
```
   平均だけでなく標準偏差も見る。差が標準偏差より小さければ「差はない」と扱い、単純な方を選ぶ。train と test の差が大きければ過学習。
5. **ハイパーパラメータ探索**: 候補が多ければ `RandomizedSearchCV`。パラメータ名は `ステップ名__引数`(例 `model__C`)。
```python
from scipy.stats import loguniform
from sklearn.model_selection import RandomizedSearchCV
search = RandomizedSearchCV(pipe, {"model__C": loguniform(1e-3, 1e2)}, n_iter=30,
                            cv=cv, scoring="roc_auc", random_state=42, n_jobs=-1)
search.fit(X_train, y_train)
```
   探索で選んだスコア(`best_score_`)は楽観的。報告用の汎化性能は最後のテストで出す。厳密にはネストした CV。
6. **最終評価(1 回だけ)**: `search.score(X_test, y_test)`、`classification_report`、混同行列。しきい値を動かすなら検証データで決める(`TunedThresholdClassifierCV`、1.5 以降)。
7. **特徴量の重要度**: `permutation_importance(best, X_test, y_test, n_repeats=10, random_state=42)` を既定にする。木モデルの `feature_importances_` は水準の多い列を過大評価しやすい。相関の強い列同士は重要度が分散する点を注記する。列名は `best[:-1].get_feature_names_out()`。
8. **保存**: `joblib.dump(best, "model.joblib")` と、学習に使ったデータの期間・sklearn のバージョン・指標を一緒に記録する。**pickle / joblib は信頼できないファイルを読み込むと任意コード実行になる**ので、他人から受け取ったモデルは読まない(共有用途は `skops` や ONNX を検討)。
9. **動作確認**: 小さなデータで `pytest` を回す(Pipeline が fit / predict できる、未知カテゴリでも落ちない)。長い学習ログは token-saver プラグインの `log-digest` に要約させてよい。

### NG 例
- `StandardScaler().fit_transform(X)` してから `train_test_split`(テストの統計量が漏れる)
- `SMOTE` などのオーバーサンプリングを CV の外で実行(imbalanced-learn の `Pipeline` 内で行う)
- 特徴量選択(`SelectKBest`)を全データで実行してから CV
- テストスコアを見てモデルやパラメータを選び直す(テストが検証データになる)

## 出力フォーマット
```markdown
## 設定
- タスク / 目的変数 / 指標 / 分割方法(理由)
## モデル比較(CV、平均 ± 標準偏差)
| モデル | ROC-AUC | PR-AUC | train との差 |
|---|---|---|---|
| Dummy | 0.500 ± 0.000 | | |
## 採用モデルと最終評価(テスト、1 回のみ)
## 重要な特徴量(permutation importance 上位)
## 注意点・次の改善案
```

## 品質チェックリスト
- [ ] 前処理がすべて Pipeline 内にある
- [ ] テストデータを最終評価の 1 回しか使っていない
- [ ] 分割方法がデータ構造(グループ・時系列)に合っている
- [ ] ベースライン(Dummy)と比較している
- [ ] CV の平均と標準偏差を両方示した
- [ ] 乱数シードを固定し、バージョンと一緒に記録した

## 例
入力: 「解約予測を作りたい。顧客 1 人につき月ごとに 1 行ある」
出力: 同一顧客が学習と検証に分かれないよう `StratifiedGroupKFold(groups=customer_id)` を使う理由、Pipeline のコード、Dummy / ロジスティック回帰 / HGB の比較表、permutation importance の上位 10 件。
