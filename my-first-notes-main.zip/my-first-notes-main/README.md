# my-first-notes — Claude Code skill / agent 集

文章・創作・プレゼン・コンテンツ・ビジネス・学習リサーチ・翻訳・キャリア・教育・マーケ・デザイン・音声・生産性・生活・ゲーム・Claude Code 活用、さらに架空資料・なりきり・思考法・未来予測・副業・お笑い・スピーチ・手紙・子育て・地域発信、さらにパーティーゲーム・テキストアドベンチャー・日常のRPG化・推し活・グルメ・応援などの遊び系でも使える、Claude Code 用の skill と agent(サブエージェント)をまとめたプラグインマーケットプレイスです。

**98 プラグイン / Skill 646 本 / Agent 233 本**

## インストール

```
/plugin marketplace add juntabe0711/my-first-notes
```

必要な分野だけインストールしてください。

```
/plugin install writing@juntabe-toolkit
/plugin install creative@juntabe-toolkit
/plugin install presentation@juntabe-toolkit
/plugin install content@juntabe-toolkit
/plugin install business@juntabe-toolkit
/plugin install research@juntabe-toolkit
/plugin install translation@juntabe-toolkit
/plugin install career@juntabe-toolkit
/plugin install education@juntabe-toolkit
/plugin install marketing@juntabe-toolkit
/plugin install design@juntabe-toolkit
/plugin install podcast@juntabe-toolkit
/plugin install productivity@juntabe-toolkit
/plugin install lifestyle@juntabe-toolkit
/plugin install game@juntabe-toolkit
/plugin install agent-config-kit@juntabe-toolkit
/plugin install workflows@juntabe-toolkit
/plugin install fictional-docs@juntabe-toolkit
/plugin install roleplay@juntabe-toolkit
/plugin install thinking@juntabe-toolkit
/plugin install debate@juntabe-toolkit
/plugin install foresight@juntabe-toolkit
/plugin install comedy@juntabe-toolkit
/plugin install diagnosis@juntabe-toolkit
/plugin install communication@juntabe-toolkit
/plugin install speech@juntabe-toolkit
/plugin install letters@juntabe-toolkit
/plugin install parenting@juntabe-toolkit
/plugin install side-business@juntabe-toolkit
/plugin install spreadsheet@juntabe-toolkit
/plugin install local-pr@juntabe-toolkit
/plugin install party-games@juntabe-toolkit
/plugin install text-adventure@juntabe-toolkit
/plugin install life-rpg@juntabe-toolkit
/plugin install surprise@juntabe-toolkit
/plugin install style-shift@juntabe-toolkit
/plugin install mascot@juntabe-toolkit
/plugin install commentary@juntabe-toolkit
/plugin install pet-voice@juntabe-toolkit
/plugin install oshi@juntabe-toolkit
/plugin install gourmet@juntabe-toolkit
/plugin install trivia@juntabe-toolkit
/plugin install memories@juntabe-toolkit
/plugin install cheer@juntabe-toolkit
/plugin install daydream@juntabe-toolkit
/plugin install token-saver@juntabe-toolkit
/plugin install python-core@juntabe-toolkit
/plugin install python-apps@juntabe-toolkit
/plugin install local-llm@juntabe-toolkit
/plugin install pytorch@juntabe-toolkit
/plugin install data-science@juntabe-toolkit
/plugin install ml-deploy@juntabe-toolkit
/plugin install web-design@juntabe-toolkit
/plugin install web-frontend@juntabe-toolkit
/plugin install ffmpeg-basics@juntabe-toolkit
/plugin install video-editing@juntabe-toolkit
/plugin install sns-video@juntabe-toolkit
/plugin install audio-processing@juntabe-toolkit
/plugin install python-video@juntabe-toolkit
/plugin install ffmpeg-performance@juntabe-toolkit
/plugin install desk-research@juntabe-toolkit
/plugin install synthesis@juntabe-toolkit
/plugin install news-literacy@juntabe-toolkit
/plugin install exam-prep@juntabe-toolkit
/plugin install language-learning@juntabe-toolkit
/plugin install stem-tutor@juntabe-toolkit
/plugin install code-learning@juntabe-toolkit
/plugin install academic-research@juntabe-toolkit
/plugin install survey-research@juntabe-toolkit
/plugin install research-notebook@juntabe-toolkit
/plugin install software-design@juntabe-toolkit
/plugin install build-planner@juntabe-toolkit
/plugin install writing-plan@juntabe-toolkit
/plugin install project-planning@juntabe-toolkit
/plugin install product-planning@juntabe-toolkit
/plugin install story-structure@juntabe-toolkit
/plugin install genre-craft@juntabe-toolkit
/plugin install writing-craft@juntabe-toolkit
/plugin install nonfiction-writing@juntabe-toolkit
/plugin install cooking@juntabe-toolkit
/plugin install english-learning@juntabe-toolkit
/plugin install korean-learning@juntabe-toolkit
/plugin install spanish-learning@juntabe-toolkit
/plugin install sales@juntabe-toolkit
/plugin install web-marketing-learning@juntabe-toolkit
/plugin install sns-operations@juntabe-toolkit
/plugin install psychology@juntabe-toolkit
/plugin install philosophy@juntabe-toolkit
/plugin install behavioral-economics@juntabe-toolkit
/plugin install training-dojo@juntabe-toolkit
/plugin install language-dojo@juntabe-toolkit
/plugin install sales-dojo@juntabe-toolkit
/plugin install communication-dojo@juntabe-toolkit
/plugin install negotiation-dojo@juntabe-toolkit
/plugin install marketing-dojo@juntabe-toolkit
/plugin install logic-dojo@juntabe-toolkit
/plugin install problem-solving-dojo@juntabe-toolkit
/plugin install business-dojo@juntabe-toolkit
```

## 使い方

- **Skill**: 「作る・変換する」ための手順と型。会話の内容に合うと自動で使われます。明示的に呼ぶときは `/writing:japanese-proofread` のように `/<プラグイン名>:<skill名>` と入力します。
- **Agent**: 「レビューする・調べる・評価する」ための専門家。独立したコンテキストで動きます。「strict-editor でこの記事をレビューして」のように名前を出して依頼します。`/agents` で一覧を確認できます。
- **対話型 Agent**(`mock-interviewer`・`coach`・`game-master`・`accountability-partner` など): 1 回の呼び出しで 1 ターン分を返し、末尾に「状態サマリ」を出します。続けるときは状態サマリを添えて再度呼び出してください。
- **ワークフロー**: `/workflows:publish-flow` などで、複数の skill と agent を順番に実行します(関連プラグインのインストール推奨。未インストールでも手順を代替して進みます)。
- **スタイルガイド**: `/writing:style-guide` で自分専用の表記ルールを `STYLE_GUIDE.md` に保存すると、文章系の skill / agent がそれを優先して従います。

## 収録一覧

### ✍️ writing(文章系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `email-writer` | 依頼・お詫び・お断り・催促・お礼・日程調整・問い合わせなど、状況に応じた日本語のビジネスメールを件名付きで作成 |
| Skill | `japanese-proofread` | 日本語の文章を校正し、誤字脱字・表記ゆれ・です/ます調とだ/である調の混在・二重敬語・ら抜き言葉・冗長表現を指摘して修正案を示す |
| Skill | `plain-japanese` | 専門用語・カタカナ語・難しい漢語をかみ砕き、中学生や外国人住民でも読める「やさしい日本語」に書き換える |
| Skill | `rewrite-tone` | 日本語の文章を、カジュアル・ビジネス・学術・親しみやすい・広報/プレスなど指定したトーンに書き換える |
| Skill | `style-guide` | ユーザー専用の文章スタイルガイド(表記ルール、使わない言葉、文体、トーン、よく使う固有名詞)を対話で作り、プロジェクトの STYLE_G… |
| Skill | `summarize-levels` | 文章・記事・議事録・レポートを「1行」「3行」「1段落」の3段階の粒度で要約 |
| Agent | `fact-checker` | 文章中の事実主張(数値・日付・統計・引用・固有名詞・因果関係・「日本初」等の最上級表現)を抽出し、Web検索で裏取りして要検証箇所を洗い… |
| Agent | `strict-editor` | 辛口の編集者として、文章の論理の飛躍・冗長さ・主張の弱さ・構成の甘さを容赦なく指摘 |
| Agent | `target-reader` | 指定された想定読者(新入社員、顧客、中学生、経営層、非エンジニアなど)になりきって文章を読み、「わからなかった点」「引っかかった点」「読… |

### 🎨 creative(創作系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `character-sheet` | 小説・漫画・ゲーム・TRPGの登場人物の設定シートを、動機・欠点・口調・一人称・関係性まで含めて作る |
| Skill | `dialogue-polish` | 小説・漫画・脚本の台詞を推敲し、キャラごとの口調の書き分け、説明台詞の排除、サブテキスト(言外の意味)、会話のテンポを整える |
| Skill | `lyrics-poem` | 歌詞や詩(自由詩・短歌・俳句を含む)を、韻・音数(モーラ)・Aメロ/Bメロ/サビの構成を意識して作る・添削 |
| Skill | `manga-script` | 漫画のネーム用脚本(ページ/コマ割り、コマの大きさ、台詞・ト書き、見開きやページめくりの引き)を作成 |
| Skill | `naming` | キャラクター名・地名・組織名・技名・作品タイトルを、世界観との整合・読みやすさ・既存作品との重複の観点から命名 |
| Skill | `plot-builder` | 小説・漫画・脚本・ゲームシナリオのプロットを、三幕構成・起承転結・セーブ・ザ・キャットなどの型に沿って組み立てる |
| Skill | `revision-pass` | 完成した原稿(小説・脚本・エッセイ等)を、構成→場面→文→語の順に複数パスで段階的に推敲 |
| Skill | `scene-writer` | 小説のシーンを、視点(人称)の統一と五感描写を意識し「Show, don't tell(説明せず見せる)」で執筆・リライト |
| Skill | `screenplay` | 映画・テレビドラマ・ラジオドラマの脚本を、日本のシナリオ書式(柱・ト書き・台詞、200字詰めペラ1枚=約1分)で執筆・整形 |
| Skill | `short-story` | ショートショート(〜4,000字)から短編(〜1万字)までを、着想→プロット→執筆→オチ検証まで一気通貫で書き上げる |
| Skill | `synopsis-logline` | 小説・漫画・脚本のログライン(1文)、あらすじ(200字/800字)、新人賞投稿用の梗概(結末まで書く)を作成 |
| Skill | `worldbuilding` | ファンタジー・SF・現代異能などの世界観設定(歴史・魔法や技術のルール・地理・文化・社会制度)を、物語に効く形で設計・整理 |
| Agent | `beta-reader` | 一般読者の目線で小説・脚本・漫画原作・Web小説を読み、面白さ・テンポ・感情の動き・離脱ポイントを感想形式で返すベータリーダー |
| Agent | `character-interviewer` | 指定されたキャラクターになりきってユーザーの質問に一人称で答え、設定の穴や作者自身も気づいていない新たな一面を引き出すキャラクター・イン… |
| Agent | `contest-judge` | 小説新人賞の下読み・選考委員の目線で原稿を評価し、一次選考を通るか、減点ポイント、応募先レーベル・賞との相性、A〜Eの総合評価を返す専門家 |
| Agent | `continuity-checker` | 小説・脚本・漫画原作・シリーズ設定資料の設定矛盾(人名表記・時系列・年齢・能力・呼称・口調・地理・持ち物)を検出する校閲の専門家 |
| Agent | `idea-brainstormer` | 物語のネタ・設定・タイトル・展開・キャラクター・歌詞のモチーフなどを、突飛なものも含めて大量に出し(発散)、その後に評価して絞り込む(収… |
| Agent | `sensitivity-reader` | 小説・脚本・漫画原作・エッセイの中の差別・偏見・ステレオタイプ・不必要に読者を傷つける表現、実在の人物や団体への配慮をチェックするセンシ… |
| Agent | `style-analyzer` | ユーザー自身が書いた文章の文体(文の長さ、語彙、リズム、視点、比喩の傾向、表記の癖)を定量・定性の両面から分析し、執筆時に参照できる「文… |

### 📊 presentation(プレゼン系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `data-to-chart` | 手元のデータと伝えたいメッセージから、最適なグラフの種類(棒・折れ線・円・散布図・ウォーターフォールなど)と、強調・ラベル・色使いなどの… |
| Skill | `marp-slides` | Marp(Markdown でスライドを作るツール)形式のスライドファイル(.md)を、frontmatter・テーマ・改ページ・画像配… |
| Skill | `one-slide-one-message` | 各スライドで伝えたいことを「主張のある1文」(キーメッセージ)に絞り込み、見出しと本文の整合を整えます |
| Skill | `slide-outline` | プレゼンの目的・聴衆・持ち時間から、SCR(状況-複雑化-解決)/PREP/問題解決型/提案型などの最適な型を選び、スライド単位の構成案… |
| Skill | `speaker-notes` | スライド(構成案・Markdown・PowerPoint の内容など)から、そのまま読み上げられる話す原稿(スピーカーノート)と、スライ… |
| Agent | `audience-critic` | 役員・顧客・技術者・現場担当者など、指定された聴衆になりきってプレゼン資料に率直なツッコミを入れる専門家 |
| Agent | `qa-predictor` | プレゼン資料から本番で聞かれそうな想定質問(Q&A)を洗い出し、回答案と裏付け資料の準備案を作る専門家 |
| Agent | `storyline-reviewer` | プレゼン資料全体のストーリー(流れ・論理のつながり・結論までの道筋)を評価し、並べ替えや追加・削除を提案する専門家 |

### 📱 content(コンテンツ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `blog-article` | SEO を意識したブログ記事を、検索意図の整理→見出し構成(H2/H3)→リード文→本文→まとめ→メタ情報まで一貫して |
| Skill | `newsletter` | メールマガジン(メルマガ・ニュースレター)の件名案と本文を、開封率とクリック率を意識して |
| Skill | `note-article` | note(note.com)向けの記事を、体験談型またはノウハウ型の構成で |
| Skill | `repurpose` | 1本のブログ記事・講演・動画・資料などを元に、SNS投稿(X/Instagram/LinkedIn)、メルマガ、YouTube・ショート… |
| Skill | `sns-post` | X(旧Twitter)・Instagram・LinkedIn・Threads・Facebook など媒体ごとの文字数・改行・ハッシュタグ… |
| Skill | `youtube-script` | YouTube の長尺動画とショート動画(YouTube Shorts / TikTok / Instagram リール)の台本を、フッ… |
| Agent | `headline-tester` | 記事・動画・メルマガ・SNS・LP などのタイトル/件名/見出し案を複数生成し、クリック率(CTR)の観点で比較評価するコピーライティン… |
| Agent | `seo-auditor` | SEO 観点で記事・Webページを診断する専門家 |
| Agent | `trend-researcher` | コンテンツ企画のためのリサーチ専門家 |

### 💼 business(ビジネス文書系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `meeting-minutes` | 会議のメモや文字起こし(Zoom/Teams/Google Meet の自動文字起こし等)から、決定事項・ToDo(担当/期限)・保留事… |
| Skill | `press-release` | 新製品・新サービス・提携・資金調達・イベントなどのプレスリリースを、PR TIMES 等の国内配信サービスや記者向け配信の慣習に沿った構… |
| Skill | `proposal-doc` | 社内稟議・上司への提案・顧客向け提案に使える企画書を、背景・課題・提案内容・期待効果・コスト・スケジュール・リスクの構成で作成 |
| Skill | `report-weekly` | 箇条書きのメモや作業ログから、上司やチームに提出する週報・日報を作成 |
| Agent | `logic-checker` | 企画書・提案書・報告書・プレゼン原稿などの論理構成をレビューする専門家 |
| Agent | `risk-reviewer` | 企画・提案・プロジェクト計画・新規事業案のリスクと懸念点を洗い出し、影響度×発生可能性で評価して対策案とともに整理する専門家 |

### 📚 research(学習・リサーチ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `book-summary` | 読んだ本の内容を、要約・学び・自分のアクション・印象に残った引用で構成する読書メモにまとめます |
| Skill | `citation-formatter` | 参考文献リストを APA 第 7 版・SIST02 などの指定書式に整形し、本文中の引用表記(著者名・年など)も書式に合わせて統一 |
| Skill | `concept-map` | テーマや教材に出てくる概念同士の関係(包含・因果・対比・手順・具体例)を、Mermaid の概念マップ図と説明文で可視化 |
| Skill | `feynman-check` | ファインマン・テクニックで、ユーザーが自分の言葉で説明した内容を診断し、正しい点・抜け・誤解・専門用語への逃げを指摘して、よりやさしい言… |
| Skill | `flashcards` | 教材・ノート・単語リストから、1 枚 1 事実の原則で暗記カードを作り、Anki にそのまま取り込める CSV/TSV(基本カード・穴埋… |
| Skill | `learning-roadmap` | 学習の目標・期限・1 日に使える時間から、マイルストーン・教材・週次計画・到達確認の方法をそろえた学習ロードマップを作ります |
| Skill | `literature-review` | 複数の論文・文献を読み比べ、先行研究の比較表・研究の系譜・未解決の課題(リサーチギャップ)を整理 |
| Skill | `paper-reading` | 論文を読み、落合陽一式フォーマット(どんなもの?/先行研究との差/技術の肝/検証方法/議論/次に読む論文)で 1 枚に要約 |
| Skill | `quiz-maker` | 教材・ノート・テーマから理解度確認クイズ(選択式・記述式・正誤・穴埋め)を難易度別に作成し、解答と解説を付けます |
| Skill | `research-question` | 興味のあるテーマや漠然とした問題意識から、検証可能なリサーチクエスチョン(RQ)と仮説を設計し、FINER 基準での評価・検証方法・必要… |
| Skill | `study-notes` | 教材・講義資料・論文・記事・動画の書き起こしなどを、要点まとめ・用語集・図解案・復習問題つきの学習ノートに整理 |
| Agent | `comparison-analyst` | ツール・手法・書籍・サービス・製品など複数の選択肢を、評価軸を定めて公平に比較し、比較表と用途別のおすすめを返す比較分析の専門家 |
| Agent | `deep-researcher` | 複数の信頼できるソースを横断して調査し、出典付きのリサーチレポートにまとめる調査専門家 |
| Agent | `devils-advocate` | 主張・仮説・結論・企画に対して、あえて反対の立場から反論・反例・代替説明・見落としたリスクを突きつけ、議論を鍛える反論役 |
| Agent | `exam-grader` | 記述式答案・小論文・レポートを、採点基準(ルーブリック)に基づいて採点・添削し、点数の根拠、改善点、模範解答を示す採点の専門家 |
| Agent | `socratic-tutor` | 答えをすぐに教えず、問いかけによって学習者自身に考えさせ理解を深めるソクラテス式のチューター |
| Agent | `source-evaluator` | URL・論文・記事・書籍・SNS 投稿などの情報源の信頼性を、著者・発行元・日付・根拠・利益相反・一次/二次の観点(CRAAP テスト)… |

### 🌐 translation(翻訳・ローカライズ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `back-translation-check` | 訳文を原文言語へ逆翻訳(バックトランスレーション)し、原文と突き合わせて意味のズレ・訳抜け・付け足し・ニュアンスの変化を検出して修正案を示す |
| Skill | `glossary-builder` | 原文・既存訳・製品資料から翻訳用の用語集(原語・訳語・品詞・定義・使用例・NG訳)を作成し、Markdown表またはCSVで出力 |
| Skill | `subtitle-translate` | 動画の字幕を翻訳し、1秒あたり4文字・1行13〜16字・2行までの字幕ルールに収まるよう要約しながら、改行位置を整えたSRT形式で出力 |
| Skill | `translate-natural` | 日本語⇔英語(ほか中国語・韓国語など他言語も可)の文章を、用途(ビジネス・マーケティング・技術文書)に合わせて自然に翻訳し、直訳/意訳の… |
| Agent | `native-checker` | 対象言語のネイティブ話者の目線で訳文や外国語の文章を読み、不自然な言い回し・翻訳調・文化的な違和感・失礼に取られうる表現を指摘 |
| Agent | `terminology-auditor` | 訳文を用語集・スタイルガイド・過去訳と照合し、指定外の訳語・訳語の不一致・表記揺れ・翻訳すべきでない語の誤訳を監査 |

### 👔 career(就活・キャリア系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `career-change-reason` | 転職理由・退職理由を、嘘をつかずにネガティブな本音から前向きな志望理由へ変換し、面接回答・職務経歴書・応募書類用に作成 |
| Skill | `entry-sheet` | 新卒就活のエントリーシート(志望動機・ガクチカ・自己PR・設問回答)を、指定字数に合わせて結論ファースト・STAR構成で作成・添削 |
| Skill | `resume-cv` | 中途採用向けの職務経歴書を、編年体・逆編年体・キャリア式から最適な形式を選んで作成し、実績を数値で表現 |
| Skill | `reverse-questions` | 面接の最後の「何か質問はありますか?」で使う逆質問を、企業・職種・面接段階(一次/二次/最終)・面接官の立場に合わせて作成 |
| Skill | `self-analysis` | 就活・転職のための自己分析を、モチベーショングラフ・強みと価値観の言語化・Will/Can/Mustの整理で進め、ESや面接で使える「軸… |
| Agent | `hr-screener` | 採用担当者の目線でES・履歴書・職務経歴書・志望動機などの応募書類を書類選考し、通過可否の見込み・懸念点・改善案を返す |
| Agent | `mock-interviewer` | 日本企業の採用面接官として、新卒・中途の模擬面接(一次/二次/最終)を1問ずつ実施し、回答への深掘り質問と評価フィードバックを返す対話型… |

### 🎓 education(教育・講師系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `lesson-plan` | 1 コマ分の授業案・学習指導案(本時の目標、導入/展開/まとめ、時間配分、発問、評価、板書計画) |
| Skill | `leveled-explanation` | 同じ内容を小学生・中学生・高校生・大人(一般)・専門家向けの段階別に説明し分け、学年や聞き手に応じた教え方の引き出しをつくります |
| Skill | `rubric-builder` | レポート・発表・作品・実技などを評価するためのルーブリック(観点×段階の表と、各セルの評価基準の文言) |
| Skill | `worksheet` | 授業や研修で配布するワークシート・演習問題・プリントを、難易度の段階づけと解答・解説(教師用)付きで |
| Skill | `workshop-design` | 社内研修・ワークショップ・勉強会の設計(ゴール設定、アイスブレイク、ワーク、共有、振り返り、分刻みのタイムテーブル、準備物) |
| Agent | `curriculum-reviewer` | カリキュラム・単元計画・シラバス・研修プログラム・教材一式をレビューし、学習順序の妥当性、目標・活動・評価の整合性、学習者の負荷(量・難… |
| Agent | `student-simulator` | 指定されたレベル・特性の学習者になりきり、授業案・教材・説明を受けたときのつまずき、誤解、出てきそうな質問や誤答を予測する模擬学習者 |

### 🎯 marketing(マーケ・ブランディング系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `ad-copy` | Google/Yahoo! の検索広告(レスポンシブ検索広告)や Meta・X・LINE などの SNS 広告のコピーを、媒体の文字数制… |
| Skill | `brand-voice` | ブランドの「話し方」を定義するブランドボイスガイド |
| Skill | `customer-journey` | 顧客が商品を知ってから購入・継続・推奨に至るまでのカスタマージャーニーマップ |
| Skill | `lp-structure` | 商品・サービスのランディングページ(LP)の構成案を、ファーストビュー・共感・解決策・ベネフィット・証拠・オファー・FAQ・CTA の順… |
| Skill | `persona` | 商品・サービスのターゲット顧客像(ペルソナ)を、属性・課題・行動・情報源・購買障壁まで具体化して |
| Agent | `competitor-analyst` | 競合の訴求メッセージ・価格/料金体系・ポジショニング・ターゲット・証拠の出し方を WebSearch/WebFetch で調査し、出典付… |
| Agent | `compliance-checker` | 広告・LP・商品ページ・SNS投稿・メルマガの表現について、景品表示法(優良誤認・有利誤認・ステマ規制)、薬機法、健康増進法、特定商取引… |
| Agent | `customer-persona` | 指定されたペルソナの顧客になりきり、広告コピー・LP・商品説明・価格・オファーを見たときの本音の反応(刺さった点、疑った点、離脱する瞬間… |

### 🖼️ design(デザイン・画像生成系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `banner-design` | SNS広告・ディスプレイ広告・Webサイト内バナーを、媒体別のサイズ、キャッチコピーの文字量、視線誘導、CTAボタン、テキスト比率の観点… |
| Skill | `character-design-prompt` | オリジナルキャラクターの設定書(名前・性格・外見・配色・シルエット・口調)を作り、画像生成AIで同じキャラクターを何度でも一貫して出すた… |
| Skill | `color-palette` | ブランド・Webサイト・資料・アプリなどの配色を、メイン/サブ/アクセントの比率(70:25:5)、HEXコード、文字と背景のコントラス… |
| Skill | `design-brief` | デザインを誰かに頼むための依頼書(デザインブリーフ)を、目的・ターゲット・トーン・必須要素・サイズと納品形式・参考・NG・スケジュールま… |
| Skill | `image-prompt` | 画像生成AI(Midjourney、DALL·E/ChatGPT、Stable Diffusion、Adobe Firefly、Imag… |
| Skill | `infographic` | 調査結果・統計・手順・比較などを1枚のインフォグラフィックにまとめるための構成(伝えたい1メッセージ、使うデータの選定、レイアウトの型、… |
| Skill | `logo-concept` | 会社・店舗・サービス・イベントなどのロゴについて、意味づけ(コンセプト)、モチーフ、書体の方向性、色、展開時の注意、商標確認の注意点を含… |
| Skill | `moodboard` | ブランド・Webサイト・イベント・撮影・商品パッケージなどのデザインコンセプトを、キーワードから色・質感・写真の方向性・書体の雰囲気に展… |
| Skill | `thumbnail-design` | YouTube動画やブログ記事・note・SNSシェア用のサムネイル(アイキャッチ)を、文字量・配置・コントラスト・スマホでの視認性の観… |
| Skill | `typography` | 資料・Webサイト・印刷物・アプリで使う書体の選び方と組み方(和文と欧文の組み合わせ、ウェイト、文字サイズ、行間・字間、見出し階層、可読… |
| Skill | `ux-writing` | アプリやWebサービスのUI文言(ボタンラベル、エラーメッセージ、空状態、確認ダイアログ、ツールチップ、完了通知などのマイクロコピー)を… |
| Agent | `accessibility-reviewer` | Webページ、アプリ画面、HTML/CSS/コンポーネント、スライド、画像などを WCAG 2.2(レベルAA中心)の観点でチェックする… |
| Agent | `brand-consistency-checker` | バナー、チラシ、スライド、Webページ、SNS投稿、パッケージなどの制作物が、ブランドガイドライン(ロゴの使用規定、ブランドカラー、指定… |
| Agent | `design-critic` | スライド、Webページ、バナー、サムネイル、チラシ、UI画面などのビジュアルデザインを、レイアウト・情報の優先順位・余白・整列・タイポグ… |
| Agent | `prompt-refiner` | 画像生成AI(Midjourney、ChatGPT/DALL·E、Stable Diffusion、Firefly など)のプロンプトと… |
| Agent | `ux-reviewer` | Webサイト・アプリの画面、ワイヤーフレーム、画面遷移図、ユーザーフロー(手順の説明文を含む)を、Nielsen の10ユーザビリティヒ… |

### 🎙️ podcast(音声・ポッドキャスト系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `chapter-list` | ポッドキャスト・音声・動画の文字起こしを読み、話題の切れ目でチャプター(区切り)を分割し、中身がわかるチャプタータイトルとタイムスタンプ… |
| Skill | `episode-plan` | ポッドキャスト・音声番組のコンセプト設計と、各エピソードの企画(テーマ、ゲスト、構成、シリーズ化) |
| Skill | `radio-script` | ジングル、コーナー、お便り紹介、CM、曲紹介などを含むラジオ番組風の台本を、秒単位の尺表記つきで |
| Skill | `show-notes` | ポッドキャストや音声配信のショーノート・概要欄(エピソード説明文、要約、タイムスタンプ、関連リンク、ハッシュタグ) |
| Skill | `talk-script` | ポッドキャスト・音声配信のトーク台本を、一人喋り/対談/ゲスト回に合わせて |
| Agent | `listener-feedback` | ポッドキャスト・ラジオ・音声配信の台本や文字起こしを、初めて聞くリスナーの目線で評価する専門家 |

### 🌱 productivity(生産性・自己管理系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `daily-plan` | 今日の固定予定とやりたいことから、最重要タスク(MIT)1〜3 個を決め、エネルギーの波に合わせたタイムブロッキングとバッファ入りの 1… |
| Skill | `decision-matrix` | 複数の選択肢で迷っているときに、評価軸と重みを決めて意思決定マトリクスで採点し、感度分析とプレモーテム(失敗の事前検討)まで行って結論と… |
| Skill | `goal-setting` | 漠然とした願望や方針を、OKR または SMART の型で四半期・年次の目標に落とし込み、測定方法・中間チェックポイント・最初の行動まで設計 |
| Skill | `habit-design` | 身につけたい習慣(運動・読書・勉強・早起き・日記など)を、極小の始め方、トリガー/ルーティン/報酬、if-then プランニング、記録方… |
| Skill | `journal-reflection` | 日記・メモ・つぶやきの書き溜めを読み、出来事と感情を整理して、気づき・感情の傾向・繰り返すパターン・次に試す小さな行動を返す |
| Skill | `meeting-agenda` | 会議の目的・ゴール・アジェンダと時間配分・事前資料・参加者の役割を整理して、招集メッセージにそのまま貼れる会議準備資料を作る |
| Skill | `monthly-review` | 1 か月・四半期・1 年を単位に、数値(目標・習慣・健康・お金など)・主な出来事・学びを棚卸しし、目標の進捗を評価して継続/修正/中止を… |
| Skill | `note-system` | 散らかったメモ・資料・ブックマークを整理するための仕組み(PARA、Zettelkasten、フォルダ/タグ設計、命名規則、定期メンテナ… |
| Skill | `task-breakdown` | 大きな目標やプロジェクト、手が付かないタスクを WBS 的に分解し、15〜90 分で終わる作業単位・見積もり・依存関係・最初の一手まで落… |
| Skill | `time-audit` | 1 週間分の時間の記録(カレンダー、作業ログ、手書きメモなど)をカテゴリ別に集計し、理想の時間配分との差を見える化して、「削る・任せる・… |
| Skill | `weekly-review` | GTD の週次レビューの流れ(収集→整理→振り返り→来週の計画)で 1 週間を棚卸しし、KPT で振り返って来週の重点と予定を決める |
| Agent | `accountability-partner` | 本人が宣言した目標・約束と進捗報告を照合し、できたことをきちんと認めたうえで、計画とのずれ・言い訳のパターン・次の具体行動を率直に確認す… |
| Agent | `calendar-optimizer` | 予定表(テキストの貼り付け、CSV、カレンダーのエクスポート等)を読み込み、会議過多・集中時間の不足・移動の非効率・予定の詰め込み・休憩… |
| Agent | `coach` | 答えやアドバイスを与えず、GROW モデルに沿った問いかけで本人の考え・選択肢・行動を引き出すコーチ |
| Agent | `priority-advisor` | タスク一覧から緊急度×重要度(アイゼンハワー・マトリクス)、締切、依存関係、所要時間、その日のエネルギーを考慮して優先順位を付け、「今日… |
| Agent | `procrastination-breaker` | 手を付けられずにいるタスクについて、先延ばしの原因(やることが不明確・大きすぎる・失敗や評価への不安・退屈・疲労や優先度の混乱など)を診… |

### 🏠 lifestyle(生活・趣味系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `budget-review` | 手取り収入と支出を固定費・変動費に分けて整理し、削減候補と効果額、目標貯蓄額に向けた月次予算案を作る家計の見直しスキル |
| Skill | `event-planning` | 誕生日会・歓送迎会・結婚式二次会・同窓会などのイベントを、準備スケジュール(逆算の段取り)、当日のタイムテーブル、役割分担、予算、案内文… |
| Skill | `fitness-plan` | 目的(減量・体力づくり・筋力アップ・ストレッチ習慣など)、運動レベル、使える時間、自宅/ジムの別に合わせて、ウォームアップからクールダウ… |
| Skill | `hobby-starter` | 始めたい趣味について、初期費用の目安(最低限/標準)、最初にそろえる道具と買わなくてよい物、最初の30日プラン、教室・サークル・オンライ… |
| Skill | `housework-plan` | 家事を名前のない「見えない家事」まで洗い出し、頻度・所要時間・担当を表にした家事分担表と、毎日/週/月/年の掃除計画、時短の工夫をまとめる |
| Skill | `meal-plan` | 人数・予算・調理時間・アレルギー・冷蔵庫の残り物をもとに、1週間分の献立と売り場別の買い物リスト、作り置き段取りを作る |
| Skill | `meal-prep` | 週末などにまとめて作り置きをするための調理段取り表(並行作業のタイムライン)、品ごとの保存期間の目安と保存方法、平日の使い回しアレンジ、… |
| Skill | `moving-checklist` | 引っ越しのやることを「2か月前〜当日〜引っ越し後」の時期別チェックリストにし、役所手続き(転出・転入・マイナンバーカード等)、電気・ガス… |
| Skill | `packing-list` | 旅行・出張・キャンプ・帰省・海外旅行・子連れ・入院準備などの用途別に、日数・季節・移動手段(飛行機/新幹線/車)で調整したチェックボック… |
| Skill | `travel-itinerary` | 行き先・日数・同行者・予算から、移動時間と余裕を織り込んだ日程表、予算内訳、雨天時の代替案、持ち物リストをまとめた旅行プランを作る |
| Agent | `gift-advisor` | 贈り物選びの相談相手となるギフトアドバイザー |
| Agent | `local-explorer` | 地域・予算・同行者・天気や季節の条件から、日帰りや半日で行ける近場のお出かけ先を WebSearch/WebFetch で調べて提案する… |
| Agent | `purchase-advisor` | 家電・日用品・生活雑貨などの購入候補を、用途・予算・重視点(性能、手入れ、サイズ、静音、電気代、保証など)で WebSearch/Web… |
| Agent | `recipe-arranger` | 手元にある食材・調味料・調理器具・使える時間から「今すぐ作れる料理」を提案し、足りない材料には家にありそうな物での代替案を出す料理アレン… |
| Agent | `trip-planner` | 旅行の実行可能性を Web で裏取りする旅程プランナー |

### 🧩 game(ゲーム・TRPG系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `balance-table` | ゲームやTRPGの成長曲線(必要経験値)・ダメージ計算式・ドロップ率・ガチャ確率・経済(収入と支出)などのバランス表を、CSV/Mark… |
| Skill | `boardgame-design` | ボードゲーム・カードゲームのルールを、勝利条件・手番構造・コンポーネント一覧・ルールブック原稿・テストプレイ計画まで一式で設計 |
| Skill | `dungeon-design` | TRPGやRPGのダンジョン・マップを、部屋グラフ(接続関係)・ギミック・罠・鍵と扉・敵配置・報酬まで設計し、テキストマップやMerma… |
| Skill | `game-design-doc` | デジタルゲーム(スマホ・PC・コンシューマ・インディー)のゲームデザインドキュメント(GDD)を、コンセプト・コアループ・システム・UI… |
| Skill | `murder-mystery` | マーダーミステリー(マダミス)のシナリオを、キャラクターシート・各人の秘密と目的・手がかりカード・事件当日のタイムライン・真相と論理的な… |
| Skill | `npc-builder` | TRPG・ゲーム・物語に登場するNPC(ノンプレイヤーキャラクター)を、役割・動機・秘密・口調・PCとの関係・能力の目安まで、GMやシナ… |
| Skill | `quest-design` | RPG・MMO・TRPG・アドベンチャーゲームのクエスト/ミッションを、目的・障害・報酬・分岐・サブクエストまで設計し、フラグ管理できる… |
| Skill | `random-tables` | TRPGやゲームで使うランダム表(1d6・2d6・1d66・1d100 のイベント表・遭遇表・名前表・天候表・戦利品表など)を、ダイスの… |
| Skill | `riddle-puzzle` | 謎解きイベント・脱出ゲーム・周遊型謎解き・謎解き本の謎を、ひらめきの種類・段階ヒント・唯一解の保証・難易度曲線・最終謎への伏線まで設計 |
| Skill | `session-log` | TRPGセッションのチャットログ(Discord・ココフォリア・どどんとふ等)や録音の書き起こしを、リプレイ風の読み物・あらすじ・次回へ… |
| Skill | `trpg-scenario` | ファンタジー・ホラー・現代・SFなど任意ジャンルのTRPGシナリオを、導入・ハンドアウト・シーン表・手がかり・クライマックス・エンディン… |
| Agent | `balance-analyst` | キャラクター・武器・カード・敵・ガチャ・経済などの数値データ(CSV/TSV/Markdown表/JSON)を読み込み、Bash(Pyt… |
| Agent | `game-master` | TRPGのゲームマスター(GM)として、シナリオに沿って情景描写・NPCの演技・判定の提示を行い、セッションを1ターンずつ進行する対話型… |
| Agent | `playtester` | TRPGシナリオ・ゲームのルール・クエスト・ダンジョン・バランス表を、プレイヤー目線で仮想プレイして検証し、詰み・抜け道(想定外の攻略)… |
| Agent | `puzzle-tester` | 謎解き・脱出ゲームの謎、マーダーミステリーの推理、ゲーム内パズルを「解く側」として実際に解き、別解・理不尽さ(情報不足や飛躍)・体感難易… |
| Agent | `rules-lawyer` | ボードゲーム・カードゲーム・TRPGのハウスルール・ゲーム内の効果テキストを一字一句読み、曖昧な表現・ルール同士の矛盾・未定義のケース・… |

### 🛠️ agent-config-kit(Claude Code 活用系・旧 claude-code-kit)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `agent-writer` | Claude Code のサブエージェント定義(agents/*.md)を設計・作成 |
| Skill | `claude-md` | プロジェクトの CLAUDE.md を新規作成・改善 |
| Skill | `commit-message` | git の差分(staged の変更)から、Conventional Commits 形式または日本語のコミットメッセージを作成 |
| Skill | `hooks-setup` | Claude Code の hooks を settings.json に設定 |
| Skill | `mcp-setup` | Claude Code に MCP サーバーを追加・設定 |
| Skill | `permissions-setup` | Claude Code の settings.json の permissions(allow / ask / deny)を設計 |
| Skill | `plugin-packager` | 手元の .claude/ にある skill・agent・コマンド・hooks を Claude Code プラグインにまとめ、mark… |
| Skill | `pr-description` | ブランチの差分とコミット履歴から、プルリクエストの説明文(概要・変更点・テスト・影響範囲・レビュー観点)を作成 |
| Skill | `prompt-improver` | Claude への依頼文(プロンプト)を、目的・背景・制約・完了条件・出力形式がはっきりした形に書き直す |
| Skill | `session-handoff` | 作業の途中経過を、次のセッション(次回の自分・別の担当者・新しい Claude)が迷わず再開できる引き継ぎメモにまとめ、HANDOFF.… |
| Skill | `skill-writer` | Claude Code の新しい skill(SKILL.md)を設計・作成 |
| Skill | `slash-command-writer` | Claude Code のカスタムスラッシュコマンド(.claude/commands/*.md)を作成 |
| Agent | `claude-md-auditor` | CLAUDE.md を監査する専門家 |
| Agent | `config-auditor` | Claude Code の設定ファイル(.claude/settings.json・settings.local.json・~/.cla… |
| Agent | `prompt-critic` | skill・サブエージェント定義・スラッシュコマンド・システムプロンプトなどの本文を読み、モデルが誤解しうる箇所、矛盾する指示、判断基準… |
| Agent | `skill-reviewer` | Claude Code の skill(SKILL.md)とサブエージェント定義(agents/*.md)の品質をレビューする専門家 |
| Agent | `workflow-orchestrator` | ユーザーの目的に対して、インストール済みの skill と agent を調べ、どれをどの順で使うかの実行計画を提案するワークフロー設計… |

### 🔗 workflows(分野横断ワークフロー)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `english-study-flow` | 英語学習を「レベル診断と目標設定→学習計画→日々のメニュー(瞬間英作文・発音・シャドーイング・英語日記)→週1回の振り返り→試験対策」の… |
| Skill | `investigation-flow` | 業務や身近な疑問のデスクリサーチを「調査計画→検索クエリ設計→一次情報の収集→突き合わせ→統合→要約の忠実性チェック→3分ブリーフィング… |
| Skill | `job-hunt-flow` | 就職・転職活動を「自己分析→エントリーシート作成→人事目線の書類選考チェック→逆質問づくり→模擬面接」まで一気通貫で進めるワークフロー |
| Skill | `korean-study-flow` | 韓国語学習を「レベル診断と目標設定→(入門者は)ハングルと発音→学習計画→日々のメニュー(作文ドリル・シャドーイング・韓国語日記・好きな… |
| Skill | `novel-flow` | 小説を「アイデア発散→プロット→人物設定→キャラ深掘り→世界観→シーン執筆→矛盾チェック→読者感想→推敲→あらすじ→新人賞目線の評価」ま… |
| Skill | `plan-to-build-flow` | AI と開発する機能を「要件ヒアリング→設計書→設計レビュー→チケット分割→計画レビュー→セッション単位の実装→差分の照合」まで一気通貫… |
| Skill | `presentation-flow` | プレゼン資料を「構成案→キーメッセージ→グラフ化→Marp スライド生成→ストーリー評価→聴衆目線のツッコミ→想定問答→話す原稿」まで一… |
| Skill | `proposal-flow` | 企画提案を「ペルソナ設定→企画書作成→論理チェック→リスクレビュー→プレゼン構成→想定問答」まで一気通貫で仕上げるワークフロー |
| Skill | `publish-flow` | ブログ記事を「テーマ調査→執筆→SEO診断→タイトル比較→校正→ファクトチェック→SNS・メルマガへの横展開」まで一気通貫で進めるワーク… |
| Skill | `research-report-flow` | 調査レポート・卒論・研究レポートを「問いの設計→調査→情報源の評価→論文精読→先行研究レビュー→反論検討→参考文献整形→辛口編集」まで一… |
| Skill | `skill-training-flow` | 営業・交渉・伝え方・論理・語学などのスキルを、道場シリーズで「始め方→今日のメニュー→相手役の設定→学ぶ→練習→甘さチェック・行動の数え… |
| Skill | `spanish-study-flow` | スペイン語学習を「レベル診断と地域の選択→発音の土台→学習計画→日々のメニュー(活用ドリル・シャドーイング・日記添削・会話練習)→週1回… |
| Skill | `study-flow` | 新しい分野の学習を「ロードマップ作成→調査→学習ノート→概念マップ→暗記カード→クイズ→ファインマン・チェック→ソクラテス式問答」の順で… |
| Skill | `writing-plan-flow` | 文章を「企画書→構成案3つの比較→アウトライン批評→読者の道のり確認→執筆スケジュール→執筆→辛口編集→校正」の順で、書く前の設計から仕… |

### 📜 fictional-docs(架空の世界の資料系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `fake-ads` | 作中世界の広告・ポスター・チラシ・商品カタログ・求人広告・政府の宣伝ポスターを、その世界の時代の広告表現(惹句・誇大表現・価格表示・問い… |
| Skill | `fake-bestiary` | 作中世界の生物・植物・鉱物・魔物について、図鑑や博物誌風の項目(分類・形態・分布・生態・人との関わり・観察記録)を作る |
| Skill | `fake-guidebook` | 作中世界の旅行ガイドブック・地誌・観光案内を、名所・名物料理・宿・治安・交通(移動日数と運賃)・方言や挨拶・旅の注意まで、実用書の書式で作る |
| Skill | `fake-journal` | 作中世界の手記・日記・手紙・航海日誌・調査ノートを、ファウンド・フッテージ(発見された資料)形式で、書き手の癖、日付の飛び、欠落・汚損・… |
| Skill | `fake-museum` | 作中世界の博物館の展示解説パネル・遺物キャプション・図録・発掘調査報告を、資料番号・材質・法量・出土地・年代測定・解釈の留保といった学芸… |
| Skill | `fake-newspaper` | 作中世界に「実在するかのような」架空の新聞紙面(一面・見出し・リード・本文記事・社説・広告欄・投書欄)を、その世界の時代や政治体制に合っ… |
| Skill | `fake-official-docs` | 作中世界の法律・条約・布告・勅令・公文書・契約書・許可証を、条文の型や前文・署名欄などの定型書式で作る |
| Skill | `fake-sns` | 作中世界の SNS タイムライン・匿名掲示板・チャットログを、複数の住民の声(立場・口調の違い)、炎上や噂の広がり方、情報の誤りまで含め… |
| Skill | `fake-textbook` | 作中世界の歴史教科書・教材・学習参考書のページを、編纂者(勝者・体制)の視点、太字の重要語句、図版キャプション、章末問題、検定や改訂の痕… |
| Skill | `fake-timeline` | 作中世界の歴史年表・王朝表(在位表)・系図を、作中暦と西暦風の換算、年齢計算、史料による異同まで含めて作る |
| Skill | `fake-wiki` | 作中世界の人物・国家・事件・技術などについて、百科事典や Wiki 風の架空記事(概要・歴史・脚注・関連項目・「要出典」の揺らぎ)を作る |
| Agent | `canon-keeper` | 架空世界の「正典(確定設定)」と新しく書かれた資料・原稿・追加設定を突き合わせ、矛盾/未確定事項/正典化すべき新事実/作中の誤伝として許… |
| Agent | `document-authenticator` | 架空世界の作中資料(手紙・日記・布告・新聞記事・報告書・碑文・契約書・広告など)が「その世界のその時代・その書き手によって書かれたもの」… |
| Agent | `in-world-historian` | 架空世界の中に生きる歴史家(時代・所属・政治的立場・偏りを指定可能)として作中資料を読み解き、学説・史料批判・論争・異説・通説の変遷を生… |
| Agent | `lore-archivist` | 散らばった設定メモ・作中資料(年表・手紙・碑文・報告書・会話ログ)を読み込み、架空世界の「年代記」と「設定資料集」(索引・用語集・出典注… |
| Agent | `world-resident-interviewer` | 架空世界の名もなき住民(職業・階層・地域・年齢・時代を指定)になりきってインタビューに一人称で答え、食事・物価・仕事・住まい・噂・信仰・… |

### 🎭 roleplay(なりきり・対話劇系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `dialogue-play` | 2〜4人の登場人物がテーマをめぐって対立し、会話だけで展開する対話劇の台本を、舞台朗読・リーディング公演・音声配信向けに作る |
| Skill | `fictional-interview` | 架空の人物・歴史上の人物(故人)・未来の自分・物や動物を相手にした「架空インタビュー記事」を、リード文・Q&A・小見出し付きの記事形式で書く |
| Skill | `historical-dialogue` | 歴史上の人物(故人)との対話台本を、史実に基づく部分と創作部分を明示的に区別し、時代に合った語彙と出典メモ付きで作る |
| Skill | `mock-trial` | 物語の登場人物・歴史上の事件・昔話や寓話を題材に、検察・弁護・証人・裁判官(裁判員)がそろった模擬裁判のシナリオを、授業やワークショップ… |
| Skill | `multi-character-scene` | 5人以上の複数キャラクターが同じ場で話す群像会話シーンを、発言量の配分・口調の書き分け・議論の推移を設計してから書く |
| Skill | `philosophy-dialogue` | 「〇〇とは何か」という問いを、プラトンの対話篇のように「問い→定義→反例→再定義」を繰り返す哲学対話として書き、必要に応じて思想家の立場… |
| Skill | `roleplay-setup` | なりきり会話セッションを始める前の「設定カード」(役・口調・知識範囲・禁止事項・開始シーン・終了条件)を作り、ブレずに楽しめる/練習でき… |
| Skill | `time-traveler` | 過去または未来から来た人が現代を見たら何に驚き、何を誤解し、何を批判するかを、対話・手紙・日記の形で書き、カルチャーギャップから現代を見… |
| Skill | `what-if` | 「もし〇〇が△△だったら」という仮定を、分岐点の特定→連鎖する影響→複数の結末という順でシミュレーションし、読み物・創作ネタ・授業の題材に |
| Agent | `debate-panel` | 立場の異なる3〜5人のパネリスト(ユーザー指定、または自動設定)を立て、テーマについて討論させたうえで、論点マップと合意点・対立点・残さ… |
| Agent | `fact-fiction-checker` | なりきり対話・歴史対話・対話劇の台本・架空インタビューを読み、史実との食い違い、時代錯誤(アナクロニズム)、創作部分の明示漏れ、実在人物… |
| Agent | `historical-figure` | 歴史上の人物(故人)になりきってユーザーの質問に一人称で答える対話型エージェント |
| Agent | `panel-moderator` | 討論・座談会・パネルディスカッションの司会として、ここまでの発言を整理し、論点のずれを正し、深掘りの問いと次に投げる問いを提示する対話型… |
| Agent | `role-actor` | 上司・部下・顧客・クレーマー・取引先・先生・保護者・物語の敵役など、任意の役を演じて会話練習の相手になる対話型エージェント |

### 🧠 thinking(思考法・フレームワーク系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `analogy` | 行き詰まった課題を「本質的な構造」に抽象化し、同じ構造を持つ異分野(自然・他業界・スポーツ・歴史など)の解き方を探して、要素ごとの対応表… |
| Skill | `backcasting` | 3〜10 年後などの「ありたい姿」を先に具体的に描き、そこから現在へ時間をさかのぼってマイルストーンと前提条件を置き、今週できる「今日の… |
| Skill | `first-principles` | 「業界の常識」「前からそうしている」といった前提を要素に分解し、物理・法律・予算などの本当に動かせない制約と、慣習にすぎない思い込みを仕… |
| Skill | `five-whys` | トラブル・ミス・不具合・目標未達などの原因を、人を責めない形で「なぜ」を繰り返して掘り下げ、複数経路の原因ツリーにして根本原因を特定し、… |
| Skill | `framework-picker` | 相談内容の「問いの種類」(原因を知りたい・発想したい・決めたい・将来に備えたい・構造を理解したい等)を判定し、thinking プラグイ… |
| Skill | `inversion` | 「どうすれば成功するか」を逆にして「どうすれば確実に失敗するか」「最悪の結果は何か」を考え、失敗の方法を洗い出して「やらないことリスト」… |
| Skill | `issue-tree` | 大きく曖昧な問題を、Why ツリー(原因の分解)・How ツリー(打ち手の分解)・What ツリー(構成要素の分解)のいずれかで MEC… |
| Skill | `scamper` | 既存の商品・サービス・企画・仕組みを、SCAMPER の 7 つの問い(置換・結合・応用・修正/拡大・転用・削除・逆転/再配置)で強制的… |
| Skill | `second-order` | ある決定・施策・ルール変更について「その次に何が起きるか」を二次・三次の影響まで追い、関係者の反応と時間軸(直後・3 か月・1 年・3 … |
| Skill | `six-hats` | デ・ボノの「6つの帽子」(白=事実・赤=感情・黒=リスク・黄=利点・緑=代替案・青=進行)で、1つのテーマを視点ごとに順番に検討し、議論… |
| Skill | `systems-thinking` | 繰り返し起きる問題や「対策したのに悪化した」状況を、要素と因果関係(+/−)で整理して Mermaid の因果ループ図に描き、自己強化ル… |
| Agent | `assumption-hunter` | 計画・企画・事業案・主張に潜む「暗黙の前提」を洗い出し、重要度×不確実性でマッピングして、最もリスクの高い前提から検証方法(安く早く確か… |
| Agent | `bias-detector` | 文章・議事録・企画書・意思決定の経緯から、確証バイアス、サンクコスト、生存者バイアス、アンカリング、楽観バイアス、集団浅慮などの認知バイ… |
| Agent | `red-team` | 計画・戦略・制度・サービスの仕組みを「攻撃者/競合/悪意ある利用者/抜け道を探す内部者」の立場から本気で壊しにいき、突破シナリオと防御策… |
| Agent | `steelman` | ユーザー自身の意見・立場と反対の立場を、その陣営の最も賢い論者が語るような最強の形(スティールマン)で組み立て、その上でユーザーの自説の… |
| Agent | `thinking-partner` | 問いや悩みを受けて、その問いに合った思考フレーム(ロジックツリー、MECE、5 Whys、第一原理、逆算、トレードオフ整理、2×2、プレ… |

### ⚖️ debate(ディベート・交渉系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `debate-prep` | 競技ディベート・授業ディベート・社内討論会の準備として、論題分析(定義・争点)、肯定側/否定側の立論、想定反論と再反駁、証拠カードを作る |
| Skill | `negotiation-plan` | 価格交渉・年収交渉・契約条件・取引条件・家賃交渉などの交渉計画を、目標、BATNA(交渉決裂時の最善の代替案)、ZOPA(合意可能領域)… |
| Skill | `persuasion-structure` | 上司・顧客・家族・チームなど特定の相手を説得するための話の構成を、相手の関心の分析、主張・根拠・反論処理・行動喚起の順で組み立て、口頭で… |
| Skill | `rebuttal-handling` | 会議・商談・議論・窓口対応などで受ける反論・クレーム・答えにくい質問への切り返しを、相手の意図の見極めと型(受け止め→確認→回答→次の一… |
| Agent | `debate-judge` | ディベートの判定員(ジャッジ)として、肯定側・否定側の立論・質疑・反駁の記録や原稿を読み、論点ごとに議論の優劣を比較して勝敗と判定理由、… |
| Agent | `negotiation-sparring` | 価格交渉・年収交渉・契約条件・値引き要求などの交渉相手役になり、ペルソナカードと納得ゲージに従って簡単には合意しない相手を1ターンずつ演… |

### 🔮 foresight(未来予測・シナリオ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `design-fiction` | 未来の製品パッケージ・広告・取扱説明書・ニュース記事・レシート・日常の一場面などを「具体的なモノ」として描くデザインフィクションを作り、… |
| Skill | `future-timeline` | あるテーマについて、5年後・10年後・30年後の未来年表を、各出来事に確度ラベル(高/中/低/思考実験)・根拠・前提を付けて作り、未来が… |
| Skill | `futures-wheel` | ある変化や出来事を中心に置き、そこから広がる一次・二次・三次の影響を放射状に展開する「フューチャーズホイール」を作る |
| Skill | `pestle` | 政治・経済・社会・技術・法律・環境の6観点(PESTLE)で外部環境を洗い出し、「現在の事実」ではなく「これからの変化」と自社・テーマへ… |
| Skill | `scenario-matrix` | シナリオプランニングの手法で、ドライビングフォースの洗い出し→不確実性×影響度の評価→2軸4象限の設定→各シナリオの物語と兆候までを一気… |
| Skill | `scenario-to-strategy` | 作成済みの複数シナリオを受けて、どのシナリオでも有効な打ち手(ノーリグレット策)、特定シナリオでのみ有効な条件付き施策、シナリオの到来を… |
| Skill | `signal-scan` | 未来の変化の「弱いシグナル(兆し)」を集めて解釈し、出来事・背景にある変化・もし広がったら・確度をまとめた「兆しカード」を作る |
| Skill | `three-horizons` | 「3つの地平線(Three Horizons)」の枠組みで、現在の延長(H1)・移行期のイノベーション(H2)・未来の萌芽(H3)を整理… |
| Skill | `trend-crossing` | 複数のトレンドを掛け合わせて、未来に生まれうる機会・新サービス・新しい行動様式のアイデアを発想し、根拠・前提・確度とともに評価 |
| Skill | `wildcards` | 起こる確率は低いが起きれば影響が極めて大きい「ワイルドカード/ブラックスワン」的な事象を洗い出し、影響の連鎖・前兆・事前の備え(レジリエ… |
| Agent | `forecast-calibrator` | 予測・見通し・事業計画の「〜の可能性が高い」「おそらく〜」といった文章を読み、確率表現の曖昧さ・過信・基準率(ベースレート)の無視・検証… |
| Agent | `future-self` | 5年後・10年後の「未来のあなた(ユーザー自身)」として、今迷っている選択(転職・進学・引っ越し・起業・結婚・習慣など)について、振り返… |
| Agent | `futurist` | 突飛だが筋の通った未来像を複数描く未来学者 |
| Agent | `scenario-stress-tester` | 戦略・事業計画・中期計画・キャリアプランを、性質の異なる複数の未来シナリオに当てて「どのシナリオのどの時点で破綻するか」「どの前提が最も… |
| Agent | `trend-scout` | 指定分野の中長期的な技術・社会・規制の変化を WebSearch/WebFetch で調査し、出典付きのトレンドレポートと「兆し(ウィー… |

### 😂 comedy(お笑い・ユーモア系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `conte-script` | コントの台本を、設定・違和感の核・エスカレーション・オチ・ト書き(動き・小道具・照明)まで含めて書く・直す |
| Skill | `manzai-script` | 2人(またはトリオ)の漫才台本を、つかみ・フリ・ボケの種類・ツッコミのワード・天丼・展開・オチまで設計し、約4分の尺で書く・直す |
| Skill | `oogiri` | 大喜利のお題に対する回答を、回答の型(ずらし・具体化・擬人化など)を使って大量に発想し、面白い順に絞り込む |
| Skill | `speech-humor` | スピーチ・挨拶・プレゼン・朝礼に入れる小ネタ(自虐、あるある、場の空気に合う軽いユーモア)を、差し込む位置と言い方まで含めて作る |
| Skill | `wordplay` | ダジャレ・言葉遊び・回文・なぞかけ(〇〇とかけて△△と解く、その心は)・アナグラム・折句(あいうえお作文)を作る |
| Agent | `comedy-critic` | 放送作家・賞レースの予選審査員の目線で、漫才・コント・大喜利の回答・スピーチの小ネタを読み、笑いどころ・間・伏線(天丼)回収・ウケる確度… |

### 🔯 diagnosis(占い・診断コンテンツ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `omikuji` | イベント・Webサイト・アプリ・お店の販促などで使うオリジナルのおみくじや占い文を、運勢の段階・出現率・項目別の運勢・ラッキーアイテムま… |
| Skill | `personality-quiz` | オリジナルの性格診断を、評価軸の設計・質問10〜20問・スコアリング表・分岐ロジックまで一式で作る |
| Skill | `result-writing` | 性格診断・タイプ診断・占いの結果文を、誰にでも当てはまりすぎない具体性、ポジティブな締め、SNSシェア文までセットで書く・直す |
| Skill | `type-diagnosis` | 「〇〇タイプ診断」を4〜16タイプで設計し、タイプ名・キャッチコピー・特徴・相性(良い/刺激し合う)・タイプ一覧表まで作る |
| Agent | `quiz-tester` | 性格診断・タイプ診断・おみくじを、さまざまな仮想回答者で実際に回答して検証し、結果の偏り(出にくい/出すぎるタイプ)・質問の誘導・タイプ… |

### 💬 communication(言いにくいことを伝える系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `apology` | ミスやトラブルの謝罪を、事実・原因・影響・対策・再発防止の順で組み立て、口頭(対面・電話)とチャットでそのまま使える言い回しを作る |
| Skill | `decline-politely` | 誘い・依頼・営業・仕事の追加などを、関係を壊さずに断るための口頭・チャットの言い回しと代替案を作る |
| Skill | `difficult-conversation` | 退職・異動の申し出、昇給交渉、別れ話、親の介護や同居の相談、関係修復など「話しづらい会話」の前に、目的・相手の立場・話す順番・想定される… |
| Skill | `feedback-sbi` | 部下・後輩・同僚・チームメンバーへのフィードバックを、SBI モデル(状況・行動・影響)で具体的に組み立て、改善を促す伝え方と褒め方、1… |
| Skill | `soft-pointing-out` | 上司・同僚・友人・家族・パートナーに、相手のミスや困っている行動を角を立てずに指摘する言い回しを、クッション言葉と相手別の型で作る |
| Agent | `reply-simulator` | 断り・謝罪・フィードバック・指摘・難しい話の切り出しなど「言いにくいことを伝える」文面や台本を読み、相手のタイプ別(素直/反発/落ち込む… |

### 🎤 speech(スピーチ・挨拶系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `eulogy` | 葬儀・告別式で読む弔辞や、お別れ会・偲ぶ会での「お別れの言葉」を、故人の人柄が伝わるエピソードと遺族への配慮を軸に、忌み言葉・重ね言葉を… |
| Skill | `farewell-speech` | 送別会・退職・異動・転勤・定年の場で読む挨拶を、「送る側(上司・同僚・幹事)」と「送られる側(本人)」のどちらでも1〜3分の原稿として作成 |
| Skill | `morning-talk` | 朝礼・朝会・会議の冒頭で話す1分程度のスピーチを、季節の話題・身近なニュース・最近の学びや失敗談から作成し、仕事につながる一言で締める |
| Skill | `toast` | 乾杯の挨拶と、中締め・締めの挨拶(一本締め・三本締め・一丁締めなど)を30秒〜1分の原稿として作成し、手締めの掛け声と手順も添える |
| Skill | `wedding-speech` | 結婚式・披露宴で読む友人代表スピーチや上司・主賓の祝辞を、3分前後の原稿として忌み言葉・重ね言葉を避けて作成 |
| Agent | `audience-mood` | 結婚式・送別会・朝礼・乾杯・弔辞などのスピーチ原稿を、会場・聴衆の顔ぶれ・場の雰囲気を具体的に想定したうえで、長さ・内容・言葉選びがその… |

### ✉️ letters(手紙・メッセージ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `condolence-message` | 訃報を受けたときのお悔やみの言葉や、病気・けが・災害に遭った人へのお見舞いのメッセージを、カード・LINE・メール・手紙などの媒体と相手… |
| Skill | `future-letter` | 未来の自分への手紙、子どもが成長したときに読む手紙(誕生・入学・成人・結婚など)、タイムカプセルに入れる手紙を、書いた時点の記録と未来の… |
| Skill | `nengajo` | 年賀状・喪中はがき(年賀欠礼)・寒中見舞い・余寒見舞いの文面を、相手との関係に合う賀詞の選択、添え書き、出す時期まで含めて作成 |
| Skill | `thank-you-letter` | お中元・お歳暮・お祝い(結婚・出産・入学・新築など)・お見舞いをいただいたときのお礼状を、頭語と結語・時候の挨拶・後付けまで整えた手紙や… |
| Skill | `yosegaki` | 退職・異動・卒業・結婚・出産・お見舞いなどで贈る寄せ書きや色紙のメッセージを、相手との関係性に合わせて1〜3行の短文で作成 |
| Agent | `warmth-checker` | 寄せ書き・年賀状・お礼状・お悔やみ・お見舞い・お祝い・未来への手紙などの個人的なメッセージが、受け取った相手に気持ちよく伝わるかを、温度… |

### 👨‍👩‍👧 parenting(子育て・家族系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `bedtime-story` | 子どもの名前・好きなもの・今日あった出来事を織り込んで、寝かしつけ用の短いお話をその場で作ります |
| Skill | `family-meeting` | 家族会議の議題設定・進め方・ルールづくりを手伝います |
| Skill | `free-research` | 夏休み・冬休みの自由研究のテーマを、学年・興味・使える日数と予算に合わせて提案し、実験/観察/調べ学習の進め方、まとめ方(模造紙・レポー… |
| Skill | `kid-explanation` | 子どもの「なんで?」「どうして?」に、年齢に合わせて、正確さを保ったたとえで親がそのまま話せる答えを作ります |
| Agent | `kid-perspective` | 指定された年齢の子どもの目線で、説明・お話・家庭のルール・掲示物・学習プリントなどを読み、「わかるか」「楽しいか」「怖くないか」「守れそ… |

### 💴 side-business(副業・個人事業系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `client-communication` | 個人事業主・副業者がクライアントとやり取りするための文面(ヒアリングシート、発注内容の確認、進捗報告、納品連絡、修正依頼への返答、範囲外… |
| Skill | `client-proposal` | クラウドソーシング(クラウドワークス・ランサーズ等)の案件への応募文や、企業・店舗への直営業の提案文を、相手の課題・関連実績・進め方・見… |
| Skill | `contract-checklist` | 業務委託契約書・発注書・クラウドソーシングの発注条件を受け取ったときに、業務範囲、修正回数、著作権・二次利用、支払期日、キャンセル・中途… |
| Skill | `estimate-invoice` | 個人事業主・副業者向けに、見積書・請求書の項目(品目、数量、単価、有効期限、支払条件、振込手数料、源泉徴収の有無)と、インボイス制度の記… |
| Skill | `marketplace-listing` | ココナラ・タイムチケット・ストアカ等のスキルマーケットに出すサービスの出品ページ(タイトル、サムネイルの文言、サービス内容、購入前のお願… |
| Skill | `personal-branding` | 副業・フリーランスとして仕事につながる個人の発信計画を、肩書き、プロフィール文(媒体別の長さ)、発信テーマの柱、投稿頻度、SNS→ポート… |
| Skill | `portfolio` | 副業・フリーランスのポートフォリオを、載せる実績の選び方、ケーススタディ形式(課題→対応→成果)、守秘義務・掲載許可への配慮まで含めて作る |
| Skill | `pricing-model` | 副業・フリーランスの価格を、時給逆算・市場相場・価値ベースの 3 方向から検討し、パッケージ/月額/時間単価/成果報酬のどれで売るかと、… |
| Skill | `service-menu` | 副業・個人事業のスキルや経験から「買える形」の商品を切り出し、松竹梅のプラン・オプション・納期・提供範囲(含む/含まない)まで決めたサー… |
| Skill | `side-business-plan` | 副業を始める・立て直すための事業計画を、目標月収、確保できる時間、売るもの、集客経路、3 か月ロードマップ、KPI、撤退基準まで 1 枚… |
| Skill | `tax-basics` | 副業・開業の税務について、開業届、青色申告、経費、帳簿、確定申告の要否、住民税、インボイス制度などの「自分が確認すべきこと」を一般情報と… |
| Agent | `client-simulator` | 副業・フリーランスの「クライアント役」をペルソナカードと納得ゲージで演じ、ヒアリング・見積もり提示・値下げ交渉・追加依頼への対応の練習相… |
| Agent | `idea-validator` | 副業・スモールビジネスのアイデアを、需要・競合・収益性・自分の強み・始めやすさの5観点で検証し、続行/修正/保留を判定して、お金と時間を… |
| Agent | `pricing-advisor` | 副業・フリーランス・個人事業のサービス内容・工数・実績・相場から、いまの価格が妥当かを評価し、値付け案(松竹梅・下限ライン)と根拠を示す… |
| Agent | `profitability-analyst` | 副業・フリーランスの案件や事業の数字(単価・工数・経費・プラットフォーム手数料・振込手数料・税・社会保険)から、実質時給・損益・損益分岐… |
| Agent | `scope-guard` | 副業・フリーランスの依頼文・見積書・契約書・発注書・クライアントとのやり取りを読み、要件の膨張(スコープクリープ)・曖昧な作業範囲・支払… |

### 📈 spreadsheet(データ・スプレッドシート系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `data-cleansing` | 集計前の汚れたデータ(表記揺れ、全角半角の混在、余分な空白、バラバラな日付形式、重複、欠損、横持ちの表)を点検し、Excel / Goo… |
| Skill | `formula-recipes` | 「やりたいこと」から Excel / Google スプレッドシートの関数レシピ(検索・条件集計・条件分岐・日付・文字列・重複・エラー処… |
| Skill | `gas-vba-snippet` | スプレッドシートの繰り返し作業(転記、シートの複製、定期的な集計、入力時の自動記録、メール通知の下書きなど)を自動化する Google … |
| Skill | `pivot-design` | 目的(何を比べて何を判断したいか)から、ピボットテーブルやクロス集計表の行・列・値・フィルタの配置、集計方法、並び順、見せ方を設計 |
| Skill | `sheet-design` | 複数人が入力しても崩れない業務用スプレッドシートを設計 |
| Agent | `data-storyteller` | 表・CSV・集計結果を読み込み、数字から「言えること」と「言えないこと」を切り分けたうえで、報告用のストーリー(結論→根拠→示唆)にまと… |
| Agent | `sheet-auditor` | スプレッドシート(CSV、数式を書き出したテキスト、数式表示のコピー、ブックの説明)を監査し、壊れやすい数式・参照ずれ・範囲漏れ・ハード… |

### 🗾 local-pr(地域・観光発信系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `furusato-gift` | ふるさと納税の返礼品紹介文を、生産者の物語・おいしい食べ方や使い方・内容量や配送などの基本情報まで含めて、ポータルサイトに載せやすい形で… |
| Skill | `local-charm` | 地域の魅力を掘り起こし、観光・移住・特産品などの発信に使える形に整理 |
| Skill | `local-event-pr` | 祭り・マルシェ・朝市・体験会・地域の文化イベントなどの告知を、チラシ用の告知文・地元紙や自治体広報向けのプレスリリース・SNS 投稿(告… |
| Skill | `tourism-pamphlet` | 観光パンフレット・観光マップ・散策ガイドの構成(ページ割り)と掲載文言を作ります |
| Agent | `outsider-eye` | 観光客・移住検討者・外国人旅行者など「その地域を知らないよそ者」の目線で、観光パンフレット・地域の Web ページ・返礼品紹介文・イベン… |

### 🎲 party-games(パーティーゲーム系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `quiz-show` | クイズ大会(社内イベント・懇親会・学校行事・オンライン)の構成を、ジャンル配分・出題形式(早押し/四択/並べ替え/記述)・難易度曲線・得… |
| Skill | `umigame-soup` | ウミガメのスープ(水平思考クイズ)の問題を、問題文・真相・矛盾のない手がかり・想定質問への回答表・難易度・段階ヒントまで一式で作る |
| Skill | `werewolf-setup` | 人狼ゲームの配役(役職と人数)・人数別レギュレーション・進行台本(昼/夜のセリフ)・初心者向けルール説明を、対面/オンラインの開催形式に… |
| Skill | `word-games` | 連想ゲーム・お題当て・NGワードゲーム・ワードウルフ・絵しりとりなど言葉系パーティーゲームのお題を、ゲーム別のルールに合わせて難易度付き… |
| Agent | `quiz-host` | クイズ番組の司会者として、1問ずつ出題し、回答を採点・解説し、得点と順位を管理しながら盛り上げる対話型エージェント |
| Agent | `umigame-host` | ウミガメのスープ(水平思考クイズ)の出題者として、問題を出し、プレイヤーの質問に「はい/いいえ/関係ありません」で答え、推理の正解判定と… |
| Agent | `werewolf-gm` | 人狼ゲームのゲームマスター(GM)として、配役の管理・AI参加者(NPC村人)の発言と投票の進行・夜の行動処理・勝敗判定を公平に行う対話… |

### 🗺️ text-adventure(テキストアドベンチャー系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `escape-adventure` | テキストで遊ぶ脱出アドベンチャー(閉じ込められた部屋から出るゲーム)を、部屋の構成・調べられる物と調べた結果・アイテムの入手と組み合わせ… |
| Skill | `gamebook` | ゲームブック(番号付きパラグラフで分岐する読み物ゲーム)を、パラグラフ構成・フラグ・アイテム・複数エンディング・Mermaid の分岐図… |
| Skill | `novel-branch` | ノベルゲーム(ビジュアルノベル・恋愛ADV・サウンドノベル)の分岐を、共通ルートと個別ルートの構成・好感度やフラグの設計・選択肢の書き方… |
| Agent | `adventure-narrator` | テキストアドベンチャーの語り手として、ユーザーの選択に応じて物語を1ターンずつ進める対話型エージェント |

### ⚔️ life-rpg(日常のRPG化系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `achievements` | 日常生活のRPG化で使う実績バッジ・称号を、達成条件・ランク(銅/銀/金)・隠し実績・コレクション(図鑑)・解除時のメッセージまで含めて設計 |
| Skill | `boss-battle` | 締め切り・試験・大掃除・引っ越し・資格取得などの大きな目標を「ボス戦」に見立て、ボスの設定(名前・HP=残タスク・弱点・攻撃パターン)、… |
| Skill | `level-system` | 日常生活をRPG化するためのレベル・経験値・ステータス(体力/知力/魅力/器用さ/精神力など)の仕組みを、行動ごとの経験値表・必要経験値… |
| Skill | `quest-board` | 家事・勉強・仕事・運動などの「やること」を、デイリー/ウィークリー/メイン/サイドのクエストに変換し、難易度(★1〜5)・経験値・報酬・… |
| Agent | `quest-giver` | 村長/ギルドマスターとして、毎日のクエスト(家事・勉強・仕事・運動)を出し、達成報告を受けて経験値・レベルアップ・称号を授ける対話型のゲ… |

### 🎁 surprise(サプライズ・宝探し系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `cipher-puzzles` | 宝探し・サプライズ・手紙に使う暗号や謎を、シーザー暗号・五十音ずらし・置き換え表・たぬき言葉・座標暗号・火を使わない「あぶり出し」風の隠… |
| Skill | `puzzle-gift` | プレゼントやメッセージカードに謎解きの仕掛けを付け、解き進めると最後に「ありがとう」「おめでとう」などの気持ちが伝わる構成を、謎の流れ・… |
| Skill | `surprise-plan` | 誕生日・記念日・送別・プロポーズ前のお祝いなどのサプライズ演出を、相手の好みの整理、バレない段取りと口実、当日の流れ(秒読みタイムライン… |
| Skill | `treasure-hunt` | 家の中・庭・公園などで遊ぶ宝探しを、ルート(ヒントの隠し場所の順番)、ヒントカードの文面、年齢別の難易度調整、ゴールの宝、安全配慮、片付… |
| Agent | `surprise-planner` | サプライズの「共犯者」として、誕生日・記念日・送別などの計画の段取り・役割分担・当日までのタイムライン・バレるリスクを管理し、毎回「今日… |

### 🎭 style-shift(文体変換・パロディ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `academic-parody` | 日常のささいな疑問や出来事を、論文風(タイトル・要旨・キーワード・先行研究・方法・結果・考察・結論・参考文献)の大真面目な文体で論じるパ… |
| Skill | `dialect-style` | 標準語の文章を、関西弁・博多弁・東北弁・名古屋弁・沖縄方言(うちなーやまとぐち)などの方言風に遊びで変換 |
| Skill | `emoji-style` | 普通の文章を、絵文字たっぷり・顔文字・ギャル語・ネットスラング風に、読める範囲で遊び変換 |
| Skill | `jidaigeki-style` | 日常の文章やメール・SNS投稿・日記を、時代劇・侍・古文風の口調に遊びで変換 |
| Skill | `lightnovel-style` | 日常の出来事や文章を、ライトノベル風(長い説明的タイトル、一人称の地の文、心の中のツッコミ、効果音、章タイトル)に遊びで変換 |
| Skill | `news-style` | 日常のささいな出来事を、ニュース原稿・号外・天気予報・スポーツ実況・速報テロップ風の報道調に遊びで変換 |
| Agent | `style-shifter` | 1つの文章を10通りの文体(時代劇・ラノベ・ニュース・スポーツ実況・論文・方言・絵文字・童話・ポエム・取扱説明書など)に一気に変換し、比… |

### 🧸 mascot(擬人化・キャラ化系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `brand-mascot` | 企業・商品・店舗・サービスのマスコットキャラクターを、役割設定、ブランドとの整合、性格と口調、SNSでの運用ルール(投稿ガイドライン・返… |
| Skill | `character-zukan` | 擬人化キャラをシリーズ化し、図鑑(ナンバリング・分類・ステータス・レア度・図鑑説明文・相関図)としてまとめる |
| Skill | `personify` | 物・家電・食べ物・場所・概念(冷蔵庫さん、締め切りさん、月曜日くん、Wi-Fiちゃん等)を擬人化し、性格・口調・見た目・人間関係・「ある… |
| Skill | `yuru-chara` | 地域・学校・イベント・団体・個人のゆるキャラを、モチーフ選び・名前・プロフィール・口癖・デザインの方向性・グッズ展開・既存キャラとの類似… |
| Agent | `mascot-voice` | 作成済みのキャラクター設定(擬人化キャラ・ゆるキャラ・企業マスコット)を読み込み、そのキャラの口調でSNS投稿・リプライ(返信)・季節の… |

### 📣 commentary(実況・ナレーション系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `documentary-narration` | 日常の出来事や身近な人・ペット・職場を、自然番組・密着番組・歴史番組などジャンル別のドキュメンタリー風ナレーション原稿に |
| Skill | `event-mc` | 運動会・地域のお祭り・社内運動会・忘年会・社内表彰式などの場内アナウンスとMC(司会)台本を、進行表・競技実況・待ち時間のつなぎ・注意喚… |
| Skill | `game-play-script` | ゲーム実況動画・配信の台本とリアクション設計を作ります |
| Skill | `sports-commentary` | 朝の二度寝、満員電車での着席、締切ギリギリの提出など日常の出来事を、実況アナウンサーと解説者の2人によるスポーツ実況に仕立てます |
| Agent | `commentator` | 出来事の記述(日記、メモ、チャットのやりとり、試合・イベントの経過など)を受け取り、熱い実況アナウンサーと冷静な解説者の2人体制で語り直… |

### 🐾 pet-voice(ペットの気持ち系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `pet-diary` | 犬・猫・うさぎ・ハムスター・インコなどペットの一日を、その子の一人称の日記に書きます |
| Skill | `pet-letter` | ペット目線で家族に宛てた手紙を書きます |
| Skill | `pet-profile` | うちの子のプロフィール(アルバムや自己紹介カード用)、ペットアカウントのSNS自己紹介文(プロフィール欄・固定投稿)、迷子になったときに… |
| Skill | `pet-sns` | ペットアカウント(Instagram・X・Threads・TikTokなど)の投稿文を、その子の口調設定・季節ネタ・ハッシュタグつきで作… |
| Agent | `pet-voice` | 飼い主のペット(犬・猫・うさぎ・小鳥など)になりきり、その子の一人称で飼い主に語りかける対話型エージェント |

### 💖 oshi(推し活系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `ensei-plan` | ライブ・舞台・イベント・握手会・コラボカフェなどへの遠征計画を、チケット、移動、宿、予算、持ち物、物販、当日のタイムラインまで推し活目線… |
| Skill | `fan-letter` | 推し(アイドル・俳優・声優・アーティスト・VTuber・作家など)へのファンレターを、具体的なエピソード入りで、相手の負担にならない長さ… |
| Skill | `fukyo-deck` | 推し(アイドル・俳優・VTuber・アーティスト・作品・キャラクターなど)の布教資料を、初見の人向けの入口、おすすめ3選、魅力の言語化、… |
| Skill | `oshi-gatari` | 「推しが好き」「尊い」で止まってしまう気持ちを、分解する問いと語彙で言語化し、ライブレポ・舞台の感想・作品の感想文・SNS投稿の型に落と… |
| Agent | `oshi-listener` | 推し語りを全力で受け止めて深掘りする聞き役 |

### 🍜 gourmet(グルメ・食レポ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `fictional-menu` | 架空のお店のメニュー表を、店のコンセプト、メニュー名、説明文、価格帯、季節限定メニューまで一式で作ります |
| Skill | `food-report` | 食レポ・グルメ記事・SNSのごはん投稿の文章を、五感の描写と食感・味の語彙で「おいしい」と言わずにおいしさが伝わる表現に |
| Skill | `gourmet-diary` | 外食・食べ歩き・お取り寄せ・旅先グルメの記録を、続けやすいテンプレート、自分なりの評価軸、写真キャプションつきのグルメ日記にまとめます |
| Skill | `pairing` | 料理とお酒(ワイン・日本酒・ビール・焼酎・ウイスキーなど)、ノンアルコール飲料、お茶・コーヒーの組み合わせを、合う理由付きで提案 |
| Agent | `food-critic` | 美食家として、料理写真(画像ファイルを Read で確認)・レシピ・食レポ/グルメ記事を講評する専門家 |

### 💡 trivia(雑学・トリビア系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `today-in-history` | 指定した日付の「今日は何の日」ネタ(記念日・歴史上の出来事・誕生日)を集め、朝礼・SNS・社内報・ラジオのつかみに使える形にまとめます |
| Skill | `trivia-notebook` | 集めた雑学・トリビアを、テーマ別・出典付き・へぇ度付き・「話すときの一言目」付きのネタ帳に整理 |
| Skill | `trivia-quiz` | 雑学・トリビアを、選択肢・正解・解説付きの雑学クイズに |
| Skill | `unchiku-talk` | 雑学・うんちくを、押し付けず相手の興味に合わせて、30秒で話せる型に組み立てます |
| Agent | `trivia-checker` | 雑学・トリビア・豆知識・「今日は何の日」ネタ・語源・俗説の真偽を Web で調べ、「本当/諸説あり/俗説/誤り/未確認」で判定して出典を… |

### 📸 memories(思い出アーカイブ系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `family-history` | 祖父母・両親など家族への聞き書きで、家族の歴史をまとめます |
| Skill | `photo-captions` | 写真アルバム・フォトブックの写真に、一言キャプション・詳細キャプション・年月日・場所をそろえて付けます |
| Skill | `travel-journal` | 旅行中のメモ・写真・レシート・つぶやきから、日ごとのハイライト、五感の描写、写真の並び順、旅のベスト3をそろえた旅行記にまとめます |
| Skill | `year-book` | 1年分の写真・日記・メモ・SNS投稿から、月別ハイライト、ランキング、数字で見る1年、来年への一言をそろえた「1年の振り返り年鑑」を作ります |
| Agent | `memory-curator` | 散らばった思い出メモ・日記・写真の説明・SNS投稿の書き出し・聞き書きの記録を読み込み、時系列とテーマで章立てした1冊の年鑑・記念誌・旅… |

### 📯 cheer(応援・褒め系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `cheer-message` | 試験・受験・試合・大会・発表・面接・転職や引っ越し前など、挑戦を控えた人へ、プレッシャーをかけない応援メッセージを作る |
| Skill | `effort-log` | 毎日の小さな達成(「起きられた」「返信した」「洗濯を回した」など)を記録するテンプレートを作り、書き溜めた記録を週末に見える化して自分を… |
| Skill | `praise-words` | 相手(子ども・パートナー・友人・同僚・自分)のがんばりや人柄を、行動・過程・人柄の3層で具体的に褒める言葉を量産 |
| Skill | `self-award` | 自分(または家族・友人・チーム)のちょっとしたがんばりを讃える、ユーモアたっぷりの表彰状・感謝状を作る |
| Agent | `gentle-tsukkomi` | ボケやグチ、ちょっとした自虐に、愛のあるツッコミを返して笑わせ、最後は必ず肯定で締める優しい相方 |
| Agent | `hype-squad` | 小さな達成でも全力で、しかも具体的に褒めちぎる応援団 |

### ☁️ daydream(空想・夢系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `daydream-prompts` | 寝る前・通勤通学の電車・待ち時間などに頭の中で楽しめる空想のお題・妄想ネタ帳を、シーン別・所要時間別にまとめて作る |
| Skill | `dream-story` | 夢日記のメモや覚えている断片(場面・人・色・感覚)を、不思議さを残したまま短い物語に仕立てる |
| Skill | `imaginary-travel` | 行けない場所・架空の国・宇宙・深海・ミクロの世界・過去や未来の街などへの空想旅行記を、旅人の一人称で五感たっぷりに書く |
| Skill | `what-if-me` | 「もしも自分が〇〇だったら」(別の職業・別の時代・動物・植物・モノ・超能力を持っていたら等)を、自分の性格や日常を手がかりに空想エッセイに |
| Agent | `daydream-guide` | 空想の世界を一緒に旅する案内人 |

### 🪙 token-saver(トークン節約系)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `checkpoint` | /compact や /clear の前に、作業の精度を落とさずに続けられる引き継ぎメモ(目的・決定事項と理由・変更済みファイル・未解決… |
| Skill | `claude-md-slim` | 毎セッション読み込まれる CLAUDE.md を、守られる精度を保ったまま短く |
| Skill | `context-diet` | メインモデルがファイル読み込み・コマンド出力・編集・返答でコンテキストを浪費しないための作業ルールを適用 |
| Skill | `delegate-router` | 作業をメインモデルで行うか、sonnet / haiku のサブエージェントに任せるかを判定し、委任用の指示文を作る |
| Skill | `mcp-audit` | 接続中の MCP サーバーとツールを棚卸しし、コンテキスト消費の観点から無効化・プロジェクト単位への移動・CLI への置き換えを提案 |
| Skill | `model-strategy` | 作業の段階に応じたメインモデルと推論の強さ(effort)の選び方・切り替え方を提案し、設定手順を示す |
| Skill | `skill-slim` | インストール済みの skill・agent 定義を、常時読み込まれる部分が小さくなるよう軽くする(description の短縮、本文の… |
| Skill | `token-audit` | /context や /usage で現在の消費状況を確認し、どこで多く使っているか(大きな Read、長いツール出力、CLAUDE.m… |
| Agent | `diff-checker` | メインが書いた変更(git diff)を、渡された受け入れ条件・チェック項目に照らして機械的に確認し、満たしていない項目だけを返す |
| Agent | `doc-digest` | 長い資料・Web ページ・PDF から抽出したテキストを読み、与えられた質問の答えに必要な部分だけを引用付きで返す |
| Agent | `log-digest` | テスト・ビルド・lint・CI などの長い出力(ログファイルまたはコマンド)から、失敗したテスト名・エラーメッセージ・該当ファイル:行・… |
| Agent | `researcher-lite` | 複数ファイル・複数ソース(コード、ドキュメント、Web)にまたがる調査をして、結論と根拠だけをメインに返す調査役 |
| Agent | `scout` | コード・ファイルの所在を探す安価な探索役 |

### 🐍 python-core(Python の土台)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `debug-python` | Python のバグを体系的に調べる手順(再現→最小化→pdb/breakpoint で観察→仮説検証→回帰テスト)とよくある落とし穴の一覧 |
| Skill | `logging-errors` | Python のロギング設定と例外処理を設計する手順(logging の設定、構造化ログ、独自例外の階層、例外の連鎖、リトライ) |
| Skill | `packaging` | Python ライブラリをパッケージ化して配布する手順(pyproject.toml のメタデータ、ビルド、バージョン管理、TestPy… |
| Skill | `performance` | Python の性能を計測してから改善する手順(cProfile/py-spy でボトルネック特定、アルゴリズムとデータ構造の見直し、ベ… |
| Skill | `pytest-design` | pytest でテストを設計する手順(テストの命名、fixture、parametrize、モック、カバレッジ、遅いテストの分離) |
| Skill | `refactor-python` | Python コードを安全にリファクタリングする手順(テストで挙動を固定→小さな関数に分割→責務分離→dataclass 化→ruff … |
| Skill | `type-hints` | Python に型ヒントを付け、mypy/pyright を導入して段階的に厳格化する手順(基本型、Optional、Protocol、… |
| Skill | `uv-project` | uv で Python プロジェクトを作成・管理する手順(uv init/add/sync/run、pyproject.toml、Pyt… |
| Agent | `py-reviewer` | Python コードのレビュー専門家 |
| Agent | `test-writer` | 対象の Python コードに pytest のテストを書き、実行して通ることを確認するテスト作成の専門家(本体コードは変更しない) |
| Agent | `type-fixer` | mypy / pyright の型エラーを、実行時の挙動を変えずに解消する型付けの専門家(type: ignore の乱用はしない) |

### 🌐 python-apps(Python アプリ作成)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `automation` | Python で業務を自動化するスクリプトを作る(ファイル整理・リネーム、Excel/CSV の集計と転記、PDF の結合・抽出、メール… |
| Skill | `cli-typer` | Typer でコマンドラインツールを作る(サブコマンド、引数とオプション、シェル補完、rich による進捗表示と表、終了コード、配布) |
| Skill | `desktop-pyside` | PySide6(Qt for Python)でデスクトップアプリを作る(ウィンドウ構成、シグナル/スロット、重い処理のスレッド化、設定の… |
| Skill | `django-app` | Django で Web アプリを作る・直す(プロジェクト/アプリ構成、モデルとマイグレーション、ビュー、テンプレート継承、フォーム、管… |
| Skill | `fastapi-app` | FastAPI で REST API を作る・直す(ルーター分割、Pydantic モデル、依存性注入、認証、エラー処理、OpenAPI… |
| Skill | `flask-app` | Flask で Web アプリを作る・直す(アプリファクトリ、Blueprint、Jinja2 テンプレート、Flask-WTF フォー… |
| Skill | `scraping` | Web ページから情報を取得するスクレイピングを、robots.txt・利用規約・アクセス間隔を守って実装する(httpx/reques… |
| Skill | `streamlit-gradio` | Streamlit / Gradio で、データ確認ツールやモデルのデモ画面を素早く作る(状態管理、キャッシュ、ファイルアップロード、公… |
| Skill | `templates-frontend` | Django / Flask のテンプレートとフロントエンドをつなぐ骨組みを作る(レイアウト継承、静的ファイルの配置、CSS/JS の読… |
| Agent | `api-designer` | 要件から REST API(エンドポイント、リクエスト/レスポンスのスキーマ、ステータスコード、ページング、認可)を設計し、既存 API… |
| Agent | `app-security-reviewer` | Python の Web アプリ(Django / Flask / FastAPI / Streamlit 等)のセキュリティレビュー担当 |
| Agent | `e2e-tester` | Playwright(Python、pytest-playwright)で Web アプリの主要な画面操作(ログイン、作成・編集・削除、… |

### 🦙 local-llm(ローカル LLM・Ollama)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `local-rag` | Ollama の埋め込みモデルとベクトルストア(Chroma など)で、手元の文書を検索して回答するローカル RAG を組む |
| Skill | `model-choice` | 用途(チャット・コーディング・要約・埋め込み・画像理解)と手元のメモリ(VRAM/RAM)から、Ollama で使うモデル・パラメータ数… |
| Skill | `modelfile` | Ollama の Modelfile(FROM、SYSTEM、PARAMETER、TEMPLATE、MESSAGE)を書いて ollam… |
| Skill | `ollama-python` | Python の ollama パッケージで chat / generate / ストリーミング / 非同期 / 会話履歴管理 / op… |
| Skill | `ollama-setup` | Ollama のインストール・起動確認・モデルの pull/run/list/rm、保存先の変更、GPU/CPU どちらで動いているかの… |
| Skill | `prompt-tuning` | 小さめのローカルモデル(数 B〜十数 B)向けにプロンプトを調整 |
| Skill | `structured-output` | Ollama の構造化出力(format="json" / JSON スキーマ指定)と Pydantic での検証、失敗時の再試行を実装 |
| Skill | `tool-calling` | Ollama のツール呼び出し(function calling)を実装 |
| Agent | `llm-benchmarker` | 複数のローカルモデル(Ollama)に同じ評価セットを投げ、回答の質・形式遵守・速度(tokens/s)・メモリ配置を比較して表にまとめ… |
| Agent | `rag-debugger` | ローカル RAG(Ollama + ベクトルストア)の回答精度が悪いときに、チャンク分割・埋め込み・検索結果・プロンプト・生成の順に診断… |

### 🔥 pytorch(PyTorch で AI 作成)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `dataset-dataloader` | PyTorch のカスタム Dataset と DataLoader を設計・実装する(transform、num_workers、co… |
| Skill | `evaluation` | PyTorch モデルを正しく評価する(タスク別の指標選び、混同行列、検証/テスト分割、データリーク防止、誤分類の分析) |
| Skill | `experiment-tracking` | PyTorch の実験管理を整える(設定ファイル化、ログ、TensorBoard / MLflow / Weights & Biases… |
| Skill | `export-onnx` | 学習済み PyTorch モデルを推論用に書き出す(torch.export / ONNX、TorchScript の位置づけ、量子化の… |
| Skill | `gpu-performance` | PyTorch の学習・推論を GPU で速く・省メモリにする(混合精度 AMP、torch.compile、バッチサイズとメモリ、勾配… |
| Skill | `model-design` | PyTorch の nn.Module でモデルを設計・実装する(CNN/RNN/Transformer の基本構成、形状の追跡、パラメ… |
| Skill | `training-loop` | PyTorch の学習ループを実装・修正する(損失関数、オプティマイザ、スケジューラ、検証、早期終了、チェックポイントの保存と再開、デバ… |
| Skill | `transfer-learning` | 事前学習モデルを使った転移学習・ファインチューニングを実装する(層の凍結/段階的解凍、torchvision の weights、Hug… |
| Agent | `hparam-advisor` | PyTorch の実験結果(学習曲線・指標・設定)から、学習率・バッチサイズ・正則化・エポック数などの次の試行案と探索計画を根拠付きで提… |
| Agent | `model-reviewer` | PyTorch のモデル定義・学習・評価コードをレビューし、train/eval モード、勾配のリセット、デバイス、データリーク、再現性… |
| Agent | `training-debugger` | PyTorch の学習ログとコードから、損失が NaN になる・下がらない・過学習・学習が遅い・CUDA OOM の原因を診断し、優先度… |

### 📊 data-science(データサイエンス)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `dataframe-prep` | pandas / Polars で CSV・Parquet などを読み込み、型の指定、欠損処理、結合、集計、ウィンドウ関数、大きなデータ… |
| Skill | `eda` | 探索的データ分析(EDA)を、データの概要→品質→分布→外れ値→相関→目的変数との関係→気づきのまとめ、の順に進めるコードとレポートを作… |
| Skill | `notebook-hygiene` | Jupyter ノートブックを、上から順に実行すれば同じ結果になる状態に整理し、関数化・.py モジュールへの移行・出力のクリア・Git… |
| Skill | `sklearn-ml` | scikit-learn で、Pipeline と ColumnTransformer による前処理、交差検証、ベースラインを含むモデル… |
| Skill | `stats-tests` | 比較したいデータの種類から適切な統計検定(t 検定、カイ二乗、ノンパラメトリック、多重比較の補正)を選び、scipy / statsmo… |
| Skill | `visualization` | Python のデータ可視化コードを、matplotlib / seaborn / plotly の使い分け、伝わるグラフの原則、日本語… |
| Agent | `eda-analyst` | データファイル(CSV / Parquet / Excel / JSON)を読み、Bash で Python を実行して集計し、要点・デ… |
| Agent | `leakage-detector` | 分析・機械学習のコード(.py / .ipynb)を読み、データリークと評価の誤り(テストデータを含めた前処理の fit、分割前の特徴量… |

### 🚀 ml-deploy(デプロイ・運用)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `ci-actions` | Python プロジェクトの GitHub Actions CI を、lint・型チェック・テスト、依存キャッシュ、Python バージ… |
| Skill | `dockerize` | Python アプリや学習済みモデルを Docker 化し、マルチステージビルド・slim イメージ・uv / pip のキャッシュ・非… |
| Skill | `inference-optimize` | 学習済みモデルの推論を、計測→バッチ化→スレッド設定→ONNX Runtime への変換→量子化の順に軽量化・高速化し、精度の劣化も検証 |
| Skill | `model-serving` | 学習済みモデル(scikit-learn / ONNX / PyTorch など)を FastAPI の推論 API にし、モデルの読み… |
| Skill | `monitoring` | 本番の API・モデルの監視を、構造化ログ、メトリクス(Prometheus 形式)、エラー通知、モデルの性能劣化とデータドリフトの検知… |
| Skill | `reproducibility` | Python / ML プロジェクトの依存と環境を固定し、lock ファイル、Python と CUDA のバージョン、乱数シード、デー… |
| Agent | `deploy-checker` | 本番リリース前のリポジトリ(Dockerfile、CI 設定、アプリの設定、推論コード)を読み、設定・秘密情報・DEBUG・ヘルスチェッ… |

### 🎨 web-design(Web デザイン実装)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `animation` | transition と keyframes によるマイクロインタラクション、prefers-reduced-motion への配慮、や… |
| Skill | `css-architecture` | カスタムプロパティでのデザイントークン、コンポーネント単位のファイル分割、BEM などの命名、cascade layers(@layer… |
| Skill | `dark-mode-theme` | prefers-color-scheme と color-scheme を使ったダークモード、色トークンの切り替え、ユーザーが選べるテー… |
| Skill | `landing-page` | 印象的なランディングページ(LP)を HTML/CSS で実装 |
| Skill | `layout-system` | Grid と Flexbox の使い分け、余白のスケール、コンテナ幅、よく使うレイアウトの型(中央寄せ・サイドバー・カードグリッド・聖杯… |
| Skill | `responsive` | モバイルファーストの CSS、ブレークポイントの決め方、clamp() による流体タイポグラフィ、container queries、s… |
| Skill | `typography-color-impl` | Web フォントの読み込み(表示速度・font-display・サブセット)、行間・字間、日本語の組版(禁則・約物・改行)、色のトークン… |
| Skill | `ui-components-css` | ボタン、カード、フォーム、ナビゲーション、ヒーロー、価格表、フッターなどの UI 部品を、hover/focus/active/disa… |
| Agent | `design-reviewer` | HTML/CSS の実装(スクリーンショットがあればそれも)を読み、余白・整列・視覚的な階層・一貫性・状態設計(hover/focus/… |
| Agent | `responsive-checker` | Playwright などのヘッドレスブラウザで複数の画面幅(360〜1440px)のスクリーンショットを撮り、レイアウト崩れ・横はみ出… |

### 🧩 web-frontend(Web フロントエンド機能)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `alpine-interactions` | Alpine.js でサーバー描画のページに小さな対話(開閉メニュー、タブ、モーダル、文字数カウント、選択連動)を足す |
| Skill | `charts-dashboard` | Chart.js でグラフとダッシュボード画面を作る |
| Skill | `fetch-api` | fetch で JSON API と連携する処理を、HTTP エラーの判定、ローディング表示、タイムアウトと中断(AbortContro… |
| Skill | `file-upload` | ファイルアップロード画面を、プレビュー、ドラッグ&ドロップ、進捗表示、サイズ・種類の事前チェック付きで作り、Django/Flask 側… |
| Skill | `forms-validation` | HTML の制約検証(required/pattern 等)を土台に、日本語のカスタムメッセージ、入力中のリアルタイム検証、送信中の二重… |
| Skill | `frontend-performance` | 画面の表示速度を計測してから改善 |
| Skill | `htmx-patterns` | htmx で JS をほぼ書かずに動的 UI(部分更新、検索サジェスト、無限スクロール、インライン編集、削除確認)を作り、Django/… |
| Skill | `ui-widgets-js` | モーダル(dialog 要素)、タブ、アコーディオン、トースト通知、ドロップダウンを依存なしのバニラ JS で作り、キーボード操作と A… |
| Agent | `browser-tester` | Playwright(Python)で実際のブラウザを操作し、フォーム送信・検証エラー・モーダル・htmx/fetch による動的更新・… |
| Agent | `frontend-reviewer` | HTML / CSS / JavaScript(バニラ JS・htmx・Alpine.js・Chart.js と Django/Flas… |

### 🎬 ffmpeg-basics(ffmpeg の基本)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `codec-container` | 用途(SNS 投稿・Web 埋め込み・保存用・編集素材・社内共有)に合わせて、映像コーデック(H.264/H.265/AV1/VP9)・… |
| Skill | `ffmpeg-install-check` | ffmpeg を OS 別(Windows / macOS / Linux)にインストールし、バージョン・使えるエンコーダ・フィルター・… |
| Skill | `ffmpeg-recipes` | 「やりたいこと」から ffmpeg コマンドを組み立てる(形式変換・切り出し・結合・リサイズ・フレームレート変更・回転・音声の削除/差し… |
| Skill | `ffprobe-inspect` | ffprobe で動画・音声ファイルの中身(コーデック、解像度、fps、ビットレート、長さ、ストリーム一覧、回転情報)を確認し、結果を読… |
| Skill | `quality-size` | ffmpeg の画質とファイルサイズを調整する(CRF・preset・ビットレート指定・2パスエンコード・目標ファイルサイズからのビット… |
| Agent | `ffmpeg-explainer` | 渡された ffmpeg / ffprobe コマンドを1オプションずつ日本語で解説し、上書き・画質劣化・音ズレ・互換性・権利の危険を重要… |

### ✂️ video-editing(ffmpeg で動画編集)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `cut-edit` | ffmpeg で動画のカット編集をする(複数区間を切り出して1本につなぐ、不要部分を削る、キーフレームを意識した正確なカット、ストリーム… |
| Skill | `overlay-text` | ffmpeg でテロップ・透かし文字・ロゴを動画に合成する(drawtext と overlay、位置指定、表示時間 enable、背景… |
| Skill | `picture-in-picture` | ffmpeg で複数の動画を1画面に配置する(ピクチャーインピクチャー=ワイプ、横並び・縦並び hstack/vstack、2x2 など… |
| Skill | `silence-cut` | ffmpeg の silencedetect で無音部分を検出し、残す区間リストを作って自動でつなぐ(ジェットカット) |
| Skill | `speed-fade` | ffmpeg で再生速度を変える(setpts と atempo で映像と音声を同期、倍速・スロー)、フェードイン/アウト(fade/a… |
| Skill | `subtitles` | ffmpeg で字幕を扱う(SRT/ASS の書き方、subtitles フィルターでの焼き込み、MP4/MKV へのソフト字幕埋め込み… |
| Agent | `edit-planner` | 「こう編集したい」という要望を ffmpeg の作業手順に分解し、filter_complex の構成図(ノードとラベルの流れ)、最終コ… |

### 📱 sns-video(SNS 向け動画)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `gif-webp` | 動画の一部から GIF / WebP アニメーションを ffmpeg で作ります |
| Skill | `platform-export` | YouTube・Shorts・TikTok・Instagram リール・X など媒体別の動画書き出し設定の目安を示し、ffmpeg のコ… |
| Skill | `shorts-clip` | 長い動画からショート動画(Shorts・TikTok・リール)用の区間を選んで ffmpeg で切り出 |
| Skill | `thumbnail-extract` | 動画からサムネイル用の静止画を ffmpeg で抽出 |
| Skill | `vertical-convert` | 横長(16:9)の動画を ffmpeg で縦型 9:16(1080x1920 など)に変換 |
| Agent | `platform-checker` | 書き出した動画を ffprobe で調べ、長さ・解像度・アスペクト比・fps・容量・コーデックを、指定された投稿先(YouTube、Sh… |

### 🔊 audio-processing(ffmpeg で音声処理)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `audio-extract` | ffmpeg で動画から音声を取り出したり、MP3・AAC・Opus・WAV・FLAC へ変換したり |
| Skill | `bgm-mix` | ffmpeg で声と BGM をミックス |
| Skill | `loudness-normalize` | ffmpeg の loudnorm フィルターで音声・動画の音量をラウドネス基準(LUFS)に揃えます |
| Skill | `noise-reduction` | ffmpeg で音声のノイズを減ら |
| Skill | `podcast-export` | ポッドキャスト配信用に音声を ffmpeg で書き出 |
| Agent | `audio-qa` | ffmpeg の ebur128・volumedetect・astats・silencedetect で音声(または動画の音声)のラウド… |

### 🎞️ python-video(Python × 動画)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `batch-processing` | フォルダ内の大量の動画・音声を Python で一括変換するスクリプトを書きます |
| Skill | `ffmpeg-python-pyav` | Python で動画を扱うときに ffmpeg-python(コマンド組み立てラッパー)と PyAV(FFmpeg ライブラリの直接バイ… |
| Skill | `progress-display` | Python から ffmpeg を実行するときに、-progress pipe:1 の出力を読み取って tqdm や rich で進捗… |
| Skill | `subprocess-ffmpeg` | Python から subprocess で ffmpeg / ffprobe を安全に呼び出すコードを書きます |
| Skill | `whisper-subtitles` | Whisper(openai-whisper または faster-whisper)で動画・音声を文字起こしし、SRT 字幕ファイルを作… |
| Agent | `batch-runner` | フォルダ内の動画を指定された処理(形式変換・縮小・音声抽出など)でまとめて変換し、成功/失敗の件数と失敗ファイルの理由だけを短く報告する… |

### ⚡ ffmpeg-performance(高速化と配信)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `encode-benchmark` | ffmpeg のエンコード設定(CRF・プリセット・コーデック・GPU など)ごとに、速度・ファイルサイズ・画質(VMAF / SSIM… |
| Skill | `gpu-encode` | ffmpeg で GPU(NVIDIA NVENC / Intel QSV / Linux の VAAPI / macOS の Vide… |
| Skill | `hls-dash` | ffmpeg で動画を HLS(.m3u8)や MPEG-DASH(.mpd)の配信用に変換 |
| Skill | `long-video-split` | 数時間の長い動画を ffmpeg の segment muxer などで分割し、分割したまま並列処理したり、最後に concat で再結… |
| Skill | `parallel-encode` | 複数の動画を ffmpeg で同時に変換するときの同時実行数・スレッド設定を決め、CPU / GPU / ディスクの負荷を見ながら最も速… |
| Agent | `encode-optimizer` | 画質・速度・サイズの条件と実行環境(ffmpeg -encoders / -hwaccels の結果、GPU、OS)から最適な ffmp… |

### 🔎 desk-research(調査の実務)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `freshness-check` | 集めた情報の発行日・更新日・データの時点を確認し、古い情報の扱い(使う/注記する/差し替える)と定期的な見直しの予定を決める |
| Skill | `primary-sources` | 調べたいテーマに対して、官公庁統計・法令・論文データベース・特許・有価証券報告書・国際機関などの一次情報をどこでどう探すかを案内し、情報… |
| Skill | `research-design` | 調べものを始める前に、大きな問いを検証可能な小問に分解し、仮説・必要な情報・調査範囲・締め切り・成果物の形を1枚の調査設計書にまとめる |
| Skill | `research-log` | 調査ログ(検索した語・見た情報源・日付・結果・未解決事項)を記録するテンプレートを用意し、後から自分や他人が同じ調査を再現できるように |
| Skill | `search-queries` | 調べたいことから検索クエリを設計 |
| Agent | `cross-checker` | 調査で集めた主張・数値ごとに、複数の独立した情報源で突き合わせ、「一致/不一致/単一ソースのみ/確認不能」を判定する検証の専門家 |
| Agent | `research-planner` | 問いやテーマから、小問・情報源候補・検索クエリ・優先順位・所要時間を含む調査計画を作る調査設計の専門家 |
| Agent | `source-hunter` | 小問や調査計画を受け取り、官公庁統計・法令・論文・企業開示などの一次情報を優先して Web で探し、URL・発行元・日付・要点・信頼度付… |

### 🧾 synthesis(要約・統合)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `bluf-summary` | 調査結果や検討内容を、結論を最初に置くBLUF(Bottom Line Up Front)とピラミッド構造で要約し、読み手に合わせて長さ… |
| Skill | `confidence-labels` | 調査結果やレポートの各主張に「確実/有力/可能性あり/不明」の確度ラベルを付け、事実と推測の書き分けと言い回しを統一 |
| Skill | `conflicting-info` | 資料や報道の間で数字・主張が食い違うとき、原因を「定義・時点・対象・方法」の違いに切り分け、どちらを採るかの基準と両論併記の書き方を示す |
| Skill | `executive-summary` | 調査報告や検討資料の冒頭に置くエグゼクティブサマリーを、意思決定者向けに「推奨・選択肢の比較・リスク・必要な判断」で構成 |
| Skill | `multi-source-synthesis` | 複数の資料・調査メモ・記事を論点ごとに整理し、比較表・出典の紐づけ・合意点と相違点で1つの統合結果にまとめる |
| Skill | `one-pager` | 調査結果や検討内容をA4一枚(背景・問い・結論・根拠・示唆・次のアクション+図表1つ)にまとめる |
| Skill | `periodic-digest` | 週次・月次でニュースや論文、業界動向をまとめる定期ダイジェストを、重要度の付け方と前回からの変化が分かるテンプレートで作る |
| Agent | `briefing-writer` | 調査結果・統合レポートから、3分で読めるブリーフィング(要点3つ、なぜ重要か、次にすること、聞かれそうな質問と答え)を作る専門家 |
| Agent | `summary-auditor` | 要約・報告書と原文を1文ずつ照合し、誇張・抜け・原文にない内容・数字の誤り・確度の上げすぎを指摘する要約の監査役 |
| Agent | `synthesizer` | 複数の調査結果・メモ・記事の抜粋を読み、論点別に統合した1本のレポートにまとめる統合担当 |

### 📰 news-literacy(ニュース・データの読み解き)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `media-comparison` | 同じ出来事を報じた複数のメディアの記事を、見出し・強調点・情報源・省かれた点で比較表にまとめる |
| Skill | `misleading-charts` | ニュース・広告・資料のグラフが誤解を招いていないかを、軸の切り取り・二重軸・面積の誇張・累積・期間の選び方などの観点で点検し、正しい読み… |
| Skill | `news-background` | ニュースの背景を、経緯・関係者・論点・用語・今後の注目点に整理し、事実と見解を分けて解説 |
| Skill | `reading-statistics` | ニュースや資料に出てくる統計を、平均と中央値・割合と実数・相関と因果・サンプルと母数・前年比の罠の観点で読み解く |
| Agent | `media-comparator` | 同じ出来事についての複数の報道をWebで集めて比較し、共通する事実・報道ごとの違い・未確認情報を出典URL付きで整理する報道比較の専門家 |
| Agent | `stats-sanity-checker` | 文章・記事・資料に出てくる数字・割合・増減率・グラフの使い方を検算し、計算の誤りや誤解を招く表現を指摘する数字のチェック担当 |

### 📝 exam-prep(資格・試験対策)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `exam-schedule` | 試験日から逆算して、インプット期→演習期→模試期→直前期の学習スケジュールを、復習の間隔と予備日込みで作ります |
| Skill | `final-checklist` | 試験直前に見返す頻出事項の総まとめと、当日の持ち物・時間配分・見直し手順のチェックリストを1枚にまとめます |
| Skill | `memorize-vs-understand` | 試験範囲の項目を「暗記すべきもの」と「理解すべきもの」に仕分け、それぞれに合った勉強法と確認方法を示 |
| Skill | `mock-exam-build` | 本番の形式・時間・配点・難易度配分に合わせたオリジナルの模擬試験を、解答と解説付きで作ります |
| Skill | `past-exam-analysis` | 手元の過去問(複数年度分)を分野・テーマ・形式・配点で集計し、出題傾向と年度ごとの変化を表にまとめて、優先して勉強すべき範囲を示 |
| Skill | `weak-points` | 間違えた問題や模試の結果を、分野と原因(知識不足/理解不足/ケアレス/時間不足)で分類し、点数が伸びる順に対策の優先順位を付けます |
| Agent | `mock-examiner` | 資格・試験対策で、1問ずつ出題して採点・解説し、分野別の正答率を記録する対話型の模擬試験官 |
| Agent | `weak-point-analyzer` | 解答記録(間違えた問題のリスト・模試の結果・正答率の記録)を読み、苦手分野と原因(知識不足/理解不足/ケアレス/時間)を特定して、次の1… |

### 🗣️ language-learning(語学学習)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `conversation-practice` | 旅行・仕事・面接など場面別の会話練習用に、ロールプレイの台本、言い換え表現、練習の進め方をまとめます(英語が既定、他言語も可) |
| Skill | `extensive-reading` | 多読・多聴の教材の選び方(レベルの目安)、続けるコツ、記録の付け方をまとめ、自分に合った進め方を提案します(英語が既定、他言語も可) |
| Skill | `grammar-explain` | 文法項目を「ルール→例文→よくある間違い→練習問題」の順にやさしく解説します(英語が既定、他言語も可) |
| Skill | `shadowing-script` | シャドーイング・音読用のオリジナル台本を、レベル別の長さと速度、区切り(スラッシュ)、注意する音のつながりの注記付きで作ります(英語が既… |
| Skill | `vocab-builder` | レベルやテーマに合わせて、意味・コロケーション・自然で短い例文・覚え方を付けた単語帳を作ります(英語が既定、他言語も可) |
| Skill | `writing-correction` | 外国語の作文を、レベルに合わせた添削量で直し、直した理由と、より自然な言い方を示します(英語が既定、他言語も可) |
| Agent | `conversation-partner` | 学習者のレベルに合わせて外国語(英語が既定)で会話し、ターンごとに自然な言い方の提案を短く添える対話型の会話相手 |
| Agent | `writing-corrector` | 外国語(英語が既定)の作文を添削し、間違いを種類別に分けて理由を説明し、その人によく出る間違いのパターンをまとめる添削担当 |

### 📐 stem-tutor(理系科目)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `derive-formula` | 数学・物理・化学の公式を「なぜその形になるのか」から導出し、前提条件・近似・適用できない場合まで整理 |
| Skill | `step-hints` | 数学・物理・化学などの問題を「問題の分類→方針のヒント→途中式のヒント→答え」の 4 段階で少しずつ開示し、どこでつまずいたかを特定 |
| Skill | `units-dimensions` | 物理・化学の式や答えを、次元解析で誤りがないか調べ、単位換算と有効数字の扱いまでチェック |
| Skill | `visual-understanding` | 数学・物理・化学の内容をグラフや図にして理解 |
| Agent | `solution-verifier` | 数学・物理・化学の解答を Python(標準ライブラリ、あれば sympy / numpy)で数値計算・記号計算して検算し、合っているか… |
| Agent | `step-hint-tutor` | 数学・物理・化学の問題で、答えを言わずにヒントを 1 段ずつ出す対話型の家庭教師 |

### 💻 code-learning(プログラミング学習)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `explain-code` | 初心者〜中級者向けに、コードを 1 行(または 1 ブロック)ずつ「何をしているか→なぜそう書くか→変えたらどうなるか」の 3 段で解説 |
| Skill | `mini-projects` | プログラミング学習者向けに、小さな作品を作る課題を設計 |
| Skill | `practice-problems` | プログラミングの演習問題をレベル別に作る |
| Skill | `read-errors` | 初心者がエラーメッセージを自分で読めるようになるための手順 |
| Agent | `code-explainer` | 初心者向けにコードを解説し、最後に理解度確認の問いを添えるプログラミング講師 |
| Agent | `kata-master` | プログラミング演習(kata)を 1 問出題し、学習者が提出したコードを実行・テストしてレビューする対話型の道場師範 |

### 🔬 academic-research(学術研究の実務)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `conference-talk` | 学会発表の準備として、口頭発表のスライド構成と時間配分、ポスターのレイアウト、質疑応答の想定問答を、発表時間と聴衆に合わせて作ります |
| Skill | `imrad-paper` | 研究論文を IMRaD 形式(序論・方法・結果・考察)で組み立て、各章で書くこと、図表の配置、アブストラクトの型を示して骨子や下書きの構… |
| Skill | `lab-notebook` | 研究ノート(実験ノート・調査ノート)を、日付・目的・条件・手順・結果・考察の型で付け、再現性とデータの保存・改ざん防止まで含めた記録ルー… |
| Skill | `research-ethics` | 研究計画や原稿について、倫理審査の要否、インフォームド・コンセント、個人情報の扱い、利益相反、著者の基準、研究不正の防止をチェックリスト… |
| Skill | `research-proposal` | 研究計画書(科研費・学振・大学院入試・学内助成など)を、背景・目的・新規性・方法・スケジュール・期待される成果・倫理の構成で作り、審査で… |
| Skill | `reviewer-response` | 査読コメントへの回答書(Response to Reviewers)を、コメントごとの対応表、丁寧で具体的な返答、根拠を示した反論、原稿… |
| Agent | `methods-checker` | 研究計画書・論文原稿の方法を読み、サンプル数、対照群、無作為化、交絡、測定の妥当性・信頼性、統計手法の選択が問いに合っているかを確認する… |
| Agent | `peer-reviewer` | 学術誌・学会の査読者の目線で論文原稿(投稿前の下書き・卒論・修論を含む)を評価し、主要な指摘・軽微な指摘・判定の目安(採録/修正/不採録… |

### 📋 survey-research(アンケート・インタビュー調査)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `interview-guide` | 半構造化インタビューのインタビューガイドを、調査目的から質問の順序、深掘りの問い(プローブ)、時間配分、記録と同意の手順まで含めて作ります |
| Skill | `qualitative-coding` | インタビュー記録や自由記述などの質的データを、オープンコーディング→カテゴリ化→テーマの順で分析し、コードブックの作成と複数人でのコーデ… |
| Skill | `questionnaire-design` | アンケート(質問票)を、調査目的から逆算して、誘導しない質問文、ダブルバーレルの回避、網羅的な選択肢、適切な尺度、順序効果への配慮、回答… |
| Skill | `sampling` | 調査の母集団の定義、標本の取り方(無作為・層化・クラスター・便宜的など)、必要なサンプル数の目安、起こりやすい偏り(カバレッジ・無回答・… |
| Skill | `survey-report` | アンケート・インタビュー調査の結果を、調査概要、単純集計・クロス集計、自由記述の扱い、限界の書き方までそろえた報告書にまとめます |
| Agent | `qualitative-coder` | インタビューの書き起こしや自由記述を読み、コードとテーマを抽出して、発言者 ID つきの引用を添えたコードブックを作る質的分析の専門家(… |
| Agent | `survey-reviewer` | アンケートの質問票を読み、誘導・ダブルバーレルなどの偏り、答えにくさ、選択肢や論点の抜け、長すぎを指摘し、質問ごとの修正案を返す質問票レ… |

### 🗂️ research-notebook(研究ノート・知識ベース)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `knowledge-review` | 研究・勉強の知識ベースを定期的に見直し、古くなった情報の更新、孤立したノートの発見、未解決の問いのリスト整理を行う |
| Skill | `literature-notes` | 読んだ文献の文献ノートを作り、概念ノートへ分解して、自分の言葉と出典リンクつきの知識ベースに育てる |
| Skill | `pdf-highlights` | PDF のハイライトやメモの色分けルールを決め、抜き出した注釈を引用とページ番号つきの文献ノートに変換 |
| Skill | `reference-manager` | Zotero などの文献管理ツールでの収集・タグ・コレクション設計、BibTeX/CSL JSON の書き出し、重複の整理、Markdo… |
| Skill | `tags-links` | 研究ノート・文献ノートのタグの粒度と命名規則、双方向リンク、索引ノート(MOC)を設計し、増えすぎたタグを統合・整理 |
| Agent | `kb-librarian` | 研究メモ・文献ノートのフォルダを読み、関連ノート同士のリンク候補、重複、タグの揺れ、索引ノート案を提案する知識ベース司書 |
| Agent | `notes-digest` | 大量の研究メモ・文献ノートから、指定したテーマに関係する記述だけを出典ノート名付きで抜き出す抽出係 |

### 🏗️ software-design(ソフトウェア設計)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `adr` | アーキテクチャ決定記録(ADR)を、コンテキスト・決定・検討した選択肢・結果・ステータスの形で書き、番号と置き換え関係を管理 |
| Skill | `data-model` | 要件からデータモデルを設計し、エンティティ・属性・関係・正規化の程度・インデックスを決めて Mermaid の erDiagram で … |
| Skill | `design-doc` | 設計ドキュメント(Design Doc / RFC)を、背景・目的・非目的・提案・代替案・影響・移行・未解決の問いの構成で、レビューしや… |
| Skill | `migration-plan` | システム移行・大規模リファクタリングの計画を、段階的移行(ストラングラーパターン)、データ移行、互換期間、ロールバック手順、完了条件まで… |
| Skill | `requirements` | システム開発の要件定義書を作る |
| Skill | `screen-flow` | 画面一覧と画面遷移図(Mermaid flowchart)、テキストのワイヤーフレーム、各画面の状態(空・読み込み中・エラー・権限なし)… |
| Skill | `tech-selection` | ライブラリ・フレームワーク・DB・クラウドサービスなどの技術選定を、評価軸と重み・候補の比較表・PoC(検証)計画・決定理由の記録までま… |
| Skill | `test-strategy` | プロジェクトや機能のテスト戦略を立てる |
| Agent | `architecture-critic` | システム構成・アーキテクチャ案を、拡張性・単純さ・運用のしやすさ・障害時の影響範囲・コストの観点で評価し、より単純な代替案があれば示す批評家 |
| Agent | `design-doc-reviewer` | 設計ドキュメント・RFC・ADR・要件書・データモデルをレビューし、抜け・矛盾・過剰設計・リスクの見落とし・既存コードとの不整合を重要度… |
| Agent | `requirements-interviewer` | 「〜みたいな機能がほしい」といった曖昧な要望に対して、1 回 2〜3 問ずつ質問を重ねて要件を固めるヒアリング役 |

### 🧭 build-planner(AI と開発する計画)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `done-criteria` | AI に任せる開発タスクの完了条件を、実行できるテストコマンド・期待する出力・確認する画面・やらないことまで含めた検証可能な形で書く |
| Skill | `parallel-work` | 開発計画の中から、サブエージェントや別セッション(worktree)に並列で任せられる独立した作業を見分けて切り出し、ファイル競合や前提… |
| Skill | `plan-mode-usage` | Claude Code の plan mode を、いつ使うか・計画の質を上げる指示の出し方・計画の承認と修正の仕方まで、公式ドキュメン… |
| Skill | `plan-vs-actual` | AI と進めた開発の計画(PLAN.md)と実績を記録し、ずれた箇所・ずれの原因・次の計画への反映を残す |
| Skill | `session-sized-tasks` | AI と進める開発作業を、1セッション(終わったら /clear で区切れる大きさ)に収まる単位に分け、依存関係・順番・各タスクの完了条… |
| Skill | `spec-first` | 実装に入る前に、目的・完了条件・制約・触らない範囲・テスト方法を SPEC.md などのファイルに書き、ユーザーの確認を取ってから実装 |
| Agent | `plan-critic` | 実装計画(PLAN.md、plan mode の計画、作業チケット一覧)を読み、抜け・順序の誤り・テスト不足・曖昧な完了条件・既存コード… |
| Agent | `scope-splitter` | 大きな仕様書・設計書・要望リストを読み、1セッションで終わる単位の作業チケット(目的・範囲・完了条件・依存)に分ける分割担当 |

### 🗒️ writing-plan(文章の設計)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `book-structure` | 書籍・長文レポート・連載など数万字規模の文章の章立てを、全体の流れ、章ごとの役割と字数配分、読者の到達点、各章の終わり方まで設計 |
| Skill | `outline-design` | 文章のアウトラインを、見出しの階層・論理構成の型(結論先行・問題解決・時系列・比較・FAQ)・各見出しで言うこと1文・字数配分まで設計 |
| Skill | `outline-options` | 同じテーマで構成案を3つ出し、狙い・長所・短所・向く読者を比較して1案を選ぶ(選んだ理由も残す) |
| Skill | `research-plan-for-writing` | 文章を書くための資料集めを、主張ごとに必要な根拠・情報源・取材やインタビューの段取り・資料の整理方法まで計画 |
| Skill | `revision-plan` | 書き上げた下書きを直す前に、大きい直しから小さい直しへの順番、何回目の推敲で何を見るか、誰からどうフィードバックを集めるかを計画 |
| Skill | `writing-brief` | 文章を書き始める前に、目的・読者・読後の変化・伝えたい一文・制約・トーンを1枚の企画書(ライティングブリーフ)にまとめる |
| Skill | `writing-schedule` | 総字数と締切から逆算して、調査・執筆・寝かせる期間・推敲・予備日を含む執筆スケジュールを作る |
| Agent | `outline-critic` | 文章・書籍のアウトライン(見出し構成・章立て)を、論理の流れ・抜け・重複・字数配分のバランス・結論との対応の観点で評価し、修正案を返す構… |
| Agent | `reader-journey-checker` | 想定読者になりきってアウトラインや原稿の章・節を順にたどり、各地点で何を知り、何に疑問を持ち、どこで離脱しそうかを表で返す読者体験の検証役 |

### 📅 project-planning(プロジェクト計画)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `gantt-chart` | WBS や作業一覧から依存関係・マイルストーン・バッファを含むガントチャートを Mermaid gantt で作り、クリティカルパスを示す |
| Skill | `kickoff-deck` | プロジェクトのキックオフ資料を、目的・スコープ・スケジュール・体制・進め方のルール・リスク・最初の2週間の構成でスライド単位の原稿にまとめる |
| Skill | `raci` | プロジェクトの体制図と RACI 表を作り、意思決定者・承認ルート・連絡経路を明確に |
| Skill | `risk-register` | プロジェクトのリスク一覧(リスク登録簿)を作り、発生可能性×影響でスコア化し、回避・軽減・移転・受容の対策、担当、見直し頻度を決める |
| Skill | `stakeholders` | プロジェクトの関係者を洗い出し、関心度×影響度マップで分類して、それぞれへの報告の頻度・形式・担当を決めたコミュニケーション計画を作る |
| Skill | `status-retro` | プロジェクトの進捗報告を信号の色の基準つきで作り、計画とのずれと対応を示す |
| Skill | `wbs` | チームのプロジェクトを成果物ベースで WBS に分解し、作業パッケージごとに担当・幅つき見積もり・完了条件を付けた表を作る |
| Agent | `pm-advisor` | プロジェクトの遅延・品質問題・メンバー不足などの状況から原因を切り分け、スコープ調整・優先順位の見直し・人員・期日交渉などの立て直し案を… |
| Agent | `schedule-checker` | プロジェクトの計画表・WBS・ガントチャート(Mermaid gantt を含む)を読み、クリティカルパス、無理な日程、担当の偏り、依存… |

### 🧪 product-planning(プロダクト企画)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `hypothesis-validation` | プロダクトの仮説を検証可能な形で書き、インタビュー・プロトタイプテスト・A/B テストなど適切な検証方法と、事前に決める判断基準を含む検… |
| Skill | `kpi-tree` | プロダクトの北極星指標を決めて KPI ツリーに分解し、先行指標と遅行指標、各指標の定義・測定方法・目標値・担当を整理 |
| Skill | `mvp-definition` | 新規プロダクトや新機能の MVP を、検証したい仮説・最小の機能・やらないこと・成功の基準と撤退の基準で定義 |
| Skill | `prd` | プロダクトや機能の PRD(プロダクト要求仕様書)を、背景・課題・対象ユーザー・目標指標・要件・非目標・リリース条件・未決事項の構成で作る |
| Skill | `prioritization` | 機能や施策の候補を RICE・MoSCoW・Kano モデルを使い分けて優先順位付けし、計算例つきで結果と判断理由を関係者に伝える形にま… |
| Skill | `roadmap` | プロダクトロードマップを Now / Next / Later の3段とテーマ単位で作り、日付を約束しすぎない書き方と更新のルールを決める |
| Skill | `story-map` | ユーザーの行動の流れに沿って活動→タスク→ストーリーの順にユーザーストーリーマップを作り、リリースごとの切れ目を引く |
| Agent | `pm-critic` | 企画書・PRD・MVP 定義・ロードマップを読み、「なぜ作るのか」「誰が困っているか」「成功をどう測るか」を問い直して、根拠の弱い前提や… |
| Agent | `user-voice` | 指定された想定ユーザー(架空の人物像)になりきり、機能案・画面案・文言に対して率直な第一印象・迷う点・使う/使わない理由を一人称で返す対… |

### 📖 story-structure(物語構造)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `character-arc` | 主人公や主要人物のキャラクターアーク(変化型・不変型・堕落型)を、欲しいもの/必要なもの/信じている嘘から設計し、物語の節目ごとの変化表に |
| Skill | `conflict-design` | 物語の葛藤を外的・内的・対人の3層で設計し、障害を段階的に強め、主人公に選択を迫る場面を作る |
| Skill | `foreshadowing` | 伏線と回収を、仕込む場所・見せ方・回収場所・読者の気づき度で設計表にし、ミスディレクションやチェーホフの銃の原則で過不足を点検 |
| Skill | `opening-ending` | 物語の冒頭(最初の一文、冒頭で示す問い・世界・人物)と結末の型(閉じる・開く・反転)を設計し、冒頭と結末を呼応させる |
| Skill | `pov-narration` | 一人称・三人称一元・三人称多元・神視点・二人称から作品に合う視点を選び、信頼できない語り手の設計や視点の切り替えルールを決める |
| Skill | `series-arc` | 長編シリーズや連載の構成を、巻(話)ごとのアークと全体のアーク、各巻の引き、謎の配分、設定の開示計画で設計 |
| Skill | `structure-catalog` | ヒーローズジャーニー・三幕構成・起承転結・序破急・エピソード型・群像劇などの構造の型を比べ、作品に合う型を選ぶ理由を示す |
| Skill | `theme-design` | 物語のテーマを「問い」の形に定め、対立する価値観・人物への割り振り・結末で示す答えを設計し、テーマを台詞で語らせず出来事で伝える方法を示す |
| Agent | `foreshadow-tracker` | 原稿から伏線の候補(意味ありげな物・台詞・描写・謎)を抽出して一覧にし、回収済み・未回収・回収が唐突なものを根拠付きで示す伏線管理の専門家 |
| Agent | `structure-analyst` | 原稿やあらすじから物語の構造(ビート・転換点・キャラクターアーク)を読み取り、表と Mermaid 図で可視化して、弱い箇所・たるむ箇所… |
| Agent | `theme-checker` | 原稿の場面ごとにテーマとのつながりを評価し、テーマから浮いている場面や、台詞・地の文でテーマを語りすぎて説教くさい箇所を指摘するテーマ批… |

### 🎭 genre-craft(ジャンル別の書き方)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `children-picturebook` | 絵本・児童書の原稿を、対象年齢に合った語彙と文の長さ、繰り返しとリズム、絵との分担、ページめくりの効果、安心できる結末の観点で設計・改稿… |
| Skill | `comedy-fiction` | コメディ小説(ユーモア小説・ドタバタ・日常系)を、キャラクター由来の笑い、状況の連鎖、テンポ、地の文のツッコミ、笑いとドラマの両立の観点… |
| Skill | `horror-writing` | ホラー小説・怪談を、恐怖の種類の選定、不安の積み上げ、見せない恐怖、日常からのずれ、緩急、結末の余韻の観点で設計・改稿 |
| Skill | `mystery-writing` | ミステリー小説(本格・日常の謎・倒叙など)を、フェアプレイの原則に沿って設計・検証 |
| Skill | `romance-writing` | 恋愛小説・ロマンスを、関係の進展段階、障害、二人の欠けたものが補い合う設計、すれ違いの必然性、満足できる結末の観点で設計・改稿 |
| Skill | `sf-fantasy-writing` | SF・ファンタジー小説で、設定の説明しすぎ(インフォダンプ)を避け、世界のルールを一貫させ、異質さと共感を両立し、用語を無理なく出すため… |
| Agent | `genre-reader` | 指定されたジャンル(ミステリー・ホラー・ロマンス・SF/ファンタジー・コメディ・児童書/絵本など)の熱心な読者として原稿を読み、ジャンル… |

### ✒️ writing-craft(文章術)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `connectives-logic` | 接続詞(順接・逆接・並列・補足・転換など)の使い分けを点検し、多用や省略しすぎ、論理の飛躍を見つけて文と文のつながりを整える |
| Skill | `metaphor-expression` | 直喩・隠喩・擬人法の使い分け、手垢のついた決まり文句の言い換え、抽象的な説明を具体例で伝える工夫、比喩の使いすぎの点検を行う |
| Skill | `openings-closings` | 書き出しのつかみの型、結論の置き方、余韻の残し方、冒頭と結びの呼応を使って、文章の最初と最後を磨く |
| Skill | `paragraph-design` | 段落の設計(最初の一文で要点を示す、1段落1話題、段落同士のつなぎ、段落の長さ)を整え、拾い読みでも伝わる文章に |
| Skill | `readability` | 漢字とひらがなの割合、句読点の位置、文末表現の単調さ、指示語の多用、数字の書き方を点検して、日本語の文章を読みやすく |
| Skill | `sentence-craft` | 一文一義と文の長さの技法で、長くて読みにくい文を分け、主語と述語を近づけ、修飾語の順序と文長のリズムを整える |
| Agent | `craft-coach` | 文章術のコーチとして、文章を添削しながら「どの技法を使い、なぜ直したか」を説明し、次に意識する点を3つ返す |
| Agent | `readability-scorer` | 日本語の文章ファイルを python3 標準ライブラリで計測し、平均文長・最長文・漢字の割合・読点の頻度・同じ文末の連続・段落の長さを数… |

### 📝 nonfiction-writing(ノンフィクションの書き方)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `autobiography` | 自分史を、年表づくり、テーマの選び方、家族や他人のプライバシーへの配慮、冊子・データなどの残し方まで順に進める |
| Skill | `column` | 時事や身近な話題を入り口に、独自の切り口で主張へ運ぶコラムを、字数の制約に合わせて組み立てる |
| Skill | `essay` | 個人的な体験から普遍的な気づきへとつなぐエッセイを、エピソードの選び方・構成の型・着地まで一緒に組み立てる |
| Skill | `experience-writing` | 留学・転職・闘病・子育て・旅などの体験記を、時系列と山場、感情と事実のバランス、読者の役に立つ情報を押さえて書く |
| Skill | `interview-article` | インタビュー記事を、事前準備と質問づくり、録音と書き起こし、Q&A形式か地の文形式かの選択、発言の整え方の範囲、相手の原稿確認まで通して作る |
| Skill | `reportage` | ルポルタージュを、取材計画、現場の描写、事実確認、取材相手の保護、主観と客観の書き分けまで押さえて書く |
| Skill | `review-critique` | 書評・映画評・作品レビューを、あらすじと評価の比率、ネタバレの扱い、根拠のある評価、作品への敬意を押さえて書く |
| Agent | `essay-editor` | エッセイ・コラムを文芸誌やウェブ媒体の編集者の目線で読み、読みどころ・弱いところ・タイトル案・削るべき箇所を返す |

### 🍳 cooking(料理)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `baking-science` | お菓子とパンがうまくいく理由・失敗する理由を、計量の厳密さ、小麦粉・砂糖・卵・油脂・膨張剤の役割、発酵、オーブン温度の観点から説明し、失… |
| Skill | `bento` | お弁当のおかず構成、詰め方、彩り、傷みにくくする工夫、作り置きや冷凍おかずの活用を、子ども向け・大人向けに合わせて提案 |
| Skill | `budget-cooking` | 安い食材の使い回し、まとめ買いと使い切り、食品ロスの削減、1食あたりのコスト計算で、無理なく食費を下げる料理の工夫を提案 |
| Skill | `cooking-basics` | 切り方、火加減、下処理、だしの取り方、調味の順番(さしすせそ)、計量の仕方など、料理の基本を理由つきで具体的に教える |
| Skill | `cooking-timeline` | 複数の料理を同じ時刻に温かい状態で仕上げるため、食卓に出す時刻からの逆算タイムラインを作り、コンロ・オーブン・電子レンジ・炊飯器の割り振… |
| Skill | `flavor-balance` | 塩味・甘味・酸味・うま味・苦味・辛味のバランスを見て味を整え、しょっぱい・薄い・甘すぎる・焦げた・固い・水っぽいなどの失敗をリカバリーす… |
| Skill | `food-safety` | 食中毒予防の三原則(つけない・増やさない・やっつける)、加熱の目安、生食の注意、冷蔵冷凍と解凍、作り置きの保存期間の目安、アレルギー表示… |
| Skill | `nutrition-balance` | 主食・主菜・副菜、一汁三菜の考え方で、1食・1日の栄養バランスを一般的な目安で確認し、たんぱく質や野菜の取り方を具体的な料理で提案 |
| Skill | `recipe-scaling` | レシピの分量を人数や型・鍋のサイズに合わせて換算し、g⇔ml⇔大さじ、海外レシピの cup・oz・lb・°F も日本の単位に直す |
| Skill | `recipe-writing` | 他の人が読んでも同じ味に再現できるレシピを書く・書き直す |
| Skill | `seasonal-ingredients` | 季節ごとの旬の野菜・魚・果物を、選び方と旬のおいしい食べ方つきで一覧に |
| Skill | `substitution` | 材料や調味料がないときの代わり、アレルギーや食習慣に合わせた置き換えを、分量の比率と仕上がりの違いつきで提案 |
| Skill | `world-cuisine` | 和・中・伊・仏・韓・タイ・インド・メキシコなど世界の料理の「基本の型」(基本調味料、香りの土台、代表的な調理法)と、日本の家庭で手に入る… |
| Agent | `cooking-coach` | 調理中に1ステップずつ案内する料理コーチ |
| Agent | `cooking-troubleshooter` | 料理の失敗(膨らまない、水っぽい、固い、焦げた、味がぼやける等)の状況を聞き取り、原因を可能性の高い順に挙げて、今からできるリカバリーと… |
| Agent | `nutrition-estimator` | レシピの材料と分量から、エネルギー・たんぱく質・脂質・炭水化物・食塩相当量の概算(推定値)を1人分と全量で出す栄養概算の専門家 |
| Agent | `recipe-tester` | レシピ原稿を読み、材料と手順の不一致、分量の抜け、曖昧な表現、時間・温度の欠落、安全上の問題を重要度付きで指摘するレシピ校閲の専門家 |

### 🇬🇧 english-learning(英語学習)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `business-english` | 英語のビジネスメール、会議、プレゼン、電話・オンライン会議で使う表現を、丁寧さの段階付きでまとめ、そのまま使える文面やフレーズ集を作ります |
| Skill | `common-mistakes` | 日本語話者に多い英語の誤り(冠詞、可算/不可算、時制、前置詞、直訳表現)と和製英語を、×→○と理由付きで整理し、自分の弱点チェックリスト… |
| Skill | `english-diary` | 英語日記の書き方の型、そのまま使える表現、添削の受け方、続けるコツをレベル別にまとめ、今日の日記を書き始める手伝い |
| Skill | `english-exam-strategy` | TOEIC L&R / S&W、英検、IELTS、TOEFL iBT の特徴と勉強法の違いを整理し、目的とレベルに合う試験選びと、技能別… |
| Skill | `instant-composition` | 日本語を見て数秒で英語にする「瞬間英作文」のドリルを、文型・文法項目別、レベル別に作り、復習の回し方まで示 |
| Skill | `listening-strategy` | 英語リスニングの勉強法(多聴と精聴の使い分け、ディクテーション、スクリプトと英語字幕の使い方、教材の選び方)を、レベルと目的に合わせた週… |
| Skill | `nuance-synonyms` | look/see/watch のような英語の類義語のニュアンスの違いを、比較表・例文・使い分けテスト付きで説明 |
| Skill | `phrasal-verbs-idioms` | よく使う英語の句動詞とイディオムを、テーマ別に意味・例文・フォーマル度・言い換え付きでまとめ、意味の推測の仕方も教えます |
| Skill | `pronunciation` | 日本語話者が苦手な英語の音(L/R・th・v/b・母音)、強勢とリズム、リンキング・リダクション・フラッピングを、IPA と練習ドリル付… |
| Skill | `speaking-frameworks` | 英語で話すときの型(PREP、1分スピーチ)と、意見を言う・反論する・時間を稼ぐ表現、フィラーの使い方を、レベル別の例付きでまとめます |
| Skill | `travel-english` | 海外旅行で使う英語(空港・ホテル・レストラン・買い物・交通・トラブル時)と聞き返し方を、そのまま言える短いフレーズ集にまとめます |
| Skill | `word-roots` | 英単語を接頭辞・語根・接尾辞に分解し、語源から意味を推測したり派生語をまとめて覚えたりできる表と練習を作ります |
| Agent | `english-tutor` | 簡単なレベル診断(CEFR の目安)をしてから、目標に合わせた短い英語レッスン(説明→例→練習→フィードバック)を1回ずつ行う対話型の家… |
| Agent | `exam-english-coach` | TOEIC・英検・IELTS・TOEFL などの形式を模したオリジナル問題を1問ずつ出し、解答に解説と解き方のコツを返す対話型の試験対策… |
| Agent | `instant-composition-drill` | 瞬間英作文のドリル担当 |
| Agent | `nuance-explainer` | 学習者の英文を読み、文法的には正しいが不自然な箇所やニュアンスのずれを「なぜネイティブはそう言わないか」の理由付きで解説する英語学習者向… |

### 🇰🇷 korean-learning(韓国語学習)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `common-mistakes` | 日本語話者が韓国語で間違えやすい点(助詞の直訳、漢字語の意味のずれ、「〜です」の訳し分け、分かち書き、語順は同じでも違う点)を、学習者の… |
| Skill | `conjugation` | 韓国語の用言の活用(語幹、陽母音・陰母音による아/어の選択、ㅂ・ㄷ・ㅅ・ㅎ・르・으・ㄹ語幹の不規則活用、時制、よく使う連結語尾)を表と例… |
| Skill | `hangul-basics` | ハングルの読み書きを、子音・母音・パッチムの組み立て、書き順、反切表の使い方、最初の1週間の練習メニューまで具体的に教えます |
| Skill | `learn-with-content` | K-POP・ドラマ・ウェブトゥーン・バラエティなど好きなコンテンツで韓国語を学ぶ計画を、教材の選び方、字幕の使い方、口語表現・略語の扱い… |
| Skill | `particles` | 韓国語の助詞(은/는と이/가の使い分け、을/를、에/에서、로/으로、와/과・하고・랑など)を、パッチムの有無による形の違いと日本語との対… |
| Skill | `pronunciation-rules` | 韓国語の発音変化(連音化・鼻音化・激音化・濃音化・流音化・口蓋音化・ㅎの弱化)を表と例で説明し、平音・激音・濃音やパッチムㄴ/ㅇ/ㅁなど… |
| Skill | `sino-korean-vocab` | 漢字の日本語音読みとハングル音の対応(例: 学→학、国→국)を規則の目安と例外つきで示し、漢字語で韓国語の語彙を効率よく増やす単語リスト… |
| Skill | `situational-conversation` | 自己紹介、カフェ、買い物、交通、旅行、友だちとの会話など場面別の韓国語フレーズと短い会話例を、聞き返し方・あいづち付きでまとめます |
| Skill | `speech-levels` | 韓国語の語尾と敬語(합니다体・해요体・반말の使い分け、尊敬の시、謙譲表現)を、相手と場面別の選び方の基準と例文で説明 |
| Skill | `topik-strategy` | TOPIK(韓国語能力試験)とハングル能力検定の違いを整理し、レベル別の勉強法、作文(TOPIK II 筆記)の型、オリジナルの練習問題… |
| Agent | `korean-composition-drill` | 韓国語の瞬間作文ドリル担当 |
| Agent | `korean-corrector` | 韓国語の作文・日記を添削する専門家 |
| Agent | `korean-tutor` | ハングルが読めるかから始める簡単なレベル診断のあと、目標に合わせた短い韓国語レッスン(説明→例→練習→フィードバック)を1回ずつ行う対話… |

### 🇪🇸 spanish-learning(スペイン語学習)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `common-mistakes` | 日本語話者がスペイン語で間違えやすい点(主語の言い過ぎ、性数一致、por と para、gustar 型動詞、冠詞の有無、偽の同族語・カ… |
| Skill | `dele-strategy` | DELE とスペイン語技能検定(西検)の違いを整理し、レベル別の勉強法、作文と口頭試験の型、オリジナルの練習問題を作ります(形式は公式で… |
| Skill | `gender-articles` | スペイン語の名詞の性(男性・女性の見分け方と例外)、定冠詞・不定冠詞、形容詞の性数一致、複数形の作り方を、例外リストと練習問題付きでまと… |
| Skill | `object-pronouns` | スペイン語の目的格代名詞(直接目的格 lo/la、間接目的格 le、se lo の形)の使い分けと語順(活用動詞の前・不定詞や命令形の後… |
| Skill | `past-tenses` | スペイン語の過去時制(点過去=pretérito indefinido、線過去=imperfecto、現在完了=pretérito pe… |
| Skill | `pronunciation-accent` | スペイン語の発音(母音5つ、r と rr、j・g・ll・y・ñ・c/z)とアクセントの位置・アクセント記号の規則を、日本語話者向けにカタ… |
| Skill | `regional-variation` | スペインと中南米のスペイン語の違い(vosotros/ustedes、voseo、発音、語彙 coche/carro など)を、どちらも… |
| Skill | `ser-estar` | スペイン語の ser と estar(どちらも「〜である」)の使い分けを、本質と状態・場所と出来事・意味が変わる形容詞・間違えやすい例で… |
| Skill | `situational-conversation` | スペイン語の場面別会話(自己紹介、旅行、レストラン、買い物、道案内、友だちとの会話、聞き返し方)のフレーズ集と短いモデル会話を、丁寧さ(… |
| Skill | `subjunctive` | スペイン語の接続法(subjuntivo)を、使う場面(願望・感情・疑い・目的・未来の時の節)の見分け方、現在形と過去形の作り方、よく使… |
| Skill | `verb-conjugation` | スペイン語の動詞の活用(規則活用 -ar/-er/-ir、主な不規則動詞、語幹母音変化、再帰動詞)を活用表と覚え方のコツ付きで整理し、練… |
| Agent | `conjugation-drill` | スペイン語の動詞活用ドリル担当 |
| Agent | `spanish-corrector` | スペイン語の作文・日記を添削し、直した理由(性数一致、活用、時制、ser/estar、por/para、アクセント記号、自然さ)と、よく… |
| Agent | `spanish-tutor` | 簡単なレベル診断(CEFR の目安)と学ぶ地域(スペイン/中南米)の確認をしてから、目標に合わせた短いスペイン語レッスンを1回ずつ行う対… |

### 🤝 sales(営業)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `account-growth` | 既存顧客との関係を深めるため、定期フォロー、アップセル・クロスセルの提案、解約の兆候の見つけ方、紹介の依頼の仕方を計画 |
| Skill | `closing` | 商談の終盤で、決裁プロセスを確認し、次の一歩(試用・稟議・契約)を押し売りにせず合意する進め方とトークを作る |
| Skill | `follow-up` | 商談後・検討中・失注後のフォローアップを、タイミングと内容の計画、メール文面まで作り、売り込みすぎずに関係を保つ |
| Skill | `hearing` | 商談のヒアリングを SPIN と BANT で設計し、質問の順番・課題の深掘り・議事メモの型まで用意 |
| Skill | `objection-handling` | 商談で出る「高い」「今じゃない」「他社と比べたい」「上に相談する」などの反論に、営業特有の型で対応するトークと次の一手を作る |
| Skill | `outreach` | 新規の見込み客への初回メール・問い合わせフォーム文・電話のトーク台本を、件名や相手に合わせた一文まで含めて作る |
| Skill | `pipeline-management` | 商談ステージの定義、KPI(商談数・受注率・単価・期間)、CRM に記録する項目、売上予測の立て方を設計 |
| Skill | `prospecting` | BtoB を中心に、理想の顧客像(ICP)を決め、情報源から見込み客リストを作り、優先順位をつけるまでを手伝う |
| Skill | `sales-proposal` | 商談後に顧客へ出す営業提案書を、課題→解決策→効果→費用→導入計画→実績の流れで、相手の言葉を使って作る |
| Agent | `deal-reviewer` | 商談メモ・議事録・CRM の記録を読み、決裁者・予算・課題・期限の把握漏れ、次の一手、失注リスクを指摘する商談レビューの専門家 |
| Agent | `proposal-critic` | 営業提案書を買い手(担当者と決裁者)の目線で読み、刺さらない点・根拠の弱い点・費用対効果の分かりにくさを指摘する批評家 |
| Agent | `sales-roleplay` | BtoB 商談の買い手役(担当者・決裁者・慎重派・比較検討中など)をペルソナカードと納得ゲージで演じ、簡単には納得しない練習相手になる対… |

### 📈 web-marketing-learning(Webマーケティングを学ぶ)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `ab-testing` | 仮説の立て方、1つずつ変える原則、サンプル数と期間の考え方、統計のよくある誤解、結果の判断まで、A/B テストの基本を入門/中級レベル別… |
| Skill | `analytics-basics` | セッション・ユーザー・直帰率/エンゲージメント・CVR・流入元など、アクセス解析の指標の意味と読み方、数字を解釈するときの注意を入門/中… |
| Skill | `content-marketing` | 目的設定、ペルソナ、テーマ設計、継続の仕組み、効果測定まで、コンテンツマーケティングの戦略の考え方を入門/中級レベル別に学ぶ教材です |
| Skill | `email-marketing` | リストの集め方、セグメント、ステップメール、開封率・クリック率の読み方、配信停止と特定電子メール法などの法令まで、メールマーケティングの… |
| Skill | `funnel-design` | 認知→興味→比較→購入→継続のファネルとカスタマージャーニーの考え方、段階ごとの施策と指標の対応を、入門/中級レベル別に学ぶ教材です |
| Skill | `marketing-fundamentals` | 3C・STP・4P/4C・ポジショニング・顧客価値といったマーケティングの基本フレームを、身近な商品の例で入門/中級レベル別に学ぶ教材です |
| Skill | `marketing-glossary` | Web マーケティングの用語をカテゴリ別に、一言説明・例・混同しやすい用語のペアで整理して学ぶ用語集です |
| Skill | `marketing-kpi` | CPA・CPC・CTR・CVR・LTV・ROAS・CAC などの指標の意味と計算、指標どうしの関係を、計算練習つきで入門/中級レベル別に… |
| Skill | `seo-basics` | 検索エンジンの仕組み、検索意図、キーワードの考え方、内部対策・コンテンツ・被リンク、やってはいけない施策まで、SEO の基本を入門/中級… |
| Skill | `web-ads-basics` | 検索広告・ディスプレイ広告・SNS 広告・動画広告の違い、入札と品質の考え方、ターゲティング、予算の決め方など、Web 広告の仕組みを入… |
| Agent | `campaign-plan-reviewer` | マーケティング施策の計画書を読み、目的と KPI の対応、ターゲットの曖昧さ、測定方法の欠落、予算配分の根拠、法令上の注意を指摘するレビ… |
| Agent | `case-study-coach` | 架空の事業のケーススタディを出題し、情報は「聞かれたら出す」形で開示、ユーザーの施策案には架空の会社の担当者として簡単には納得せず反論し… |
| Agent | `marketing-tutor` | Web マーケティングを体系的に学びたい人の家庭教師です |

### 📲 sns-operations(SNS運用)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `account-design` | SNS アカウントの目的・ターゲット・コンセプト・発信テーマの柱・プロフィール・媒体選びを設計 |
| Skill | `community-management` | SNS のコメント・DM への返信方針、よくある質問の回答集、批判コメントへの対応、ブロック・非表示の基準、個人情報の扱いを決めます |
| Skill | `content-calendar` | SNS の投稿カレンダーを作ります |
| Skill | `crisis-response` | SNS での炎上・批判の拡大に備え、兆候の見つけ方、初動、事実確認、お詫び文の考え方、やってはいけない対応、平常時の準備をまとめます |
| Skill | `growth-experiments` | SNS 運用の改善を実験として設計・記録・判定 |
| Skill | `influencer-collab` | インフルエンサーへの依頼や UGC(お客様の投稿)の活用を、選び方・依頼内容・ステマ規制と PR 表記・契約で決めることまで整理 |
| Skill | `insights-analysis` | SNS のインサイト(数値)を読み解き、伸びた投稿と伸びなかった投稿を比べて仮説と次の投稿案を出し、週次・月次レポートにまとめます |
| Skill | `platform-mechanics` | X・Instagram・TikTok・YouTube・LINE などの特徴と「投稿がどう表示されるか」の考え方を、断定せず一般論として解説 |
| Skill | `short-video-strategy` | リール・TikTok・YouTube ショートなどショート動画の企画の型、冒頭数秒の作り方、シリーズ化、投稿後の分析までの戦略を立てます |
| Agent | `account-auditor` | SNS アカウントの診断役 |
| Agent | `crisis-advisor` | SNS の炎上・批判が起きたとき(または起きそうなとき)に状況を聞き取り、事実確認すべきこと、初動の選択肢、発信文の注意点、社内で決める… |
| Agent | `sns-coach` | SNS 運用を学びたい人のための対話型コーチ |

### 🧠 psychology(心理学を学ぶ)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `cognition-memory` | 注意・知覚・記憶の種類と仕組み・忘却、学習に役立つ知見(分散学習・想起練習など)を確度付きで教える |
| Skill | `developmental` | 生涯発達、愛着、認知発達の主要な理論(ピアジェ、ヴィゴツキー、エリクソン、ボウルビィなど)と現在の評価を教える |
| Skill | `emotion` | 感情の主な理論、感情と判断の関係、感情の調整の方法(一般論)を確度付きで教える |
| Skill | `everyday-application` | 勉強・仕事・人間関係で使える心理学の知見を、確度付きで具体的な行動に落とし込む |
| Skill | `learning-motivation` | 古典的・オペラント条件づけ、内発的・外発的動機づけ、自己決定理論、自己効力感を、身近な例と確度付きで教える |
| Skill | `positive-psychology` | ウェルビーイング、強み、感謝などポジティブ心理学の研究を、効果の大きさと限界も含めて教える |
| Skill | `psychology-overview` | 心理学の全体像(主な分野、研究の対象と方法、学ぶ順番、よくある誤解)をレベルに合わせて案内 |
| Skill | `research-literacy` | 心理学の研究の読み方(実験と相関、サンプル、効果量、再現性の危機、ポップ心理学の見分け方)を教え、記事や研究紹介をチェック |
| Skill | `social-psychology` | 同調、服従、帰属、態度と説得、集団の心理を、有名な研究とその後の批判・再現性も含めて正直に教える |
| Agent | `experiment-explainer` | 有名な心理学実験(ミルグラム、アッシュ、スタンフォード監獄実験、マシュマロ・テスト、リトル・アルバートなど)について、目的・方法・結果・… |
| Agent | `myth-buster` | 「心理学で〇〇と言われている」という俗説やネット・SNS・本の話を、研究の状況(支持されている/議論あり/再現されない/俗説)で判定し、… |
| Agent | `psych-tutor` | 学習者のレベルと関心に合わせて、心理学の短いレッスンと確認問題を1回の呼び出しで1つずつ行う対話型の家庭教師 |

### 🏛️ philosophy(哲学を学ぶ)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `applied-ethics` | AI 倫理、生命倫理、環境倫理、ビジネス倫理などの具体的な問題について、論点を整理し、複数の立場とその根拠・反論を示す |
| Skill | `eastern-philosophy` | 儒教、道家、仏教思想、日本の思想の概要を、主な問い・人物・考え方で整理し、西洋哲学と比べるときの注意点も示す |
| Skill | `epistemology` | 認識論(知識とは何か、合理論と経験論、懐疑論、ゲティア問題、正当化の理論など)を、身近な例と確認問題つきで説明 |
| Skill | `ethics` | 規範倫理学の主要な立場(功利主義・義務論・徳倫理・契約説)の考え方、強み、代表的な批判を整理し、具体的な事例に当てはめて比べる |
| Skill | `history-of-philosophy` | 古代ギリシア→中世→近代→現代という哲学史の流れを、各時代の主な問いと人物でたどり、学ぶ順番や入門の道筋を示す |
| Skill | `metaphysics` | 形而上学の主要テーマ(存在、心身問題、自由意志、時間、人格の同一性)を、問い・主な立場・反論・身近な例で整理 |
| Skill | `political-philosophy` | 正義、自由、平等、国家の正当性について、功利主義・リベラリズム・リバタリアニズム・共同体主義などの主要な立場を比較し、具体的な制度の論点… |
| Skill | `reading-primary-texts` | 哲学の原典を読むための方法(翻訳・版の選び方、段落ごとの要約、論証の再構成、ノートの取り方、入門書との併用)を、読みたい本に合わせた読書… |
| Skill | `thought-experiments` | トロッコ問題、中国語の部屋、テセウスの船、水槽の脳などの有名な思考実験について、何を問うものか・主な応答・批判を整理し、自分でも考えられ… |
| Agent | `argument-mapper` | 文章や主張から論証の構造(前提・結論・隠れた前提・推論の型)を取り出し、Mermaid 図と表で示して、弱い箇所を指摘する論証分析の専門家 |
| Agent | `ethics-case-discussant` | 倫理的なジレンマの事例について、功利主義・義務論・徳倫理・契約説などの立場からの見方を整理し、ユーザー自身の判断とその理由を問い返す対話… |
| Agent | `philosophy-tutor` | 学習者のレベルと関心に合わせて、哲学の問いを一つ投げ、考え方を紹介し、学習者の考えを聞いて、反論や別の立場を示す対話型の哲学チューター |

### 💹 behavioral-economics(行動経済学を学ぶ)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `applications` | 行動経済学をお金・健康・習慣・仕事の自分の行動に応用し、効果の確度が高い工夫から 1〜3 個だけ選んで試す計画を作る(やりすぎない) |
| Skill | `be-overview` | 行動経済学の全体像(伝統的な経済学との違い、限定合理性、システム1/2の考え方とその限界、主要な研究者と業績)を、レベル別に説明→身近な… |
| Skill | `game-theory-basics` | ゲーム理論の基礎(利得表、囚人のジレンマ、ナッシュ均衡、協調ゲーム、繰り返しゲームと応報戦略)を身近な例と確認問題で学び、実際の人の振る… |
| Skill | `heuristics-biases` | ヒューリスティクスとバイアス(アンカリング、利用可能性、代表性、現状維持、保有効果、フレーミングなど)を、研究の確度と再現性の状況付きで… |
| Skill | `mental-accounting` | メンタルアカウンティング(お金の心の会計、財布の分け方、サンクコスト、ハウスマネー効果、支払いの痛み)を身近な例で学び、自分の家計を見直… |
| Skill | `nudge-design` | ナッジ(選択の自由を残したまま行動を後押しする工夫)を EAST フレームワークとデフォルト設計で考え、透明性・選択の自由・相手の利益の… |
| Skill | `prospect-theory` | プロスペクト理論と損失回避(価値関数、参照点、感応度逓減、確率加重、4 つのパターン)を、身近な例と「あなたならどちらを選ぶ?」の問題で… |
| Skill | `reading-research` | 行動経済学の研究やポップな解説記事・書籍を読むときに、実験の種類(実験室・フィールド・自然実験)、効果量、サンプルサイズ、再現性、出版バ… |
| Skill | `social-preferences` | 社会的選好(公平性、不平等回避、互恵性、利他性)と、最後通牒ゲーム・独裁者ゲーム・公共財ゲーム、社会規範の働きを、体験問題と確度付きで学ぶ |
| Skill | `time-preference` | 時間選好(指数割引と双曲割引、現在バイアス、先延ばし、コミットメント装置)を学び、貯蓄・ダイエット・勉強などに応用する工夫を確度付きで整理 |
| Agent | `be-tutor` | 行動経済学の家庭教師 |
| Agent | `dark-pattern-detector` | Web ページ・アプリの文言、画面の説明、申込・解約フローを読み、ダークパターン(偽の緊急性・偽の希少性、解約の妨害、事前チェック、隠れ… |
| Agent | `decision-review-coach` | ユーザーの過去の意思決定(買い物、仕事の選択、引っ越し、契約など)を一緒に振り返り、働いた可能性のあるバイアスと次に使える工夫を、責めず… |

### 🥋 training-dojo(トレーニング道場・共通)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `adaptive-difficulty` | 練習ログ(v2 の9列)と実践の記録から苦手な観点を判定し、次回のメニュー(レッスン→ドリル ID→相手役のペルソナのつまみ)を組み、難… |
| Skill | `dojo-start` | 道場での練習を始めるために、伸ばしたい力・実践の場面を含む期限つきの目標・現在地の簡易診断・最初の相手役の難易度・1回15〜30分の1週… |
| Skill | `evidence-based-scoring` | 道場の採点を「ユーザーの発言の引用」と「行動の数(質問数・オープン率・要約の回数・引き出した懸念の数など)」に基づいて行うためのルール、… |
| Skill | `learn-practice-feedback` | 道場の「① 学ぶ → ② 練習する → ③ フィードバック → ④ 実践で試す・振り返る」のサイクルを回すルール(各段階でやること・相手… |
| Skill | `persona-card` | 道場のロールプレイで相手役が使うペルソナカード(架空の名前・立場・本当の利害・予算と権限・警戒心・隠れた懸念・情報開示ルール・納得条件・… |
| Skill | `practice-log` | 道場の練習ログを共通形式 v2(1回1行・9列、種別は AI/実践)で作成・追記し、週ごとのまとめを書く |
| Skill | `progress-report` | 練習ログから週次・月次の成長レポート(観点別スコアの推移、伸びた点、停滞している点、AI 練習と実践の比較、次の重点)を作る |
| Skill | `real-world-debrief` | 実際の商談・会議・交渉・発表・外国語での会話のあとに、状況・目的・匿名化した相手・重要な発言・結果・感触を記録し、道場の rubric … |
| Skill | `rubric-design` | どの道場にもない力(プレゼン、面接、文章、電話対応など)を練習するために、自分用の評価基準(観点4〜6 × 4段階、行動で書く)を作る |
| Skill | `simulation-realism` | 道場のロールプレイで相手役が簡単に納得しないためのルール、納得ゲージ(0〜10、初期値・上下の条件・しきい値・記録方法)、よくある「甘い… |
| Skill | `spaced-review` | 練習ログから「できなかった点」を拾い、何日後にもう一度練習するかの間隔(1→3→7→14→30日)を決めて復習リストを作る |
| Agent | `behavior-counter` | 練習記録や実践の振り返り記録から、ユーザーの発言について道場ごとの行動指標(質問数・オープン/クローズド・要約や確認の回数・引き出した懸… |
| Agent | `dojo-master` | 道場の師範 |
| Agent | `feedback-coach` | どの道場にも当てはまらない練習(プレゼン、面接、文章、電話対応など)や実践の振り返りを、ユーザーが示した目標か rubric-desig… |
| Agent | `progress-analyst` | dojo/ フォルダの練習ログ(v2 の9列、v1 の8列も可)を集計し、種別(AI/実践)ごとの観点別スコアの推移・練習頻度・停滞して… |
| Agent | `real-debrief-coach` | 実際の商談・会議・交渉・発表・外国語での会話のあとに、1回に1〜2問ずつ質問して状況・目的・やり取り・結果を聞き取り、匿名化した振り返り… |
| Agent | `realism-auditor` | ロールプレイの練習記録(会話・状態サマリ・ペルソナカード)を読み、相手役がペルソナに忠実だったか、納得ゲージの上げ方が甘くなかったか、隠… |
| Agent | `training-planner` | dojo/ の練習ログ(v2 の9列)と dojo/real/ の実践の記録を読み、苦手な観点、次回のメニュー(レッスン→ドリル ID→… |

### 🗣️ language-dojo(語学道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `language-curriculum` | どの言語でも使える語学道場の単元一覧を、CEFR A1〜C1 の Can-do(〜できる)で到達目標・4技能×場面・学ぶ順番・レベル診断… |
| Skill | `language-drills` | 語学道場の②「練習」 |
| Skill | `language-lesson` | 語学道場の①「学ぶ」 |
| Skill | `language-rubric` | 語学道場の③「フィードバック」の評価基準 |
| Agent | `language-evaluator` | 語学道場の評価役 |
| Agent | `language-sparring` | 語学道場の練習相手 |

### 🤝 sales-dojo(営業道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `sales-curriculum` | 営業道場の単元一覧(準備・アプローチ・ヒアリング・提案・反論対応・クロージング・フォロー・既存顧客)と到達目標、学ぶ順番、レベル診断を示… |
| Skill | `sales-drills` | 営業道場の練習メニュー |
| Skill | `sales-lesson` | 営業道場の 1 単元(ヒアリング・反論対応・クロージングなど)を、5 分で読める説明・良い例と悪い例・ポイント 3 つ・理解確認の問い … |
| Skill | `sales-rubric` | 営業ロープレ・商談の振り返りを採点する評価基準(質問力・課題把握・提案力・反論への対応・進行と次の一歩・誠実さ × 4 段階) |
| Agent | `sales-evaluator` | sales-roleplay の練習記録(納得ゲージの推移・納得条件の達成状況を含む)、1 人ドリルの回答、実際の商談の振り返り記録を … |

### 💬 communication-dojo(コミュニケーション道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `communication-curriculum` | コミュニケーション道場の単元一覧(傾聴・質問・わかりやすい説明・報連相・雑談・フィードバックの伝え方・難しい会話)を、入門/中級/上級の… |
| Skill | `communication-drills` | コミュニケーション道場の②「練習」 |
| Skill | `communication-lesson` | コミュニケーション道場の①「学ぶ」 |
| Skill | `communication-rubric` | コミュニケーション道場の③「フィードバック」の評価基準 |
| Agent | `communication-evaluator` | コミュニケーション道場の評価役 |
| Agent | `communication-sparring` | コミュニケーション道場の練習相手 |

### ⚖️ negotiation-dojo(交渉道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `negotiation-curriculum` | 交渉道場の単元一覧(準備〈BATNA・留保価格・利害〉、アンカリング、譲歩、価値の創造、難しい相手、合意の確認)と到達目標、学ぶ順番、レ… |
| Skill | `negotiation-drills` | 交渉道場の練習メニュー |
| Skill | `negotiation-lesson` | 交渉道場の 1 単元(BATNA と準備・アンカリング・譲歩・価値の創造・難しい相手・合意の確認)を、5 分で読める説明・良い例と悪い例… |
| Skill | `negotiation-rubric` | 模擬交渉や実際の交渉の振り返りを採点するための評価基準(準備・利害の探り方・提案の作り方・譲歩の管理・関係の維持・合意内容の明確さ × … |
| Agent | `negotiation-evaluator` | negotiation-sparring との模擬交渉の記録(納得ゲージの推移・納得条件の達成状況を含む)、1 人ドリルの回答、実際の交… |

### 📈 marketing-dojo(マーケティング道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `marketing-curriculum` | マーケティング道場の単元一覧(顧客理解・STP・価値提案・4P・集客・数値管理・ブランド)を入門/中級/上級で示し、レベル診断から学ぶ順… |
| Skill | `marketing-drills` | マーケティング道場の練習課題集です |
| Skill | `marketing-lesson` | マーケティング道場の1単元(顧客理解・STP・価値提案・4P・集客・数値管理・ブランド)を、5分で読める説明→良い例と悪い例→ポイント3… |
| Skill | `marketing-rubric` | マーケティング道場の評価基準です |
| Agent | `marketing-evaluator` | マーケティングの施策案・ドリル回答・case-study-coach やクライアント役とのやり取りの記録・実務の振り返り記録を mark… |

### 🧩 logic-dojo(論理的思考道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `logic-curriculum` | 論理的思考道場の単元一覧(演繹と帰納、主張と根拠、MECE、ロジックツリー、ピラミッド構造、So what/Why so、要約、反論と再… |
| Skill | `logic-drills` | 論理的思考のドリル集(根拠の不足を見つける、MECE に分ける、結論を一文にする、ピラミッドを組む、誤謬の指摘、300字要約、反論と再反… |
| Skill | `logic-lesson` | 論理的思考道場の 1 単元(主張と根拠、MECE、ピラミッド構造、So what/Why so、要約、反論、誤謬など)を、5 分で読める… |
| Skill | `logic-rubric` | 論理的思考の評価基準(主張の明確さ、根拠の妥当性、構造(MECE)、つながり、反論への備え、簡潔さ)を 4 段階の行動例つきで示し、数え… |
| Agent | `logic-evaluator` | 論理的思考道場の評価役 |
| Agent | `logic-sparring` | 論理的思考ドリルの出題役兼練習相手 |

### 🔧 problem-solving-dojo(問題解決道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `problem-solving-curriculum` | 問題解決道場の単元一覧(問題の定義、問題の分解、原因分析、仮説思考、打ち手の発想と評価、優先順位、実行計画と検証)と学ぶ順番を示し、レベ… |
| Skill | `problem-solving-drills` | 問題解決の練習メニュー集 |
| Skill | `problem-solving-lesson` | 問題解決道場の 1 単元(問題の定義、分解、原因分析、仮説思考、打ち手、優先順位、実行計画)を、5 分で読める説明・良い例と悪い例・ポイ… |
| Skill | `problem-solving-rubric` | 問題解決の評価基準(問題の定義、分解の質、仮説と検証、打ち手の具体性、優先順位の根拠、実行可能性)を 4 段階の行動例つきで示し、数えら… |
| Agent | `case-interviewer` | ケース面接官役の練習相手 |
| Agent | `problem-solving-evaluator` | 問題解決道場の評価役 |

### 🏢 business-dojo(経営・ビジネス道場)
| 種類 | 名前 | 内容 |
|---|---|---|
| Skill | `business-curriculum` | 経営・ビジネス道場の単元一覧(戦略・会計・ファイナンス基礎・組織と人・オペレーション・リーダーシップ・事業計画)を入門/中級/上級で示し… |
| Skill | `business-drills` | 経営・ビジネス道場の演習集です |
| Skill | `business-lesson` | 経営・ビジネス道場の1単元(戦略・財務三表・損益分岐とキャッシュフロー・組織と人・オペレーション・リーダーシップ・事業計画)を、5分で読… |
| Skill | `business-rubric` | 経営・ビジネス道場の評価基準です |
| Agent | `business-evaluator` | 経営判断のドリル回答、business-simulator の評価用の記録(納得ゲージ・納得条件の達成状況を含む)、実務の判断の振り返り… |
| Agent | `business-simulator` | 架空の会社の経営者としてユーザーに毎期の意思決定を求め、その結果(売上・利益・現金・社員の士気など)と、社員・顧客・銀行・株主のペルソナ… |

## 組み合わせ例(「作る skill → 評価する agent」)

一気通貫で実行したい場合は `workflows` プラグインの各フローを使ってください。

- **ブログ記事**(`/workflows:publish-flow`): `trend-researcher` → `/content:blog-article` → `seo-auditor` → `headline-tester` → `/writing:japanese-proofread`
- **小説**(`/workflows:novel-flow`): `idea-brainstormer` → `/creative:plot-builder` → `/creative:character-sheet`(`character-interviewer` で深掘り)→ `/creative:scene-writer` → `continuity-checker` と `beta-reader` → `/creative:revision-pass`
- **新人賞応募**: `contest-judge` と `sensitivity-reader` でチェック → `/creative:synopsis-logline` で梗概作成
- **プレゼン**(`/workflows:presentation-flow`): `/presentation:slide-outline` → `/presentation:marp-slides` → `audience-critic` と `qa-predictor` → `/presentation:speaker-notes`
- **企画提案**(`/workflows:proposal-flow`): `/marketing:persona` → `/business:proposal-doc` → `logic-checker` と `risk-reviewer`
- **学習**(`/workflows:study-flow`): `/research:learning-roadmap` → `/research:study-notes` → `/research:flashcards` → `/research:feynman-check` と `socratic-tutor`
- **研究・レポート**(`/workflows:research-report-flow`): `/research:research-question` → `/research:paper-reading` → `/research:literature-review` → `devils-advocate` → `/research:citation-formatter`
- **就活**(`/workflows:job-hunt-flow`): `/career:self-analysis` → `/career:entry-sheet` → `hr-screener` → `mock-interviewer`
- **広告・LP**: `/marketing:lp-structure` → `/marketing:ad-copy` → `customer-persona` → `compliance-checker`
- **画像生成**: `/design:design-brief` → `/design:image-prompt` や `/design:character-design-prompt` → `prompt-refiner` で改善
- **TRPG / 謎解き**: `/game:trpg-scenario` や `/game:riddle-puzzle` → `playtester` と `puzzle-tester` → `rules-lawyer`
- **世界観づくり**: `/creative:worldbuilding` → `/fictional-docs:fake-timeline` と `/fictional-docs:fake-newspaper` などで作中資料を作成 → `canon-keeper` で整合確認 → `lore-archivist` で設定資料集に編纂
- **歴史対話・討論**: `/roleplay:historical-dialogue` → `fact-fiction-checker` で史実確認 / `debate-panel` で多視点討論
- **考え抜く**: `/thinking:framework-picker` で手法を選ぶ → `/thinking:first-principles` など → `assumption-hunter` と `red-team` で検証
- **未来戦略**: `trend-scout` → `/foresight:scenario-matrix` → `/foresight:scenario-to-strategy` → `scenario-stress-tester`
- **副業を始める**: `idea-validator` → `/side-business:service-menu` → `/side-business:pricing-model`(`pricing-advisor`)→ `/side-business:marketplace-listing` → `client-simulator` で商談練習
- **ひとり遊び**: `umigame-host` でウミガメのスープ / `adventure-narrator` でテキストアドベンチャー / `daydream-guide` で空想旅行
- **習慣をゲームに**: `/life-rpg:quest-board` と `/life-rpg:level-system` で設計 → `quest-giver` に毎日報告 → `hype-squad` に褒めてもらう
- **サプライズ**: `/surprise:surprise-plan` → `/surprise:treasure-hunt` と `/surprise:cipher-puzzles` → `surprise-planner` で段取り管理
- **推し活**: `oshi-listener` で推し語り → `/oshi:fukyo-deck` で布教資料 → `/oshi:ensei-plan` で遠征計画
- **トークン節約**: `/token-saver:delegate-router` で委任先を決める → 探索は `scout`、長いログは `log-digest`、資料は `doc-digest`(いずれも Haiku)→ 区切りで `/token-saver:checkpoint`
- **Django/Flask で Web アプリ**: `/python-apps:django-app` か `/python-apps:flask-app` → `/python-apps:templates-frontend` → `/web-design:layout-system` などで見た目 → `/web-frontend:htmx-patterns` などで機能 → `app-security-reviewer` と `browser-tester`
- **ローカル LLM アプリ**: `/local-llm:ollama-setup` → `/local-llm:model-choice` → `/local-llm:local-rag` → `rag-debugger` → `llm-benchmarker`
- **PyTorch で AI 作成**: `/pytorch:dataset-dataloader` → `/pytorch:training-loop` → `training-debugger`(ログは `log-digest` で要約)→ `/pytorch:export-onnx` → `/ml-deploy:model-serving`
- **ショート動画を作る**: `/video-editing:silence-cut` → `/python-video:whisper-subtitles` → `/video-editing:subtitles` → `/sns-video:vertical-convert` → `/audio-processing:loudness-normalize` → `platform-checker`
- **調査して報告する**(`/workflows:investigation-flow`): `research-planner` → `/desk-research:search-queries` → `source-hunter`(長い資料は `doc-digest`)→ `cross-checker` → `synthesizer` → `summary-auditor` → `briefing-writer`
- **資格試験**: `/exam-prep:past-exam-analysis` → `/exam-prep:exam-schedule` → `mock-examiner` → `weak-point-analyzer`
- **論文を書く**: `/academic-research:research-proposal` → `/academic-research:imrad-paper` → `methods-checker` と `peer-reviewer` → `/academic-research:reviewer-response`
- **設計してから作る**(`/workflows:plan-to-build-flow`): `requirements-interviewer` → `/software-design:design-doc` → `design-doc-reviewer` → `scope-splitter` → `plan-critic` → 実装 → `diff-checker`
- **計画してから書く**(`/workflows:writing-plan-flow`): `/writing-plan:writing-brief` → `/writing-plan:outline-options` → `outline-critic` → `reader-journey-checker` → 執筆 → `strict-editor`
- **長編小説の構造を固める**: `/story-structure:structure-catalog` → `/story-structure:theme-design` → `/story-structure:foreshadowing` → 執筆 → `structure-analyst` と `foreshadow-tracker`
- **料理**: `/lifestyle:meal-plan` で献立 → `/cooking:recipe-writing` とレシピ確認の `recipe-tester` → `/cooking:cooking-timeline` で段取り → `cooking-coach` と一緒に調理 → 失敗したら `cooking-troubleshooter`
- **英語学習**(`/workflows:english-study-flow`): `english-tutor` でレベル診断 → 毎日 `instant-composition-drill`・`/english-learning:pronunciation`・英語日記と `nuance-explainer` → 試験前は `exam-english-coach`
- **韓国語学習**(`/workflows:korean-study-flow`): `korean-tutor` でレベル診断 → `/korean-learning:hangul-basics` → 毎日 `korean-composition-drill` と日記の添削(`korean-corrector`)→ 試験前は `/korean-learning:topik-strategy`
- **スペイン語学習**(`/workflows:spanish-study-flow`): `spanish-tutor` でレベルと地域を確認 → 毎日 `conjugation-drill` と日記の添削(`spanish-corrector`)→ 試験前は `/spanish-learning:dele-strategy`
- **営業**: `/sales:prospecting` → `/sales:outreach` → `/sales:hearing` → `/sales:sales-proposal`(`proposal-critic` でチェック)→ `sales-roleplay` で商談練習 → `deal-reviewer`
- **Web マーケを学ぶ**: `marketing-tutor` で基礎 → `/web-marketing-learning:marketing-kpi` で指標の計算練習 → `case-study-coach` でケーススタディ
- **SNS 運用**: `/sns-operations:account-design` → `/sns-operations:content-calendar` → 投稿(`/content:sns-post`)→ `/sns-operations:insights-analysis` → `account-auditor`
- **人について学ぶ**: `psych-tutor`・`philosophy-tutor`・`be-tutor` でレッスン → 気になる話は `myth-buster` で真偽確認 → `decision-review-coach` で自分の意思決定を振り返る
- **道場で力を伸ばす**(`/workflows:skill-training-flow`): `/training-dojo:dojo-start` で目標と計画 → `dojo-master` が今日のメニューを決める → ① `/<道場>:<分野>-lesson` で学ぶ → ② `<分野>-drills` と練習相手(`language-sparring`・`sales-roleplay`・`communication-sparring`・`negotiation-sparring`・`case-study-coach`・`logic-sparring`・`case-interviewer`・`business-simulator`)で練習 → ③ `<分野>-evaluator` でフィードバック → 練習ログに記録 → 週1回 `progress-analyst`
- **Claude Code の拡張**: `/agent-config-kit:skill-writer` → `skill-reviewer` → `/agent-config-kit:plugin-packager`

## ディレクトリ構成

```
.claude-plugin/marketplace.json
plugins/<plugin>/
  .claude-plugin/plugin.json
  skills/<skill-name>/SKILL.md
  agents/<agent-name>.md
```

新しい skill を追加するときは `plugins/<plugin>/skills/<name>/SKILL.md` を、agent を追加するときは `plugins/<plugin>/agents/<name>.md` を作成してください(`/agent-config-kit:skill-writer` と `/agent-config-kit:agent-writer` が手順を案内します)。
